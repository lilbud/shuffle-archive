# Little Queenie
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/1976/01/04/cover-me-little-queenie/
#### Published: January 04, 1976
#### Last Updated: November 15, 2025
![0x1900-000000-80-0-0.jpg](https://estreetshuffle.com/wp-content/uploads/1976/01/0x1900-000000-80-0-0.jpg)

There Bruce was: biding time at the bar of the Hotel Pffffffffister, when he was supposed to be on stage playing.
When a bomb threat disrupted his show at the Uptown Theater in Milwaukee on the evening of October 2, 1975, Bruce and the band were forced to take a *three hour* intermission only seven songs into the show.
What does one do during an unscheduled three-hour intermission at a hotel bar? Well… listening to the band’s, um, *loose* performance of Chuck Berry’s “Little Queenie” when they re-took the stage at midnight, it’s not hard to figure out.
[Youtube: Bruce Springsteen - LITTLE QUEENIE  1975  (audio)](https://www.youtube.com/watch?v=CkCRdMY9g6E)
![](https://www.youtube.com/watch?v=CkCRdMY9g6E)
Chuck Berry’s original 1959 version was a bit more uptempo and energetic, but in fairness to Bruce, had Berry been “drinking his skull out” for three hours before stepping into the studio? I don’t think so.
[Youtube: Chuck Berry - LITTLE QUEENIE - 1959 HQ!](https://www.youtube.com/watch?v=uyp13Q6dQjY)
![](https://www.youtube.com/watch?v=uyp13Q6dQjY)
“Little Queenie” was a hit for Berry, peaking at #80 on the Hot 100, and it became a favorite for Bruce, too–although it’s a bona fide rarity (it only comes out once or twice a decade), he’s covered it during every era of his career from his Bruce Springsteen Band days forward.
[http://estreetshuffle.com/wp-content/uploads/2018/12/01-LITTLE-QUEENIE-START-CUT.mp3?_=5](http://estreetshuffle.com/wp-content/uploads/2018/12/01-LITTLE-QUEENIE-START-CUT.mp3?_=5)
<http://estreetshuffle.com/wp-content/uploads/2018/12/01-LITTLE-QUEENIE-START-CUT.mp3>
Bruce never forgot that bomb scare experience, though. Bruce was back in Milwaukee almost exactly 27 years after that infamous show. He winkingly asked the audience, “Are you loose?” and closed the show with a “Milwaukee special.”
[Youtube: Bruce Springsteen - "Little Queenie" - Milwaukee, 2002-09-27](https://www.youtube.com/watch?v=jgnT1UIbfmA)
![](https://www.youtube.com/watch?v=jgnT1UIbfmA)
But the band’s smokingest performance of “Little Queenie” was its last (to date, at least)–from their legendary St. Louis ’08 show, when Bruce granted one last sign request in a never-ending encore:
[Youtube: Bruce Springsteen -- LITTLE QUEENIE --- St. Louis 2008](https://www.youtube.com/watch?v=oncRaQa76qA)
![](https://www.youtube.com/watch?v=oncRaQa76qA)
Bruce has played “Little Queenie” at least once a decade since the 1970s, so it’s due for a return… just as soon as Bruce gets back on the road.
**Little Queenie**
**First performed:** September 1, 1971 (Long Branch, NJ)
**Last performed:** August 23, 2008 (St. Louis, MO)
(c) December 11, 2018