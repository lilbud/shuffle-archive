# Cover Me, Wainright Family, Emmylou Harris, Brandi Carlile, and more: Hungry Heart
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/08/13/cover-me-wainright-family-emmylou-harris-brandi-carlile-and-more-hungry-heart/
#### Published: August 13, 2018
#### Last Updated: December 28, 2022
![Cayamo-2017.jpg](https://estreetshuffle.com/wp-content/uploads/2018/08/Cayamo-2017.jpg)

In February 2017, the Cayamo festival-at-sea featured a terrific line-up, and with that much talent on one ship, there were bound to be some team-ups.
Here’s one of them: “[Hungry Heart](https://estreetshuffle.com/index.php/2022/12/21/roll-of-the-dice-hungry-heart/)” covered by the Wainright family, Emmylou Harris, Brandi Carlile, and more.
[Youtube: Cayamo 2017 - Hungry Heart - Wainwright Family and Friends](https://www.youtube.com/watch?v=1yLTMjt4udI)
![](https://www.youtube.com/watch?v=1yLTMjt4udI)