# Cover Me, Barry Gibb: I'm on Fire
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/07/05/cover-me-barry-gibb-im-on-fire/
#### Published: July 05, 2019
#### Last Updated: December 18, 2021
![barry-gibb.jpg](https://estreetshuffle.com/wp-content/uploads/2019/07/barry-gibb.jpg)

One of the highlights of Bruce Springsteen’s Australian High Hopes Tour was his gorgeously arranged cover of “[Stayin’ Alive](https://estreetshuffle.com/index.php/2020/09/01/cover-me-stayin-alive/)” by the Bee Gees. It was so good that even Barry Gibb was blown away by it. (Don’t take my word for it, though.)
> Dear Bruce [@springsteen](https://twitter.com/springsteen?ref_src=twsrc%5Etfw), just been blown away by your Stayin Alive. You brought it back to life.Thank you!
>
> — Barry Gibb (@GibbBarry) [February 26, 2014](https://twitter.com/GibbBarry/status/438814997020692480?ref_src=twsrc%5Etfw)
So when Barry kicked off his own American tour a few months later, he decided to repay the favor.
At his tour opener (and at many of the shows thereafter), Barry’s set included a cover of Bruce’s 1985 hit, “[I’m on Fire](https://estreetshuffle.com/index.php/2021/09/11/roll-of-the-dice-im-on-fire/).” Here’s his performance from Chicago, on May 27, 2014:
[Youtube: Barry Gibb "I'm on Fire' Chicago Mythology Tour](https://www.youtube.com/watch?v=R81FXrQ6aiQ)
![](https://www.youtube.com/watch?v=R81FXrQ6aiQ)
I suspect Barry chose the song to show off that famous falsetto of his, and based on the crowd’s reaction it was an inspired choice.