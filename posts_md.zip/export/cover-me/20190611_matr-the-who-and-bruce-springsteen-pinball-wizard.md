# MatR: The Who and Bruce Springsteen, Pinball Wizard
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/06/11/matr-the-who-and-bruce-springsteen-pinball-wizard/
#### Published: June 11, 2019
#### Last Updated: June 11, 2019
![pinball.jpg](https://estreetshuffle.com/wp-content/uploads/2019/06/pinball.jpg)

“Pinball Wizard” is one of The Who’s most popular songs (it went to #4 in the U.K. and #19 in the U.S.), and it’s certainly one of the most performed, a mainstay of their concerts since its debut on *Tommy* in 1969.
[Youtube: The Who-Pinball Wizard](https://www.youtube.com/watch?v=4AKbUm8GrbM)
![](https://www.youtube.com/watch?v=4AKbUm8GrbM)
While Bruce has never covered it during one of his own concerts, he did join an all-star jam band at the 5th annual Rock and Roll Hall of Fame Induction Ceremony, backing new inductees The Who on a few of their songs, including “Pinball Wizard.”
You can watch it below, but keep a careful eye out: Bruce’s appearances are few and fleeting. Max Weinberg actually gets more screen time than Bruce–perhaps because he seems to be having an even better time! (Charmingly, Bruce tends to seem star-struck during many of these HoF jam performances.)
[Youtube: The Who perform at Rock and Roll Hall of Fame and Museum inductions 1990](https://www.youtube.com/watch?v=rSb63bh1WVU)
![](https://www.youtube.com/watch?v=rSb63bh1WVU)
**Pinball Wizard
First performed:** January 17, 1990 (New York City, NY)
**Last performed:** January 17, 1990 (New York City, NY)