# MatR: Bruce Springsteen and Bruce Hornsby, You Sexy Thing
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/09/22/matr-bruce-springsteen-and-bruce-hornsby-you-sexy-thing/
#### Published: September 22, 2019
#### Last Updated: December 15, 2020
![sexything.jpg](https://estreetshuffle.com/wp-content/uploads/2019/09/sexything.jpg)

What’s more unlikely than Bruce Springsteen covering “You Sexy Thing,” the surprise 1975 B-side smash hit (it ranked #22 for the entire year) by Hot Chocolate?
[Youtube: Hot Chocolate - You Sexy Thing (ZDF Disco, 24.04.1976)](https://www.youtube.com/watch?v=4DwEni2N_-A)
![](https://www.youtube.com/watch?v=4DwEni2N_-A)
How about turning it into a steamy duet with a fellow Bruce?
On the evenings of December 7 and 8 during Bruce’s 2001 holiday show stand in Asbury Park, one of the far-and-away highlights of those loose, festive shows was the “You Sexy Thing” duet between Bruces Springsteen and Hornsby. And if their vocal performances weren’t hot enough, add Hornsby’s star turn on the accordion and a spot-on sax solo from The Big Man, and you’ve got the recipe for a showstopper.
Take a listen to one of my favorite under-the-radar covers:
[https://videopress.com/embed/pgrQg0c6?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata](https://videopress.com/embed/pgrQg0c6?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata)
Bruce teased fans with “You Sexy Thing” snippets more than a dozen times in the decade that followed, but these two special nights remain the only two times Bruce has ever played it in full.
**You Sexy Thing**
**First performed:** December 7, 2001 (Asbury Park, NJ)
**Last performed:** December 8, 2001 (Asbury Park, NJ)