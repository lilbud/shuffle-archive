# Cover Me, Camera Obscura: Tougher Than the Rest
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/05/28/cover-me-camera-obscura-tougher-than-the-rest/
#### Published: May 28, 2019
#### Last Updated: January 01, 2023
![camera-obscura-the-sweetest-thing-2009-2.jpg](https://estreetshuffle.com/wp-content/uploads/2019/05/camera-obscura-the-sweetest-thing-2009-2.jpg)

A fascinating thing happens when a heterosexual woman sings “[Tougher Than the Rest](https://estreetshuffle.com/index.php/2020/08/08/roll-of-the-dice-tougher-than-the-rest/).”
When you swap the genders of the singer and the addressee, but you keep the rest of the lyrics intact, the song transforms.
In Bruce’s [*Tunnel of Love*](https://estreetshuffle.com/index.php/2022/08/08/album-companion-tunnel-of-love/) original, the singer is a self-aware, world-weary man who realizes he isn’t every girl’s dream, but who pledges to be true and constant.
When Tracyanne Campbell sings it, though (or [Shawn Colvin](http://estreetshuffle.com/index.php/2018/05/09/cover-me-shawn-colvin-tougher-than-the-rest/), or [Tracey Thorn](http://estreetshuffle.com/index.php/2018/09/19/cover-me-everything-but-the-girl-tougher-than-the-rest/), or [Martina Linn](http://estreetshuffle.com/index.php/2018/02/15/cover-me-martina-linn-tougher-than-the-rest/), who likewise bring new meaning to the song), she doesn’t *want* every girl’s dream boy. She wants something true, meaningful, and lasting. And just like that, the song changes, but it’s just as powerfully romantic.
[Youtube: Tougher Than The Rest (Springsteen Cover)](https://www.youtube.com/watch?v=70he4zgJzoU)
![](https://www.youtube.com/watch?v=70he4zgJzoU)
It’s a beautiful cover by Traceyanne’s band Camera Obscura, and you can find it on the B-side of their 2009 single, “The Sweetest Thing.”