# MatR: Roy Orbison, Bruce Springsteen and Friends, Blue Angel
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/11/05/matr-roy-orbison-bruce-springsteen-and-friends-blue-angel/
#### Published: November 05, 2018
#### Last Updated: December 05, 2020
![roy-orbison.png](https://estreetshuffle.com/wp-content/uploads/2018/11/roy-orbison.png)

On September 30 1987, an all-star array of musical talent gathered at the Cocoanut Grove in Los Angeles for the filming of *Roy Orbison & Friends: A Black & White Night*.
Bruce has always been a big Orbison fan, so it’s not surprising to learn that he volunteered to be part of Roy’s backing band. He can be seen prominently throughout the concert, which was broadcast on Cinemax in 1988 and issued (several times) on home video over the years.
However, a few songs were cut (for time) from the original broadcast and home releases, and the sublime “Blue Angel” was one of them. It appeared for the first time more than a decade later; if you haven’t seen the the re-release, check out the performance below.
[Youtube: Roy Orbison - "Blue Angel" from Black and White Night](https://www.youtube.com/watch?v=GCe40AlSAsE)
![](https://www.youtube.com/watch?v=GCe40AlSAsE)
That’s Bruce seated in the background on guitar, and if you watch carefully you’ll catch Jackson Browne, Elvis Costello, and k.d. lang, and others as well.
Orbison originally released “Blue Angel” in 1960. It peaked at #9 on the U.S. Hot 100.
[Youtube: Blue Angel](https://www.youtube.com/watch?v=YUMFNz0IpEQ)
![](https://www.youtube.com/watch?v=YUMFNz0IpEQ)
Check out more Orbison/Springsteen highlights from *Black and White Night* [here](https://estreetshuffle.com/?s=orbison).
**Blue Angel**
**First performed:** September 30, 1987 (Los Angeles, CA)
**Last performed:** September 30, 1987 (Los Angeles, CA)