# Cover Me, Kenny Chesney: One Step Up
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/08/22/cover-me-kenny-chesney-one-step-up/
#### Published: August 22, 2018
#### Last Updated: August 22, 2018
![kenny-e1534738886143.jpg](https://estreetshuffle.com/wp-content/uploads/2018/08/kenny-e1534738886143.jpg)

“[One Step Up](http://estreetshuffle.com/index.php/2018/08/17/roll-of-the-dice-one-step-up/)” had been missing in action for 17 years when Bruce unexpectedly brought it back at his Pittsburgh show on the Devils & Dust tour. He didn’t say much by way of introduction, and what he did say was cryptic:
“This for Ken. Thanks for the nice card.”
“Ken” is Kenny Chesney, and the card in question was a note that Chesney included when he sent Bruce his recording of “One Step Up” from his 2002 album, *No Shoes, No Shirt, No Problems.*
Chesney has been pretty open about his reverence for Bruce’s music, and his fondness for “One Step Up” dates back to his bar gig days. He’d always intended to record it but, “I knew I needed to wait until I’d lived enough to really sing the song. I felt like I owed it what it was: don’t just sing it ’cause it’s Bruce; wait ’til I really understand.”
[Youtube: One Step Up](https://www.youtube.com/watch?v=SzFk7R2thiA)
![](https://www.youtube.com/watch?v=SzFk7R2thiA)
Maybe he understood it when he recorded it in the studio, but there’s no doubt he’d lived it by the time he performed it live at The Stone Pony fifteen years later. That performance below–plus his show-stopping rendition at Bruce’s MusiCares tribute–is far superior to his album cut and cemented his Bruce bonafides. It’s every bit as good as the original.
[Youtube: Kenny Chesney - One Step Up (Official Live Audio)](https://www.youtube.com/watch?v=AutxQVMIYvk)
![](https://www.youtube.com/watch?v=AutxQVMIYvk)