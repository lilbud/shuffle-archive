# MatR: Jon Bon Jovi and Bruce Springsteen: Who Says You Can't Go Home
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/06/22/matr-jon-bon-jovi-and-bruce-springsteen-who-says-you-cant-go-home/
#### Published: June 22, 2019
#### Last Updated: June 15, 2019
![whosays.jpg](https://estreetshuffle.com/wp-content/uploads/2019/06/whosays.jpg)

I’m not a big Bon Jovi fan, but I do love their song, “Who Says You Can’t Go Home,” from their 2005 *Have a Nice Day* album. That’s probably because it sounds just like a Bruce Springsteen song.
Seriously, just listen to the lyrics and tell me that Jon wasn’t channeling Bruce when he wrote it:
[Youtube: Bon Jovi - Who Says You Can't Go Home (Official Music Video)](https://www.youtube.com/watch?v=abzbVFuxigg)
![](https://www.youtube.com/watch?v=abzbVFuxigg)
So I was pretty psyched when Jon asked Bruce to join him when he played “Who Says You Can’t Go Home” at the *12-12-12* benefit concert for the victims of Hurricane Sandy.
Sure enough, the song fit Bruce like a glove. Watch and see–it’s a fantastic performance:
[Youtube: Bon Jovi / Bruce Springsteen - Who Says You Can't Go Home 2012 Live](https://www.youtube.com/watch?v=NQWFklgKA_E)
![](https://www.youtube.com/watch?v=NQWFklgKA_E)
As it turns out, “Who Says You Can’t Go Home” was made for a duet. In fact, Jon Bon Jovi recorded and filmed *two* versions of it for the same album. You’ve seen the first at the top of this post; here’s the second, in a country arrangement with Jennifer Nettles:
[Youtube: Bon Jovi, Jennifer Nettles - Who Says You Can't Go Home](https://www.youtube.com/watch?v=5CeX5VEo10c)
![](https://www.youtube.com/watch?v=5CeX5VEo10c)
I gotta say: Bruce turned in a great performance, but the best “Who Says You Can’t Go Home” duet award has to go to Jon and Jennifer.
**Who Says You Can’t Go Home
First performed:** December 12, 2012 (New York City, NY)
**Last performed:** December 12, 2012 (New York City, NY)