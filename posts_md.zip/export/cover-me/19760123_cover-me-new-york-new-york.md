# New York, New York
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/1976/01/23/cover-me-new-york-new-york/
#### Published: January 23, 1976
#### Last Updated: November 15, 2025
![newyork.png](https://estreetshuffle.com/wp-content/uploads/2021/06/newyork.png)

Start spreading the news: I’m leaving today!
Actually, that’s not true. I left last night, and by the time you read this, I’ll have landed at JFK and am probably in an Uber headed toward New York, New York.
You know, The Big Apple. The City That Never Sleeps. The City So Nice They Named It Twice.
I’m talking about the city immortalized by the song named after it, from the movie named after it.
[Youtube: New York, New York](https://www.youtube.com/watch?v=5-pyc_z7WbY)
![](https://www.youtube.com/watch?v=5-pyc_z7WbY)
“New York, New York” was originally performed by Liza Minelli in Martin Scorsese’s film by the same name. Minelli’s original version never became a hit–it peaked at only #104 upon its release in 1977–but her live performances became legendary, like this one from 1986.
[Youtube: Liza Belts Out the Ultimate Performance of 'New York, New York' [REMASTERED 2013]](https://www.youtube.com/watch?v=8XhxfFzgKmU)
![](https://www.youtube.com/watch?v=8XhxfFzgKmU)
Still, it took The Chairman of the Board to make a hit single out of “New York, New York.” Frank Sinatra scored his last-ever Top 40 hit with it when his studio recording peaked at #32 in 1980.
[Youtube: Theme From New York, New York (2008 Remastered)](https://www.youtube.com/watch?v=le1QF3uoQNg)
![](https://www.youtube.com/watch?v=le1QF3uoQNg)
It didn’t take long for “New York, New York” to establish itself as an unofficial theme song for the city, a fact tacitly acknowledged by Bruce Springsteen and the E Street Band when they played New York’s Madison Square Garden on the Tunnel of Love Tour in 1988.
At the first two of a five-show stand, the E Street Band played Bruce off stage at the end of the night with a brief instrumental coda of “New York, New York.”
[https://videopress.com/embed/28CoUbgM?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata](https://videopress.com/embed/28CoUbgM?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata)
Okay, maybe that was too short to count as a true cover, but there was also the time that Bruce joined Sinatra himself at a tribute concert in 1995, in what may very well be Bruce’s stiffest, most awkward television appearance ever.
[Youtube: Frank Sinatra - New York, New York 1995](https://www.youtube.com/watch?v=93e0wRzl0vo)
![](https://www.youtube.com/watch?v=93e0wRzl0vo)
Okay, maybe that doesn’t really count as a cover either. I’m not even certain Bruce sings at any point during that performance. I don’t know *what* he was doing exactly, and I’m not sure Bruce knew either.
But none of that matters, because if you haven’t figured it out by now, this whole article is just a pretext because **I’m seeing Springsteen on Broadway tonight!**
I’m excited to hear *any* live music again after a year-and-a-half, let alone an up-close-and-personal performance by Bruce.
I’m way too excited to blog coherently, so instead of an analytical roll of the dice or a trip through rock and roll history, today you just get my fanboy babbling.
Stay tuned for my report from Re-Opening Night coming on Monday, though… pretty sure I can collect myself by then.
I think.
**New York, New York
First performed:** May 16, 1988 (New York City, NY)
**Last performed:** November 19, 1995 (Los Angeles, CA)
(c) June 26, 2021