# MatR: Bruce Springsteen, Joe Ely, and Alejandro Escovedo: Midnight Train
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/04/matr-bruce-springsteen-joe-ely-and-alejandro-escovedo-midnight-train/
#### Published: March 04, 2018
#### Last Updated: April 14, 2019
![flat.jpg](https://estreetshuffle.com/wp-content/uploads/2018/03/flat.jpg)

From SxSW 2012: Bruce joins his Texas buddies Joe Ely and Alejandro Escovedo for The Flatlanders’ “Midnight Train.”
[Youtube: JOE ELY, BRUCE SPRINGSTEEN & ALEJANDRO ESCOVEDO "Midnight Train" SXSW 2012](https://www.youtube.com/watch?v=DmLPWWvrT6I)
![](https://www.youtube.com/watch?v=DmLPWWvrT6I)
Here’s the original–
[Youtube: Midnight Train](https://www.youtube.com/watch?v=y_TyiFj-3uw)
![](https://www.youtube.com/watch?v=y_TyiFj-3uw)
**Midnight Train
First performed:** March 14, 2012 (Austin, TX)
**Last performed:** March 14, 2012 (Austin, TX)