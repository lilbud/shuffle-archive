# Cover Me, Serena Ryder: Racing in the Street
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/11/18/cover-me-serena-ryder-racing-in-the-street/
#### Published: November 18, 2018
#### Last Updated: December 15, 2021
![serena.jpg](https://estreetshuffle.com/wp-content/uploads/2018/11/serena.jpg)

Singer-songwriter Serena Ryder may not be as well known in the U.S. as she is in her native Canada, but she certainly caught someone’s attention on E Street, because her exquisite, stripped-down cover of “[Racing in the Street](https://estreetshuffle.com/index.php/2021/10/03/roll-of-the-dice-racing-in-the-street/)” was featured on Bruce’s official site back in 2009 as part of the site’s short-lived “Hangin’ on E Street” series.
That series has since been removed, but the videos are still floating around, and many of them (like this one) are well worth watching. Watch Serena do right by “Racing in the Street” below.
[Youtube: Serena Ryder - "Racing In The Street" - Hangin' Out On E Street](https://www.youtube.com/watch?v=zvjGxcZSMz4)
![](https://www.youtube.com/watch?v=zvjGxcZSMz4)