# Cover Me, The Head and The Heart: Hungry Heart
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2020/02/20/cover-me-the-head-and-the-heart-hungry-heart/
#### Published: February 20, 2020
#### Last Updated: January 01, 2023
![TheHeadandtheHeart.jpg](https://estreetshuffle.com/wp-content/uploads/2020/02/TheHeadandtheHeart.jpg)

Who knew The Head and The Heart are Springsteen fans?
I didn’t, at least not until the band showed up for the premiere of *Blinded by the Light* at Sundance and performed a Springsteen tribute in Park City the night before.
To the best of my knowledge, though, no recording (or even a set list) has surfaced from that night.
But fear not, THATH/Springsteen fans: late last year, The Head and The Heart paid homage to Bruce once again, and this time their performance was not only captured on audio–it was streamed as part of a special 70th birthday tribute show.
Here’s that performance: a lovely and aptly-chosen cover of Bruce’s “[Hungry Heart](https://estreetshuffle.com/index.php/2022/12/21/roll-of-the-dice-hungry-heart/).”
[http://estreetshuffle.com/wp-content/uploads/2020/02/head-heart-hungry.mp3?_=1](http://estreetshuffle.com/wp-content/uploads/2020/02/head-heart-hungry.mp3?_=1)
<http://estreetshuffle.com/wp-content/uploads/2020/02/head-heart-hungry.mp3>