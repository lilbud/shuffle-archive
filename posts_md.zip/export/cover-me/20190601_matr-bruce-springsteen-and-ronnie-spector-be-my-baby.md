# MatR: Bruce Springsteen and Ronnie Spector, Be My Baby
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/06/01/matr-bruce-springsteen-and-ronnie-spector-be-my-baby/
#### Published: June 01, 2019
#### Last Updated: December 12, 2020
![bemybaby.jpg](https://estreetshuffle.com/wp-content/uploads/2019/06/bemybaby.jpg)

It peaked at #2 on the Billboard Hot 100.
It captured the top spot on the Cash Box Top 100.
*Rolling Stone* notched it at #22 on their 500 Greatest Songs of All Time.
*Billboard* named it the #1 Greatest Girl Group Song of All Time.
It’s in both the Grammy Hall of Fame and the United States National Recording Registry.
It features a full orchestra, backing vocals by Darlene Love and Sonny and Cher.
And of course, the 1963 smash “Be My Baby” features the inimitable Ronnie Spector on lead vocals, along with producer Phil Spector’s “wall of sound” that influenced Bruce’s “Born to Run” (along with Ronnie’s signature “whoa-oh-oh-oh-oh” that Bruce quotes in his own signature song).
[Youtube: The Ronettes - Be My Baby (Official Audio)](https://www.youtube.com/watch?v=jSPpbOGnFgk)
![](https://www.youtube.com/watch?v=jSPpbOGnFgk)
Bruce was a Ronnie Spector fan long before they ever met–and their meeting was musical providence by way of John Lennon. (Read that story [here](http://estreetshuffle.com/index.php/2018/09/02/meeting-across-the-river-bruce-springsteen-and-ronnie-spector-baby-i-love-you/).)
On the night of November 4, 1976, Bruce finally had the chance to perform with Ronnie on stage when he invited her to join the E Street Band during their encore set at the Palladium in New York City. They performed three of her hits that night, culminating in their greatest hit. The E Street Band may not have been The Ronettes, but they were more than up for the challenge.
[Youtube: Bruce Springsteen Be My Baby(with Ronnie Spector) 1976](https://www.youtube.com/watch?v=0AnDHaY-evE)
![](https://www.youtube.com/watch?v=0AnDHaY-evE)
Ronnie and Bruce would perform “Be My Baby” together four more times the following year, but even though Ronnie and Bruce have shared a stage as recently as 2016, it’s been more than three decades since they last performed Ronnie’s iconic hit together.
**Be My Baby
First performed:** November 4, 1976 (New York City, NY)
**Last performed:** January 18, 1989 (New York City, NY)