# MatR: John Eddie, Bruce Springsteen, and Friends: Bang a Gong (Get It On)
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/04/11/matr-john-eddie-and-bruce-springsteen-bang-a-gong-get-it-on/
#### Published: April 11, 2019
#### Last Updated: December 10, 2020
![Get-It-On.jpg](https://estreetshuffle.com/wp-content/uploads/2019/04/Get-It-On.jpg)

One of rock’s greatest riffs was based on another one of rock’s greatest riffs, and Bruce has played them both.
“[Little Queenie](http://estreetshuffle.com/index.php/2018/12/11/cover-me-little-queenie/)” is the more common of the two (forever associated by fans with the infamous “bomb scare show” of 1975); Bruce’s version of “Get It On” is a lot more obscure.
The original, of course, is well-known and instantly recognizable. T. Rex released it as a single in 1971, and it went all the way to #10 in the U.S. and to the top spot in the U.K.
[Youtube: T. Rex - Get It On (1971) HD 0815007](https://www.youtube.com/watch?v=wZkTh_T75QY)
![](https://www.youtube.com/watch?v=wZkTh_T75QY)
Supergroup The Power Station covered it in 1985, and their version (slightly retitled) charted as well, outperforming the original in the U.S.
[Youtube: The Power Station - Get It On (Bang A Gong) (Official Music Video)](https://www.youtube.com/watch?v=O2vHbXI2p4k)
![](https://www.youtube.com/watch?v=O2vHbXI2p4k)
When Bruce tackled it for the one and only time, it was with a supergroup of sorts, too. On the night of October 21, 1994, Bruce joined an all-star line-up at The Playpen in Sayreville, New Jersey.
Together with John Eddie, Greg Kihn, Marshall Crenshaw, and Elliott Murphy, Bruce tackled an impromptu “Bang a Gong (Get It On)” before seguing seamlessly into “[(Get Your Kicks on) Route 66](https://estreetshuffle.com/index.php/2019/08/15/cover-me-get-your-kicks-on-route-66/).” Listen to that one-time-only performance below.
[Youtube: Bruce Springsteen, John Eddie, and Friends - "Bang a Gong (Get It On)" / "Route 66"](https://www.youtube.com/watch?v=9osA0jMFeBk)
![](https://www.youtube.com/watch?v=9osA0jMFeBk)
**Get It On**
**First performed:** October 21, 1994 (Sayreville, NJ)
**Last performed:** October 21, 1994 (Sayreville, NJ)