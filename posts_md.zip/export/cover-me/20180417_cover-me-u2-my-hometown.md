# Cover Me, U2: My Hometown
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/04/17/cover-me-u2-my-hometown/
#### Published: April 17, 2018
#### Last Updated: November 27, 2020
![u2.jpg](https://estreetshuffle.com/wp-content/uploads/2018/04/u2.jpg)

On June 29 1985, U2 played a homecoming show at Croke Park in Dublin. Bono kicked off the encores with a dedication to his father: a cover of “[My Hometown](https://estreetshuffle.com/index.php/2020/04/09/roll-of-the-dice-my-hometown/).”
I’ll give Bono credit for the heartfelt vocals, but I don’t think it’s possible to arrange the song in a way that screams “1980s!” more than this one…
[Youtube: 04 My Hometown](https://www.youtube.com/watch?v=qBhj3qKgQ-Q)
![](https://www.youtube.com/watch?v=qBhj3qKgQ-Q)