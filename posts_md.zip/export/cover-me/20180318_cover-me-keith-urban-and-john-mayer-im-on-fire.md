# Cover Me, Keith Urban and John Mayer: I'm on Fire
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/18/cover-me-keith-urban-and-john-mayer-im-on-fire/
#### Published: March 18, 2018
#### Last Updated: December 12, 2021
![keith-urban-john-mayer-gorge-urbancountryblog.jpg](https://estreetshuffle.com/wp-content/uploads/2018/03/keith-urban-john-mayer-gorge-urbancountryblog.jpg)

There are enough covers of “[I’m on Fire](https://estreetshuffle.com/index.php/2021/09/11/roll-of-the-dice-im-on-fire/)” to fuel a blog of its own, but this is one of my favorites–the guitar interplay is just exquisite, and you’d expect no less from John Mayer and Keith Urban.
From their 2010 concert at the Gorge Amphitheater in George, WA.
[Youtube: Mayer / Urban - I'm On Fire - The Gorge - 8/28/2010](https://www.youtube.com/watch?v=RMMD891A7V4)
![](https://www.youtube.com/watch?v=RMMD891A7V4)