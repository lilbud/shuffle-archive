# Cover Me: Gulf Coast Highway
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/01/18/cover-me-gulf-coast-highway/
#### Published: January 18, 2019
#### Last Updated: December 07, 2020
![nancy.jpg](https://estreetshuffle.com/wp-content/uploads/2019/01/nancy.jpg)

In February 1988, just prior to the kickoff of Bruce’s Tunnel of Love Express Tour, Nanci Griffith released her sixth studio album, *Little Love Affairs.*
Tucked away at the end of Side One of that album is a gorgeous duet with Mac McAnally called “Gulf Coast Highway,” that sounds for all the world like a Bruce Springsteen song.
[Youtube: Nanci Griffith - Gulf Coast Highway](https://www.youtube.com/watch?v=okUYwIdxRWs)
![](https://www.youtube.com/watch?v=okUYwIdxRWs)
In fact, with lyrics like these, “Gulf Coast Highway” would be right at home on *The Ghost of Tom Joad* (even though that album was still seven years in the future):
*Gulf coast highway, he worked the rails*
*He worked the rice fields with their cold dark wells*
*He worked the oil rigs in the Gulf of Mexico*
*The only thing we’ve owned is this old house here by the road*
*…*
*Highway 90, the jobs are gone*
*We kept our garden, we set the sun*
*This is the only place on Earth blue bonnets grow*
*And once a year they come and go*
*At this old house here by the road*
Bruce was apparently taken with the song, because not long after the song’s release, he soundchecked it at least once. The recording below is from a soundcheck sometime during his stand at Madison Square Garden in 1988. Take a listen–it’s a beautiful arrangement featuring Patti’s lovely backing vocals.
[Youtube: Bruce Springsteen - "Gulf Coast Highway" - New York, 1988](https://www.youtube.com/watch?v=wgN6OHlkoZU)
![](https://www.youtube.com/watch?v=wgN6OHlkoZU)
Too bad Bruce bluffs some of the vocals; this is one cover I’d love to have a true recording of.
**Gulf Coast Highway**
**Never performed live** (but soundchecked in 1988)