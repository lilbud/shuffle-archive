# Cover Me, Jesse Malin: Janey, Don't You Lose Heart
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/12/17/cover-me-jesse-malin-janey-dont-you-lose-heart/
#### Published: December 17, 2018
#### Last Updated: April 15, 2019
![jesse-e1543638332310.jpg](https://estreetshuffle.com/wp-content/uploads/2018/12/jesse-e1543638332310.jpg)

Here’s a lovely cover of one of my favorite songs from *Tracks:*
“[Janey, Don’t You Lose Heart](http://estreetshuffle.com/index.php/2019/04/06/roll-of-the-dice-janey-dont-you-lose-heart/)” performed by Jesse Malin and some very talented backing musicians (that’s clearly Joe Grushecky on guitar, and I’m pretty sure that’s Willie Nile lurking at the edge of the frame on tambourine) at McLoone’s in Asbury Park during Light of Day 2017.
Nothing particularly remarkable or unusual about this one, just a sweet performance by some great musicians. Here’s hoping for a reprise next month!
[Youtube: ''Janey, Don't You Lose Heart'' - Jesse Malin - Asbury Park, New Jersey - January 15th, 2017](https://www.youtube.com/watch?v=n7rs94Yb23o)
![](https://www.youtube.com/watch?v=n7rs94Yb23o)