# Cover Me, Lynda Carter: I'm on Fire
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/07/17/cover-me-lynda-carter-im-on-fire/
#### Published: July 17, 2019
#### Last Updated: December 18, 2021
![lynda.jpg](https://estreetshuffle.com/wp-content/uploads/2019/07/lynda.jpg)

So this is a thing: Iconic TV stars from the 1970s covering songs by Bruce Springsteen. Sure, it’s a micro-genre, but a surprisingly well-represented one.
So far on the Shuffle, we’ve featured Tom “Luke Duke” Wopat’s [wonderfully atmospheric cover](http://estreetshuffle.com/index.php/2019/04/17/cover-me-tom-wopat-meeting-across-the-river/) of “[Meeting Across the River](http://estreetshuffle.com/index.php/2019/08/04/roll-of-the-dice-meeting-across-the-river/)” and Suzi “Leather Tuscadero” Quatro’s [terrific version](http://estreetshuffle.com/index.php/2019/03/16/cover-me-suzi-quatro-born-to-run/) of “Born to Run.”
Here’s installment #3: Lynda “Wonder Woman” Carter’s gentle country arrangement of “[I’m on Fire](https://estreetshuffle.com/index.php/2021/09/11/roll-of-the-dice-im-on-fire/).”
[Youtube: I'm on Fire](https://www.youtube.com/watch?v=K86HGZQ4i4I)
![](https://www.youtube.com/watch?v=K86HGZQ4i4I)
Can’t say I’m a fan of this particular arrangement–I think it entirely loses the heat at the heart of the song–but it’s a valiant attempt, and hey, it’s Wonder Woman.
Bonus: here’s a snippet of Lynda performing the song live. It’s only a minute, but it’s the only clip I could find.
[https://www.dailymotion.com/embed/video/x139duf](https://www.dailymotion.com/embed/video/x139duf)