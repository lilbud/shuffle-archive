# Cover Me, Mat Kearney: Dancing in the Dark
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/02/10/cover-me-mat-kearney-dancing-in-the-dark/
#### Published: February 10, 2018
#### Last Updated: December 28, 2022
![kearney.jpg](https://estreetshuffle.com/wp-content/uploads/2018/02/kearney.jpg)

There are a lot of covers of “[Dancing in the Dark](https://estreetshuffle.com/index.php/2021/12/25/roll-of-the-dice-dancing-in-the-dark/)” out there, but this is one by Mat Kearney in 2009 is my favorite.
Nicely done, Mat.
[Youtube: Matt Kearney- Dancing in the Dark](https://www.youtube.com/watch?v=JbZC7qMTO-Y)
![](https://www.youtube.com/watch?v=JbZC7qMTO-Y)