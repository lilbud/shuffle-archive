# Cover Me, Chris Martin: My Love Will Not Let You Down
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/09/04/cover-me-chris-martin-my-love-will-not-let-you-down/
#### Published: September 04, 2018
#### Last Updated: April 14, 2019
![martin.jpg](https://estreetshuffle.com/wp-content/uploads/2018/09/martin.jpg)

Flashback to 2009 and the 23rd Bridge School benefit concert, a recurring event that Bruce himself is no stranger to.
That year, Coldplay’s Chris Martin was among the performers, and a highlight of his acoustic set was a cover of Bruce’s “[My Love Will Not Let You Down](http://estreetshuffle.com/index.php/2018/01/24/roll-of-the-dice-my-love-will-not-let-you-down/)” performed on piano and violin only.
It’s a bit rough around the edges, but if you ever wondered what this arena anthem would sound like acoustically, here’s your chance to find out.
[Youtube: Chris Martin covers Springsteen at Bridge School Benefit](https://www.youtube.com/watch?v=JMypwUsp7Y0)
![](https://www.youtube.com/watch?v=JMypwUsp7Y0)