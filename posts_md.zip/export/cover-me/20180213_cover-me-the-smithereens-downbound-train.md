# Cover Me, The Smithereens: Downbound Train
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/02/13/cover-me-the-smithereens-downbound-train/
#### Published: February 13, 2018
#### Last Updated: December 12, 2021
![dowbound.jpg](https://estreetshuffle.com/wp-content/uploads/2018/02/dowbound.jpg)

Fellow New Jerseyans take a swing at Bruce’s “[Downbound Train](http://estreetshuffle.com/index.php/2019/01/22/roll-of-the-dice-downbound-train/).”
There’s nothing new here arrangement-wise, but they do an admirable job with it. They also have the benefit of distance from the 1980s; it’s nice to hear a studio version of “Downbound Train” with the synth dialed back!
[Youtube: Downbound Train](https://www.youtube.com/watch?v=i5WJowjLhmc)
![](https://www.youtube.com/watch?v=i5WJowjLhmc)