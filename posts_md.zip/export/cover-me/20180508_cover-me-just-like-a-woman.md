# Cover Me: Just Like a Woman
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/05/08/cover-me-just-like-a-woman/
#### Published: May 08, 2018
#### Last Updated: November 26, 2019
![justlikeawoman.jpg](https://estreetshuffle.com/wp-content/uploads/2018/05/justlikeawoman.jpg)

Bruce Springsteen has never *officially* performed Bob Dylan’s “Just Like a Woman,” but he did cover it once during a soundcheck, way back on March 23, 1988 in Atlanta. The sound quality isn’t great, but it’s an enjoyable listen at least once:
[Youtube: Bruce Springsteen covers Bob Dylan's "Just Like a Woman" - Atlanta, March 23, 1988](https://www.youtube.com/watch?v=iJFX3NtPbjg)
![](https://www.youtube.com/watch?v=iJFX3NtPbjg)
As always, Dylan’s original for comparison:
[Youtube: Bob Dylan - Just Like a Woman (Official Audio)](https://www.youtube.com/watch?v=dRLXZVojdhQ)
![](https://www.youtube.com/watch?v=dRLXZVojdhQ)
**Just Like a Woman**
**First performed:** March 4, 1988 (Chapel Hill, NC – soundcheck only)
**Last performed:** March 23, 1988 (Atlanta, GA – soundcheck only)