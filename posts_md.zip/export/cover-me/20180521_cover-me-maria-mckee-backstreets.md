# Cover Me, Maria McKee: Backstreets
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/05/21/cover-me-maria-mckee-backstreets/
#### Published: May 21, 2018
#### Last Updated: December 28, 2022
![mckee.jpg](https://estreetshuffle.com/wp-content/uploads/2018/05/mckee.jpg)

Maria McKee is no stranger to Bruce’s music: when she was fronting Lone Justice in the eighties, Steve Van Zandt was a frequent collaborator, and Shane Fontayne was her bandmate. But the musical connection stayed second degree until 2006, when McKee took a crack at one of Bruce’s most enduring classics.
From her album *Live – Acoustic Tour 2006*, here’s Maria McKee’s beautiful cover of “[Backstreets](https://estreetshuffle.com/index.php/2022/05/14/roll-of-the-dice-backstreets/).”
[Youtube: Backstreets-Maria McKee](https://www.youtube.com/watch?v=MgwObTsSebY)
![](https://www.youtube.com/watch?v=MgwObTsSebY)