# Cover Me, Jon Bon Jovi: Fade Away
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/05/03/cover-me-jon-bon-jovi-fade-away/
#### Published: May 03, 2019
#### Last Updated: January 01, 2023
![Jon-Bon-Jovi-Tokyo-1997.jpg](https://estreetshuffle.com/wp-content/uploads/2019/05/Jon-Bon-Jovi-Tokyo-1997.jpg)

I don’t know much about the source of today’s video; perhaps some Bon Jovi fans can help me out.
The original Youtube poster cites this as hailing from Jon Bon Jovi’s sole stop in Japan on his 1997 *Destination Anywhere* tour, and I have no reason doubt that.
If so, however, someone needs to correct the setlist record, because there’s no mention of Jon’s beautiful cover of Bruce’s “[Fade Away](http://estreetshuffle.com/index.php/2018/04/28/roll-of-the-dice-fade-away/)” below.
[Youtube: Jon Bon Jovi - Fade Away (Japan 1997)](https://www.youtube.com/watch?v=EE0Ljr7F-bg)
![](https://www.youtube.com/watch?v=EE0Ljr7F-bg)
Interestingly, though, the setlist archive indicates that John opened the show with “[Not Fade Away](https://estreetshuffle.com/index.php/2020/06/24/cover-me-not-fade-away/)” (an entirely different Buddy Holly song) and encored with Bruce’s “[Hearts of Stone](https://estreetshuffle.com/index.php/2022/09/07/roll-of-the-dice-hearts-of-stone/).” Perhaps one of those is a mistaken reference to “Fade Away” instead.
Regardless of where it was, though, Jon gave a lovely and faithful performance of the song that night, and it’s a worthy addition to the vast catalog of Springsteen covers.