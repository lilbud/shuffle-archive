# Cover Me: Coma Girl
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/03/13/cover-me-coma-girl/
#### Published: March 13, 2019
#### Last Updated: March 12, 2019
![JoeStrummer_ComaGirl-258683b.jpg](https://estreetshuffle.com/wp-content/uploads/2019/03/JoeStrummer_ComaGirl-258683b.jpg)

In the summer of 2009, Bruce Springsteen and the E Street Band hit the festival circuit for the first time. One of their first stops was a headlining gig at England’s Glastonbury Festival, where Bruce paid tribute to Joe Strummer with an acoustic cover of “Coma Girl,” accompanied only by Clarence.
[Youtube: Bruce Springsteen - "Coma Girl" - 2009-06-27](https://www.youtube.com/watch?v=CidvmRntFu8)
![](https://www.youtube.com/watch?v=CidvmRntFu8)
Strummer’s love for Glastonbury is well known, and “Coma Girl” itself is reported to be inspired by Strummer’s experiences with his daughter at the festival, so it was both thoughtful and poignant of Bruce to play that particular song from that particular stage.
“Coma Girl” was released as the first single off of Strummer’s *Streetcore* album with The Mescaleros in 2003. He never lived to see its release.
[Youtube: Joe Strummer & The Mescaleros - Coma Girl](https://www.youtube.com/watch?v=x7YHHK9WReY)
![](https://www.youtube.com/watch?v=x7YHHK9WReY)
**Coma Girl
First performed:** June 27, 2009 (Pilton, England)
**Last performed:** June 27, 2009 (Pilton, England)