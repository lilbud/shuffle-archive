# Cover Me, John Moreland: Thunder Road
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/07/14/cover-me-john-moreland-thunder-road/
#### Published: July 14, 2018
#### Last Updated: July 08, 2018
![john-moreland-thunder-road-bruce-springsteen.jpg](https://estreetshuffle.com/wp-content/uploads/2018/07/john-moreland-thunder-road-bruce-springsteen.jpg)

Oklahoma singer-songwriter John Moreland’s gruff voice makes him a natural fit for covering Bruce, and his gut-wrenching, heart-tugging lyrics make “Thunder Road” a natural song choice.
Here’s his take on it, recorded in the studio in 2015.
[Youtube: John Moreland - Thunder Road](https://www.youtube.com/watch?v=Jub6cg_UhcQ)
![](https://www.youtube.com/watch?v=Jub6cg_UhcQ)