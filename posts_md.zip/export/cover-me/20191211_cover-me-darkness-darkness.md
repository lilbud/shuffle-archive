# Cover Me: Darkness, Darkness
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/12/11/cover-me-darkness-darkness/
#### Published: December 11, 2019
#### Last Updated: December 18, 2020
![darkness.jpg](https://estreetshuffle.com/wp-content/uploads/2019/11/darkness.jpg)

“Darkness, Darkness” never got anywhere close to being a hit for The Youngbloods. Even though the band released it as a single twice (once in 1969 and then again the following year), it took the second attempt for it to even crack the Top 100.
[Youtube: The Youngbloods - Darkness, Darkness](https://www.youtube.com/watch?v=ORSD_u2upP4)
![](https://www.youtube.com/watch?v=ORSD_u2upP4)
That didn’t stop Jesse Colin Young’s anti-war song from inspiring a host of covers over the years from Robert Plant, Ann and Nancy Wilson, Eric Burdon, Cowboy Junkies, and more.
It also influenced a very young Bruce Springsteen, who added the song to his set lists for several shows during his pre-label Bruce Springsteen Band era.
It’s not surprising that “Darkness, Darkness” resonated with Bruce. With lyrics describing the nighttime terrors of a soldier in Vietnam, the song must have hit close to home for Bruce, who had already lost a bandmate and a local hero to the war.
But it’s a little bit surprising that Bruce chose to arrange “Darkness, Darkness” as a twelve-minute instrumental jam rather than include its lyrics.
[Youtube: Darkness Darkness Bruce Springsteen Band 1972 02 04, Back Door Club, Richmond, VA](https://www.youtube.com/watch?v=QGTbr0ShG_c)
![](https://www.youtube.com/watch?v=QGTbr0ShG_c)
Why’d he do that? Beats me, but the Bruce Springsteen Band still manages to communicate the narrator’s dread and horror even without the lyrics.
Even then, they were that good.
**Darkness, Darkness
First performed:** July 10, 1971 (Lincroft, NJ)
**Last performed:** February 4, 1972 (Richmond, VA)