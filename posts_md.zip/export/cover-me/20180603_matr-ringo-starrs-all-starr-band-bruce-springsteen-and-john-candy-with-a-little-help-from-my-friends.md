# MatR: Ringo Starr's All Starr Band and Bruce Springsteen: With a Little Help from My Friends
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/06/03/matr-ringo-starrs-all-starr-band-bruce-springsteen-and-john-candy-with-a-little-help-from-my-friends/
#### Published: June 03, 2018
#### Last Updated: November 30, 2020
![littlehelp.jpg](https://estreetshuffle.com/wp-content/uploads/2018/06/littlehelp.jpg)

Back in April, I shared Bruce’s 1989 guest appearance with Ringo Starr’s All Star Band at the Garden State Arts Center, where Bruce joined the band for “[Photograph](http://estreetshuffle.com/index.php/2018/04/29/matr-bruce-springsteen-and-ringo-starr-and-his-all-starr-band-photograph/).”
Bruce was actually on stage for four songs that night, and “Photograph” was followed by a final encore of “[With a Little Help From My Friends](https://estreetshuffle.com/index.php/2018/06/03/matr-ringo-starrs-all-starr-band-bruce-springsteen-and-john-candy-with-a-little-help-from-my-friends/).” Bruce is on guitar only on this one, no vocals, but his contribution is easy to pick out.
[Youtube: Ringo Starr's All Starr Band and Bruce Springsteen - "With a Little Help From My Friends"](https://www.youtube.com/watch?v=vqMxTWqVoYM)
![](https://www.youtube.com/watch?v=vqMxTWqVoYM)
Bruce did indeed have friends on stage that night: with the E Street Band on hiatus (not yet officially broken up), Nils and Clarence had joined up with Ringo, so it was a treat for fans to see Bruce reunite with them on stage at the Garden State Arts Center.
The original song, of course, was one of The Beatles’ rare singles with Ringo on lead vocals. Released in the spring of 1967 on *Sgt. Pepper’s Lonely Hearts Club Band*, the song also provided a hit single for Joe Cocker the following year.
[Youtube: With A Little Help From My Friends (Remastered 2009)](https://www.youtube.com/watch?v=0C58ttB2-Qg)
![](https://www.youtube.com/watch?v=0C58ttB2-Qg)
**With a Little Help From My Friends
First performed:** September 30, 1967 (Freehold, NJ)
**Last performed:** August 11, 1989 (Holmdel, NJ)