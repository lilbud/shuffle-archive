# Cover Me, Stanley Clarke Band: Born in the U.S.A.
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/04/21/cover-me-stanley-clarke-band-born-in-the-usa/
#### Published: April 21, 2018
#### Last Updated: November 26, 2019
![bitusa-e1523574448418.jpg](https://estreetshuffle.com/wp-content/uploads/2018/04/bitusa-e1523574448418.jpg)

When it comes to covering Bruce’s songs, I often say: you either need to out-perform the original artists (a tough feat) or else deliver an arrangement that he’d never try himself.
Bassist Stanley Clarke and his band definitely took the latter route. From their 1985 *Find Out!* album, check out their unique take on “[Born in the U.S.A.](http://estreetshuffle.com/index.php/2019/09/21/roll-of-the-dice-born-in-the-u-s-a/)”
[Youtube: Stanley Clarke Band - Born In The U.S.A.](https://www.youtube.com/watch?v=zgGtViqj-ps)
![](https://www.youtube.com/watch?v=zgGtViqj-ps)