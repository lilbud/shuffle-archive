# Cover Me: Wooly Bully
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/31/cover-me-woolly-bully/
#### Published: March 31, 2018
#### Last Updated: June 29, 2019
![wooly.jpg](https://estreetshuffle.com/wp-content/uploads/2018/03/wooly.jpg)

“Wooly Bully” is a rock/Tex-Mex hybrid released in 1964 by novelty act Sam the Sham and the Pharoahs. It became a massive hit the following year, earning Billboard Magazine’s Number One Record of the Year distinction.
Bruce has covered it sixteen times over the years, unsurprisingly since he once proclaimed that “any bar band worth its salt has got to know this one.” Here’s what I think is their best take, from Tacoma in 1984.
[https://videopress.com/embed/Fh9LVVK3?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata](https://videopress.com/embed/Fh9LVVK3?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata)
Bonus footage: check out this high-quality video from the original artists.
[Youtube: Wooly Bully Sam Sham Pharaohs ReProCut Video JAR-ReMix HiQ Hybrid JARichardsFilm](https://www.youtube.com/watch?v=BcU3b_OfGrs)
![](https://www.youtube.com/watch?v=BcU3b_OfGrs)
**Wooly Bully
First performed:** September 19, 1982 (Asbury Park, NJ)
**Last performed:** May 8, 2009 (University Park, PA)