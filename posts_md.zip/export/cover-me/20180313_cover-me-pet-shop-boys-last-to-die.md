# Cover Me, Pet Shop Boys: Last to Die
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/13/cover-me-pet-shop-boys-last-to-die/
#### Published: March 13, 2018
#### Last Updated: December 28, 2022
![psbelectricb.jpg](https://estreetshuffle.com/wp-content/uploads/2018/03/psbelectricb.jpg)

Another contender for “least likely Springsteen cover:”
The Pet Shop Boys’ version of “Last to Die” retains the surreal, late-night driving feel of the original and makes it danceable. That’s actually an impressive feat.
[Youtube: Pet Shop Boys - The Last To Die (Audio)](https://www.youtube.com/watch?v=__RdJtpmIZE)
![](https://www.youtube.com/watch?v=__RdJtpmIZE)