# Cover Me, Tina Turner: Dancing in the Dark
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/06/05/cover-me-tina-turner-dancing-in-the-dark/
#### Published: June 05, 2018
#### Last Updated: December 28, 2022
![Tina-Turner-Live-in-Tokyo-1985-TSP-103-front-e1522904668626.jpg](https://estreetshuffle.com/wp-content/uploads/2018/04/Tina-Turner-Live-in-Tokyo-1985-TSP-103-front-e1522904668626.jpg)

In 1985, Bruce and Tina Turner were both at the height of their superstar popularity. So it must have been a thrill if you were one of the lucky ones to see Tina cover Bruce’s greatest hit. From her Tokyo concert on December 28, 1985, here’s Tina Turner performing “[Dancing in the Dark.](https://estreetshuffle.com/index.php/2021/12/25/roll-of-the-dice-dancing-in-the-dark/)”
[Youtube: Tina Turner  Dancing In The Dark](https://www.youtube.com/watch?v=INKwtDSC2gY)
![](https://www.youtube.com/watch?v=INKwtDSC2gY)