# MatR: Bob Dylan, Bruce Springsteen, and Neil Young: Rainy Day Women #12 & 35
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2020/01/29/matr-bob-dylan-bruce-springsteen-and-neil-young-rainy-day-women-12-35/
#### Published: January 29, 2020
#### Last Updated: January 29, 2020
![bob-dylan-rainy-day-women-12-and-35-cbs.jpg](https://estreetshuffle.com/wp-content/uploads/2020/01/bob-dylan-rainy-day-women-12-and-35-cbs.jpg)

Loose, sloppy, and raucous, Bob Dylan’s “Rainy Day Women #12 & 35” improbably rose to the top of the charts when it was released as a single in the spring of 1966, stopping just shy of the number one spot.
Maybe it was the song’s infectious and pervasive sense of fun that carried it so high, but the controversial “Everybody must get stoned” chorus probably had a lot to do with it, too.
[Youtube: Bob Dylan - Rainy Day Women #12 & 35 (Official Audio)](https://www.youtube.com/watch?v=fm-po_FUmvM)
![](https://www.youtube.com/watch?v=fm-po_FUmvM)
Regardless, “Rainy Day Women” has become one of Dylan’s best-known songs and is often featured in his set lists.
Case in point: Dylan’s show at the Roseland Ballroom in New York City on October 20, 1994.
Dylan broke out “Rainy Day Women” during his third encore, and he invited a couple of guests to join him on stage for it. You won’t hear their voices below (which is just as well, because it would be jarring to hear the famously anti-drug Springsteen calling for everyone to get stoned), but you’ll hear their guitars–here’s Bob Dylan backed by Neil Young and Bruce Springsteen on “Rainy Day Women #12 & 35,” Bruce’s only known performance of the song.
[Youtube: Bob Dylan - Rainy Day Women #12 & 35 with Bruce Springsteen and Neil Young 1994](https://www.youtube.com/watch?v=s3-uk7pmEFI)
![](https://www.youtube.com/watch?v=s3-uk7pmEFI)
**Rainy Day Women #12 & 35
First performed:** October 20, 1994 (New York City, NY)
**Last performed:** October 20, 1994 (New York City, NY)