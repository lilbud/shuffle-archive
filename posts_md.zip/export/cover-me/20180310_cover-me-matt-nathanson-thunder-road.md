# Cover Me, Matt Nathanson: Thunder Road
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/10/cover-me-matt-nathanson-thunder-road/
#### Published: March 10, 2018
#### Last Updated: March 09, 2018
![nathanson.jpg](https://estreetshuffle.com/wp-content/uploads/2018/03/nathanson.jpg)

Matt Nathanson is a great singer/songwriter and performer. He also likes to cover Bruce–a lot.
Here’s one of his favorites.
[Youtube: Matt Nathanson-Thunder Road-Live At Camp Krim 8/14/14](https://www.youtube.com/watch?v=6y6icFp8zqk)
![](https://www.youtube.com/watch?v=6y6icFp8zqk)