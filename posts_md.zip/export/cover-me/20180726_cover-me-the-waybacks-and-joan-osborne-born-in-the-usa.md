# Cover Me, The Waybacks and Joan Osborne: Born in the U.S.A.
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/07/26/cover-me-the-waybacks-and-joan-osborne-born-in-the-usa/
#### Published: July 26, 2018
#### Last Updated: December 01, 2020
![DMwaybacks-e1532388031468.jpg](https://estreetshuffle.com/wp-content/uploads/2018/07/DMwaybacks-e1532388031468.jpg)

When I shared Joan Osborne and The Waybacks’ [cover of “I’m Goin’ Down”](http://estreetshuffle.com/index.php/2018/05/15/cover-me-joan-osborne-and-the-waybacks-im-goin-down/) a few months ago, I promised it wouldn’t be the last time I dip into this absolutely fantastic album.
So here’s another reinvention of a classic Springsteen song, from a concert album full of them. *This* is how you put your own spin on another artist’s song. Check out their version of “[Born in the U.S.A.](https://estreetshuffle.com/index.php/2019/09/21/roll-of-the-dice-born-in-the-u-s-a/)”
[Youtube: Born in the USA](https://www.youtube.com/watch?v=m5SHAY3nAjE)
![](https://www.youtube.com/watch?v=m5SHAY3nAjE)