# Cover Me, Joe Cocker: Human Touch
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/02/07/cover-me-joe-cocker-human-touch/
#### Published: February 07, 2018
#### Last Updated: November 25, 2019
![humantouch.jpg](https://estreetshuffle.com/wp-content/uploads/2018/02/humantouch.jpg)

I’ve always thought “[Human Touch](http://estreetshuffle.com/index.php/2019/08/09/roll-of-the-dice-human-touch/)” cried out for an acoustic arrangement, but surprisingly, Bruce has never tried it (in public, at least).
Joe Cocker shows us how it’s done–turning in a cool, understated, almost swinging take on the song.
It’s a keeper.
[Youtube: Joe Cocker - Human Touch (1996)](https://www.youtube.com/watch?v=jWp5sXWmMCY)
![](https://www.youtube.com/watch?v=jWp5sXWmMCY)