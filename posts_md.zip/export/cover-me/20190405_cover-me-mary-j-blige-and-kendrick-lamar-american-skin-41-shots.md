# Cover Me, Mary J. Blige and Kendrick Lamar: American Skin (41 Shots)
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/04/05/cover-me-mary-j-blige-and-kendrick-lamar-american-skin-41-shots/
#### Published: April 05, 2019
#### Last Updated: January 01, 2024
![maryblige.jpg](https://estreetshuffle.com/wp-content/uploads/2019/04/maryblige.jpg)

Back in September 2016, when the U.S. presidential election was coming down to the home stretch (wow, that seems like so long ago), Mary J. Blige debuted a new show on Apple Music called *The 411 with Mary J. Blige.*
The debut episode featured presidential candidate and former Secretary of State Hillary Clinton as Blige’s guest, and during the episode (and in the trailer below), while discussing police brutality Blige spontaneously sings a verse from Bruce’s “American Skin (41 Shots)” to Secretary Clinton:
[Youtube: Mary J Blige sings to Hillary Clinton](https://www.youtube.com/watch?v=GvDjV9cly9Q)
![](https://www.youtube.com/watch?v=GvDjV9cly9Q)
At least, we *thought* it was spontaneous at the time.
Turns out that Blige had already recorded a full cover of the song with the help of rapper Kendrick Lamar, and she released it as a single not even a month later.
If you haven’t heard it before, trust me: you need to. It’s magnificent, even more powerful than Bruce’s original version:
[http://estreetshuffle.com/wp-content/uploads/2019/04/mary-j-blige-American-Skin-41-Shots-feat.-Kendrick-Lamar-1.mp3?_=2](http://estreetshuffle.com/wp-content/uploads/2019/04/mary-j-blige-American-Skin-41-Shots-feat.-Kendrick-Lamar-1.mp3?_=2)
<http://estreetshuffle.com/wp-content/uploads/2019/04/mary-j-blige-American-Skin-41-Shots-feat.-Kendrick-Lamar-1.mp3>
Lamar’s additional lyrics add heightened resonance, and I’m sure Bruce approves–he’s always been one to adapt, reinvent, and rewrite when covering other artists.
In case they fly by a bit too quickly to fully appreciate, here are Lamar’s lyrics:
*If I die right before I wake*
*Cross my heart, then I seal my fate*
*Life in the dark of the heartless*
*Looking at the remedy for all this*
*Everyday they look at you a target*
*Falling victim, them and*
*Him and her then this one, insensitivity*
*Talk bad religion, skin identity*
*Lack rash decision made by yours*
*Pack facility with the urban boy*
*Gun admitted he bear arm*
*The entity, arm and leg and head made to destroy*
*80% of the victim was yours*
*Maybe I get to relive years of war*
*Look on the corner, we been here before*
*Look at the momma, you seen tears before?*
*Pain bright and early*
*Rain, sleet, hail, snow, worry*
*More storm barricade the city*
*Prosecution, unhung jury*
*These days murder keep ’em busy*
*Sweet blood flowed on the gurney*
*Yellow tape tied around the street*
*Colin Kaepernick was more than worthy*
*I could reverse the day, reverse the time*
*Reverse the block, reverse the gun, reverse the shot*
*Reverse the law, reverse the flaw*
*That made us all the versions of a danger flock*
*Reverse the love, reverse the hate*
*Reverse the hope, reverse the way we playing sin*
*Reverse the moment, so we can live again*
*Life and times of the American skin*