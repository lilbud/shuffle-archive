# Cover Me, Town Bike: Radio Nowhere
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/01/31/cover-me-town-bike-radio-nowhere/
#### Published: January 31, 2019
#### Last Updated: December 16, 2021
![townbike.jpg](https://estreetshuffle.com/wp-content/uploads/2019/01/townbike.jpg)

C’mon, admit it: who among us hasn’t wondered what it would sound like if The Ramones and The Go-Gos teamed up to cover “[Radio Nowhere](https://estreetshuffle.com/index.php/2021/08/01/roll-of-the-dice-radio-nowhere/)?”
Well, wonder no longer. because this delightful cover by Liverpool band Town Bike is pretty much exactly that. And I love it so much!
[Youtube: Radio Nowhere (Springsteen cover) - Town bike](https://www.youtube.com/watch?v=lEZj_4tlDSA)
![](https://www.youtube.com/watch?v=lEZj_4tlDSA)
Kudos to Town Bike for realizing that “Radio Nowhere” was always a punk rocker at heart.