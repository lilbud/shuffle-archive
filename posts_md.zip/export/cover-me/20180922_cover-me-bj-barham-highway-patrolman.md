# Cover Me, BJ Barham: Highway Patrolman
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/09/22/cover-me-bj-barham-highway-patrolman/
#### Published: September 22, 2018
#### Last Updated: December 13, 2021
![bj-bruce-1240x1240-e1537312346329.jpg](https://estreetshuffle.com/wp-content/uploads/2018/09/bj-bruce-1240x1240-e1537312346329.jpg)

Reviewers have drawn comparisons between Bruce and North Carolina-based American Aquarium, so it’s not surprising to learn that lead singer BJ Barham considers Bruce to be “the greatest American songwriter we’ve ever seen.”
His band covers Bruce frequently in concert, but here’s a rare pro-shot solo performance–a spare but atmospheric take of “Highway Patrolman.”
[Youtube: BJ Barham - Highway Patrolman](https://www.youtube.com/watch?v=cRoNe0pFrrk)
![](https://www.youtube.com/watch?v=cRoNe0pFrrk)