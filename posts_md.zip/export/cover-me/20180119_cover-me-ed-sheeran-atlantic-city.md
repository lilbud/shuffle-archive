# Cover Me, Ed Sheeran: Atlantic City
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/01/19/cover-me-ed-sheeran-atlantic-city/
#### Published: January 19, 2018
#### Last Updated: March 09, 2019
![sheeran.jpg](https://estreetshuffle.com/wp-content/uploads/2018/01/sheeran.jpg)

Ed Sheeran hails from pretty far away from [Atlantic City](http://estreetshuffle.com/index.php/2018/06/04/roll-of-the-dice-atlantic-city/), but that doesn’t stop him from turning in a wonderfully faithful acoustic cover of Bruce’s *Nebraska* classic.
[Youtube: Ed Sheeran covers Bruce Springsteen [Atlantic City]](https://www.youtube.com/watch?v=tXGqhViirVE)
![](https://www.youtube.com/watch?v=tXGqhViirVE)