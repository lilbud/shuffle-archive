# Cover Me, Vampire Weekend: I'm Goin' Down
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/08/01/cover-me-vampire-weekend-im-goin-down/
#### Published: August 01, 2018
#### Last Updated: December 12, 2021
![vampire-e1533054368772.jpg](https://estreetshuffle.com/wp-content/uploads/2018/08/vampire-e1533054368772.jpg)

At a Vancouver concert in 2010, Vampire Weekend delighted fans with a cover of Bruce’s “I’m Goin’ Down.”
Just after they premiered it in Vancouver, the band made a special stop to play an acoustic set for Seattle radio station 107.7 The End before their show in Redmond’s Marymoor Park.
Fortunately, “[I’m Goin’ Down](https://estreetshuffle.com/index.php/2021/06/05/roll-of-the-dice-im-goin-down/)” was on the setlist, so we now have a wonderfully shot and recorded acoustic rendition to enjoy.
[Youtube: Vampire Weekend "I'm Going Down" Acoustic Springsteen Cover](https://www.youtube.com/watch?v=CZUMEIHLwGs)
![](https://www.youtube.com/watch?v=CZUMEIHLwGs)
The band continued to perform “I’m Goin’ Down” through the rest of the summer and early fall, but it doesn’t appear to have made their setlist since.