# Cover Me, Kirk Kelly: Downbound Train
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/08/02/cover-me-kirk-kelly-downbound-train/
#### Published: August 02, 2019
#### Last Updated: August 01, 2019
![LOD.jpg](https://estreetshuffle.com/wp-content/uploads/2019/08/LOD.jpg)

More than fifteen years before *Born to Uke,* Kirk Kelly gave Bruce’s “[Downbound Train](http://estreetshuffle.com/index.php/2019/01/22/roll-of-the-dice-downbound-train/)” the ukulele treatment.
Paring the song down and stripping it of all ornamentation, Kirk transforms “Downbound Train.” It’s no longer cinematic, but it’s every bit as powerful–Bruce’s narrator now sounds defeated, disturbed, and stuck in his own head. It’s an eerie effect.
[Youtube: Downbound Train](https://www.youtube.com/watch?v=R9HakNjZln8)
![](https://www.youtube.com/watch?v=R9HakNjZln8)
You can find Kelly’s cover of “Downbound Train” on the 2003 tribute album, *Light of Day*.