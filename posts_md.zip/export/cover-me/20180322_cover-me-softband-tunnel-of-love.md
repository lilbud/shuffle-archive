# Cover Me, Softband: Tunnel of Love
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/22/cover-me-softband-tunnel-of-love/
#### Published: March 22, 2018
#### Last Updated: December 12, 2021
![tolsoft.jpg](https://estreetshuffle.com/wp-content/uploads/2018/03/tolsoft.jpg)

I don’t know anything about this band (and couldn’t find any info on-line), but I adore this acoustic cover of “[Tunnel of Love](https://estreetshuffle.com/index.php/2021/06/15/roll-of-the-dice-tunnel-of-love/).” If you know anything about them, please drop me a note.
[Youtube: Tunnel Of Love](https://www.youtube.com/watch?v=tUroxzwQEZc)
![](https://www.youtube.com/watch?v=tUroxzwQEZc)