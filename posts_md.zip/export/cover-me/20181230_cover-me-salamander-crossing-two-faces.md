# Cover Me, Salamander Crossing: Two Faces
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/12/30/cover-me-salamander-crossing-two-faces/
#### Published: December 30, 2018
#### Last Updated: January 01, 2023
![salamander.jpg](https://estreetshuffle.com/wp-content/uploads/2018/12/salamander.jpg)

I’m a sucker for obscure Bruce covers and unusual arrangements; Salamander Crossing checked both boxes with their bluegrass rendition of “[Two Faces](https://estreetshuffle.com/index.php/2022/05/26/roll-of-the-dice-two-faces/)” on their 1996 album *Passion Train.*
The band isn’t around anymore, but their career retrospective album (which includes “Two Faces”) is still in print.
[Youtube: Two Faces](https://www.youtube.com/watch?v=A0YjFdOuSQ4)
![](https://www.youtube.com/watch?v=A0YjFdOuSQ4)