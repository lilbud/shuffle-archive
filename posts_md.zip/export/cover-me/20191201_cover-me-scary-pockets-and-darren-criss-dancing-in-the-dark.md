# Cover Me, Scary Pockets and Darren Criss: Dancing in the Dark
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/12/01/cover-me-scary-pockets-and-darren-criss-dancing-in-the-dark/
#### Published: December 01, 2019
#### Last Updated: January 01, 2023
![scarypockets.jpg](https://estreetshuffle.com/wp-content/uploads/2019/12/scarypockets.jpg)

If you haven’t discovered Scary Pockets yet, check out their [YouTube channel](https://www.youtube.com/channel/UC-2JUs_G21BrJ0efehwGkUw/videos?view=0&sort=dd&shelf_id=0) and prepared to be hooked.
The Los Angeles-based funk band releases new music videos weekly, usually a reinterpretation of a classic song featuring some phenomenal guest vocalists.
Last week’s release featured the multi-talented Darren Criss at the microphone, with what is easily one of the best covers of “[Dancing in the Dark](https://estreetshuffle.com/index.php/2021/12/25/roll-of-the-dice-dancing-in-the-dark/)” yet.
I know I’ve been going to the “Dancing in the Dark” well pretty often of late, but trust me: watch this one.
Oh, and wait for it…
[Youtube: Dancing in the Dark | Bruce Springsteen | funk cover ft. Darren Criss](https://www.youtube.com/watch?v=b5rySSphFO0)
![](https://www.youtube.com/watch?v=b5rySSphFO0)