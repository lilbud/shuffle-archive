# Cover Me, Babyface and Des'ree: Fire
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/04/26/cover-me-babyface-and-desree-fire/
#### Published: April 26, 2018
#### Last Updated: November 27, 2020
![fire-e1523641410776.jpg](https://estreetshuffle.com/wp-content/uploads/2018/04/fire-e1523641410776.jpg)

From the 1998 film *Hav Plenty*, Babyface and Des’ree take Bruce’s already sultry “[Fire](https://estreetshuffle.com/index.php/2020/08/05/roll-of-the-dice-fire/)” and turn it up a notch.
[Youtube: Fire](https://www.youtube.com/watch?v=xd6qT0GTPPg)
![](https://www.youtube.com/watch?v=xd6qT0GTPPg)