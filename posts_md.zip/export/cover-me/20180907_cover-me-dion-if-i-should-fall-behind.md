# Cover Me, Dion: If I Should Fall Behind
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/09/07/cover-me-dion-if-i-should-fall-behind/
#### Published: September 07, 2018
#### Last Updated: September 07, 2018
![diondimucci_dreamonfire.jpg](https://estreetshuffle.com/wp-content/uploads/2018/09/diondimucci_dreamonfire.jpg)

“[If I Should Fall Behind](http://estreetshuffle.com/index.php/2018/06/01/roll-of-the-dice-if-i-should-fall-behind/)” is one of Bruce’s loveliest and most versatile ballads. Bruce has treated us to many interpretations since its 1992 debut, so it’s unsurprising that its beauty and malleability would attract other artists to cover it as well.
One of the best covers of “If I Should Fall Behind” is also the very first: Dion DiMucci (of Dion and the Belmonts) included it as the lead-off track on his *Dream on Fire* album, released mere months after Bruce’s original debuted on *Lucky Town*.
Dion gave it his signature doo-wop treatment, and the result is so perfect that if you didn’t know better, you’d think it was first written and recorded in the 1950s instead of the 1990s.
[Youtube: Dion - If I Should Fall Behind](https://www.youtube.com/watch?v=TBGO_OBp9y8)
![](https://www.youtube.com/watch?v=TBGO_OBp9y8)
**Bonus:**
Dion and Bruce performed “If I Should Fall Behind” together a couple of times. Here’s the first, from The Ghost of Tom Joad Tour, in Sunrise, Florida.
[Youtube: Bruce Springsteen and Dion, "If I Should Fall Behind" - Sunrise, FL, 1996-12-02](https://www.youtube.com/watch?v=Pi5wsCgXMhw)
![](https://www.youtube.com/watch?v=Pi5wsCgXMhw)