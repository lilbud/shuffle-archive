# Cover Me: Come On, Let's Go
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/10/19/cover-me-come-on-lets-go/
#### Published: October 19, 2018
#### Last Updated: October 15, 2018
![ritchie-valens-come-on-lets-go-london-2.jpg](https://estreetshuffle.com/wp-content/uploads/2018/10/ritchie-valens-come-on-lets-go-london-2.jpg)

Rock and roll singer/songwriter Ritchie Valens’ life and career were both cut tragically short: he died at the age of seventeen not even a year into his recording career, in a plane crash that also took the lives of Buddy Holly and J.P. Richardson.
Those few months were productive, though–Valens charted three bona fide and enduring hits in the second half of 1958, “Donna,” “La Bamba,” and his very first single, “Come On, Let’s Go.”
[Youtube: Come On Let’s Go](https://www.youtube.com/watch?v=2PRvejWMWl4)
![](https://www.youtube.com/watch?v=2PRvejWMWl4)
Bruce has performed it live nine times, but even the longest and most fervent of fans would be forgiven for having never caught it, because all nine of those times we unannounced bar performances, eight of them in 1982 (all but one with Cats on a Smooth Surface at The Stone Pony, plus a Beaver Brown team-up at Big Man’s West), and the last was in the summer of 1987–one again at the The Stone Pony, this time with both the E Street Band and Cats on a Smooth Surface.
A couple of these performances have been floating around youtube for a while, but none of them are very listenable.
So here’s a treat: a newly uploaded, wonderfully clear recording of Bruce and Cats on a Smooth Surface performing Valens’ first hit at The Stone Pony, on June 27, 1982.
[Youtube: Bruce Springsteen & Cats on a Smooth Surface - "Come On, Let's Go" - Stone Pony, 1982-06-27](https://www.youtube.com/watch?v=oSf8JYKOCXo)
![](https://www.youtube.com/watch?v=oSf8JYKOCXo)
**Come On, Let’s** **Go**
**First performed:** June 20, 1982 (Asbury Park)
**Last performed:** August 2, 1987 (Asbury Park)