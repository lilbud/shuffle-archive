# Cover Me, Marshall Crenshaw: All or Nothin' at All
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/01/23/cover-me-marshall-crenshaw-all-or-nothin-at-all/
#### Published: January 23, 2019
#### Last Updated: January 23, 2019
![bsides.jpg](https://estreetshuffle.com/wp-content/uploads/2019/01/bsides.jpg)

Dare I say it? Dare I do:
In my humble opinion, Marshall Crenshaw’s cover of “[All or Nothin’ at All](http://estreetshuffle.com/index.php/2018/01/30/roll-of-the-dice-all-or-nothing-at-all/)” is stronger than Bruce’s tragically overlooked *Human Touch* track.
Crenshaw wisely hews closely to the album arrangement–it’s perfectly suited for his style–but if he doesn’t bring anything new to the table, he definitely brings his A-game. Turn it up!
[Youtube: Marshall Crenshaw - All or Nothin' At All](https://www.youtube.com/watch?v=FzYHw9PwZCU)
![](https://www.youtube.com/watch?v=FzYHw9PwZCU)
You can find Crenshaw’s cover of “All or Nothin’ at All” on the Springsteen tribute album *One Step Up* or on the Crenshaw bootleg *B-Sides and Unreleased*.