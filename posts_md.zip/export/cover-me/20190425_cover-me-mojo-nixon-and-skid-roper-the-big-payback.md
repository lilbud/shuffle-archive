# Cover Me, Mojo Nixon and Skid Roper: The Big Payback
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/04/25/cover-me-mojo-nixon-and-skid-roper-the-big-payback/
#### Published: April 25, 2019
#### Last Updated: January 01, 2023
![mojo.jpg](https://estreetshuffle.com/wp-content/uploads/2018/11/mojo.jpg)

Bonus Cover Me post today, since I totally had a brainfart and mis-attributed Greg Kin’s live cover of “[Rendezvous](https://estreetshuffle.com/index.php/2021/05/08/roll-of-the-dice-rendezvous/)” to John Eddie earlier. (That post has since been retracted, redirected, and merged with my post from last year about Kihn’s version of that song. My apologies–once in a while, the daily blog deadline combined with my day job get the better of me!)
I’m a sucker for covers of obscure Springsteen songs, and they don’t come much more obscure than “[The Big Payback](http://estreetshuffle.com/index.php/2018/11/11/roll-of-the-dice-the-big-payback/),” the B-side of an under-the-radar single, re-issued on a bonus disc of a limited-edition compilation.
But it’s a great song, and Mojo Nixon and Skid Roper did a terrific cover of it back in 1985, even if it’s just a *bit* over the top given the subject matter.
Check it out:
[Youtube: Big Payback](https://www.youtube.com/watch?v=3gFZQTaaAB8)
![](https://www.youtube.com/watch?v=3gFZQTaaAB8)