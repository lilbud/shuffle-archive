# Cover Me, Martina Linn: Tougher Than the Rest
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/02/15/cover-me-martina-linn-tougher-than-the-rest/
#### Published: February 15, 2018
#### Last Updated: November 26, 2020
![martina-linn_1.jpg](https://estreetshuffle.com/wp-content/uploads/2018/02/martina-linn_1.jpg)

Continuing our mini-theme for Valentine’s Week, here’s Swiss recording artist Martina Linn with a gorgeous acoustic cover of Bruce’s “[Tougher Than the Rest](https://estreetshuffle.com/index.php/2020/08/08/roll-of-the-dice-tougher-than-the-rest/).”
[Youtube: Martina Linn - «Tougher Than The Rest» (Springsteen-Cover) - SRF 3 Live Session](https://www.youtube.com/watch?v=49jqQvmQ86U)
![](https://www.youtube.com/watch?v=49jqQvmQ86U)