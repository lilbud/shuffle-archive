# Cover Me, Eddie Vedder: One Step Up
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/01/16/cover-me-eddie-vedder-one-step-up/
#### Published: January 16, 2018
#### Last Updated: August 17, 2018
![bad-radio.jpg](https://estreetshuffle.com/wp-content/uploads/2018/01/bad-radio.jpg)

Before Pearl Jam there was Bad Radio. They never released an album, but Bad Radio still has a claim to fame: their frontman was Eddie Vedder.
And even in his Bad Radio days, Eddie was a Springsteen fan. He recorded this lovely cover of “[One Step Up](http://estreetshuffle.com/index.php/2018/08/17/roll-of-the-dice-one-step-up/)” in a friend’s recording studio in Chicago sometime in the late 1980s.
[Youtube: One step up - EDDIE VEDDER (Bad radio)](https://www.youtube.com/watch?v=Ol1Q6aY9Xpw)
![](https://www.youtube.com/watch?v=Ol1Q6aY9Xpw)