# Cover Me, Nitty Gritty Dirt Band: Cadillac Ranch
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/02/26/cover-me-nitty-gritty-dirt-band-cadillac-ranch/
#### Published: February 26, 2018
#### Last Updated: November 26, 2020
![the-nitty-gritty-dirt-band-cadillac-ranch-warner-bros.jpg](https://estreetshuffle.com/wp-content/uploads/2018/02/the-nitty-gritty-dirt-band-cadillac-ranch-warner-bros.jpg)

“[Cadillac Ranch](https://estreetshuffle.com/index.php/2020/07/23/roll-of-the-dice-cadillac-ranch/)” was always rockabilly, so it shouldn’t be surprising that the Nitty Gritty Dirt Band covered it frequently in concert. They actually released live recordings of it twice, in 1984 and 1991.
Here’s the 1984 version…
[Youtube: Nitty Gritty Dirt Band - Cadillac Ranch.](https://www.youtube.com/watch?v=OMZAKaLR-yM)
![](https://www.youtube.com/watch?v=OMZAKaLR-yM)
…and as a bonus, here they are still performing it in 2011. Like Bruce, they’re better with age!
[Youtube: Nitty Gritty Dirt Band - Cadillac Ranch (Live)](https://www.youtube.com/watch?v=F7svzn-5vUg)
![](https://www.youtube.com/watch?v=F7svzn-5vUg)