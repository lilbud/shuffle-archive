# Cover Me, Mumford and Sons: I'm on Fire
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/10/06/cover-me-mumford-and-sons-im-on-fire/
#### Published: October 06, 2019
#### Last Updated: December 19, 2021
![mumford.jpg](https://estreetshuffle.com/wp-content/uploads/2019/10/mumford.jpg)

I really tried to put some more space between “[I’m on Fire](https://estreetshuffle.com/index.php/2021/09/11/roll-of-the-dice-im-on-fire/)” covers, but then this one popped up on YouTube a week ago and suddenly I’m off the wagon.
And yes, I know that Mumford & Sons have been covering “I’m on Fire” for years, and yes I know that many of those performances were captured on video in pretty great quality.
But in my opinion, this one stands head and shoulders above the others:
[Youtube: Mumford & Sons - I'm On Fire (Bruce Springsteen Cover) [LIVE @ The Stephen Talkhouse]](https://www.youtube.com/watch?v=4gKNLeBtXy0)
![](https://www.youtube.com/watch?v=4gKNLeBtXy0)
The band absolutely *nails* the pacing and the temperature, keeping the song at a slowly building simmer until it explodes before closing on a quietly sinister note.
Honestly, I’m not a huge Mumford & Sons fan, but this particular performance of “I’m on Fire” has immediately become one of my favorites among a sea of covers of this particular song.