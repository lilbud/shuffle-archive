# Cover Me, My Morning Jacket: Hungry Heart
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/10/08/cover-me-my-morning-jacket-hungry-heart/
#### Published: October 08, 2018
#### Last Updated: January 01, 2023
![hungry-2-e1538627136925.jpg](https://estreetshuffle.com/wp-content/uploads/2018/10/hungry-2-e1538627136925.jpg)

Days before their appearance at a Hurricane Sandy relief concert in Asbury Park, My Morning Jacket premiered their note-perfect cover of “[Hungry Heart](https://estreetshuffle.com/index.php/2022/12/21/roll-of-the-dice-hungry-heart/)” at their New Year’s Eve show in Boston. (They played it in AP, too.)
It’s a wonderfully faithful cover without a trace of irony or self-consciousness. There’s even a horn section.
I’m pretty certain Bruce would approve.
[Youtube: Hungry Heart - My Morning Jacket (Bruce Springsteen Cover)  *soundboard audio*](https://www.youtube.com/watch?v=J8YnAqa1hbA)
![](https://www.youtube.com/watch?v=J8YnAqa1hbA)