# Cover Me: "Take It Easy"
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/01/18/cover-me-take-it-easy/
#### Published: January 18, 2018
#### Last Updated: December 12, 2021
![eagles.jpg](https://estreetshuffle.com/wp-content/uploads/2018/01/eagles.jpg)

Another great one gone too soon: Bruce Springsteen pays tribute to Glenn Frey, one day following his death on January 18, 2016.
[Youtube: Bruce Springsteen - Take It Easy](https://www.youtube.com/watch?v=U0i7CFQHEtI)
![](https://www.youtube.com/watch?v=U0i7CFQHEtI)
“Take it Easy” was actually co-written by both Glenn Frey and Jackson Browne, and both The Eagles and Browne recorded it. The Eagles version came out first–it was, in fact, the band’s first single, released in 1972 and peaking at #12 on the Hot 100.
[Youtube: Take It Easy (2013 Remaster)](https://www.youtube.com/watch?v=4v8KEbQA8kw)
![](https://www.youtube.com/watch?v=4v8KEbQA8kw)
**Take It Easy
First performed:** March 16, 2004 (New York City, NY)
**Last performed:** September 21, 2017 (Holmdel, NJ)