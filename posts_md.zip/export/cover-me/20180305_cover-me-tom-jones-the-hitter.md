# Cover Me, Tom Jones: The Hitter
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/05/cover-me-tom-jones-the-hitter/
#### Published: March 05, 2018
#### Last Updated: December 12, 2021
![tomjones.jpg](https://estreetshuffle.com/wp-content/uploads/2018/03/tomjones.jpg)

One of the most unexpected Bruce covers is an absolute must-listen: Tom Jones completely reinvents “The Hitter” in a smoldering interpretation.
Jones’ take on the song’s protagonist is unapologetic–he owns his deeds and wraps himself in his sins, and the result is a very different song than Bruce’s original.
[Youtube: The Hitter](https://www.youtube.com/watch?v=xCHeGoHGZkc)
![](https://www.youtube.com/watch?v=xCHeGoHGZkc)