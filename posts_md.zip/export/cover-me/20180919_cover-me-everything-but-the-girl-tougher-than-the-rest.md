# Cover Me, Everything But the Girl: Tougher Than the Rest
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/09/19/cover-me-everything-but-the-girl-tougher-than-the-rest/
#### Published: September 19, 2018
#### Last Updated: December 03, 2020
![ebtg.jpg](https://estreetshuffle.com/wp-content/uploads/2018/09/ebtg.jpg)

This is probably my all-time favorite Bruce cover.
I’ve been in love with Tracey Thorn’s voice since I first discovered Everything But the Girl’s *Idlewild* album while perusing my college radio station’s album library one day before my weekly show. By the time I got to “I Always Was Your Girl,” I was hooked but good.
Tracey’s voice is more than beautiful–it’s also layered with an amazing range of emotion and subtext beneath the lyrics of any song she embraces.
So when EBTG released their *Acoustic* CD, including a cover of Bruce’s “[Tougher Than the Rest,](https://estreetshuffle.com/index.php/2020/08/08/roll-of-the-dice-tougher-than-the-rest/)” I knew before I even heard it that it was going to be a keeper.
She definitely groks the song:
*“Its narrative says true toughness is nothing to do with being macho, but is all about loyalty, and emotional maturity; being able to see that ‘the road is dark’ and giving reassurance that you’ll be able to cope with that. It’s a song in which the singer is honest about their own slightly shop-soiled weariness — ‘Well it ain’t no secret, I’ve been around a time or two’ — but suspects this quality might be understood and shared — ‘I don’t know babe, maybe you’ve been around too.’ This is an honest and open thing to say, and it takes strength to lay yourself bare like this. So ultimately, what the song says is that tough and vulnerable are the same thing.”*
I hope I have plenty of time before the dice turn up that song for me to write about, because I don’t know that I can say it any better than that.
Give a listen to this tender, acoustic interpretation of “Tougher Than the Rest.”
[Youtube: Tougher Than the Rest](https://www.youtube.com/watch?v=B_tIeud0xPo)
![](https://www.youtube.com/watch?v=B_tIeud0xPo)