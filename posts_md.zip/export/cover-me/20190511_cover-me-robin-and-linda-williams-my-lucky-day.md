# Cover Me, Robin and Linda Williams: My Lucky Day
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/05/11/cover-me-robin-and-linda-williams-my-lucky-day/
#### Published: May 11, 2019
#### Last Updated: December 11, 2020
![robinlindawilliams_theseolddarkhills.jpg](https://estreetshuffle.com/wp-content/uploads/2019/05/robinlindawilliams_theseolddarkhills.jpg)

“[My Lucky Day](http://estreetshuffle.com/index.php/2019/09/02/roll-of-the-dice-my-lucky-day/)” is way up there among my favorite 21st-century Springsteen songs. Since it debuted as the second single from *Working on a Dream* a full decade ago, it’s been a perennial on my setlist wish list.
But as much as I love the song, I’ve always felt that the tenderness of the lyrics was completely overpowered by force of the full-band arrangement.
And then I discovered this cover by husband-and-wife folk singers Robin and Linda Williams, and I’ll be darned: they fixed it.
Take a listen–if you’ve never given “My Lucky Day” much consideration before, you’re about to discover one of Bruce’s loveliest hidden love songs.
[Youtube: My Lucky Day](https://www.youtube.com/watch?v=X1GxAU8NLcs)
![](https://www.youtube.com/watch?v=X1GxAU8NLcs)