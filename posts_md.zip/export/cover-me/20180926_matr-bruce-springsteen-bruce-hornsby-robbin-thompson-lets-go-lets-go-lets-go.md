# MatR: Bruce Springsteen, Bruce Hornsby & Robbin Thompson, Let's Go, Let's Go, Let's Go
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/09/26/matr-bruce-springsteen-bruce-hornsby-robbin-thompson-lets-go-lets-go-lets-go/
#### Published: September 26, 2018
#### Last Updated: September 26, 2018
![letsgo-e1537330693338.jpg](https://estreetshuffle.com/wp-content/uploads/2018/09/letsgo-e1537330693338.jpg)

Hank Ballard was one of the founding fathers of rock and roll, releasing several hit songs in the early fifties and writing one of rock’s breakthrough hits, “The Twist” (made famous by Chubby Checker).
Bruce considered him an influence and an inspiration, and after Ballard passed away in early March 2003, Bruce paid tribute by covering Ballard’s greatest hit, “Let’s Go, Let’s Go, Let’s Go,” twice that week.
For the second performance in Richmond, Bruce brought two friends on stage to help him pay homage: Bruce Hornsby, and old Steel Mill bandmate Robbin Thompson. Here’s that performance:
[Youtube: Bruce Springsteen - "Let's Go, Let's Go, Let's Go" - 2003-03-06](https://www.youtube.com/watch?v=0R97Ohj_qdE)
![](https://www.youtube.com/watch?v=0R97Ohj_qdE)
“Let’s Go, Let’s Go, Let’s Go” peaked at number 6 on the charts. It was Ballard’s last and greatest hit.
[Youtube: Hank Ballard - Let's Go, Let's Go, Let's Go](https://www.youtube.com/watch?v=TYfnC4CgN-Y)
![](https://www.youtube.com/watch?v=TYfnC4CgN-Y)
**Let’s Go, Let’s Go, Let’s Go
First performed:** March 4, 2003 (Jacksonville, FL)
**Last performed:** March 6, 2003 (Richmond, VA)