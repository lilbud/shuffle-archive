# Cover Me, Sympathy and the Lion: Glory Days
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/01/15/cover-me-sympathy-and-the-lion-glory-days/
#### Published: January 15, 2019
#### Last Updated: January 15, 2019
![sympathy.jpg](https://estreetshuffle.com/wp-content/uploads/2019/01/sympathy.jpg)

My rule for covering Bruce: Be different or be great.
Sympathy and the Lion, a duo out of Lancaster, PA, does both.
Words can’t describe how much I love their cover of “Glory Days,” so just take a listen. I’ve never heard the song arranged like this before (or since).
[Youtube: Springsteen's "Glory Days" on piano by  Sympathy and the Lion](https://www.youtube.com/watch?v=FCGitYHpsLs)
![](https://www.youtube.com/watch?v=FCGitYHpsLs)
And just like that, an 80s arena showpiece is transformed into an intimate, aching, truly nostalgic ballad.
I think Bruce would approve.
Let’s hope we hear from these guys again.