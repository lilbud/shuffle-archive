# MatR: Joe Grushecky and Bruce Springsteen, "Lighten Up"
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/02/05/matr-joe-grushecky-and-bruce-springsteen-lighten-up/
#### Published: February 05, 2018
#### Last Updated: January 01, 2024
![lighten.jpg](https://estreetshuffle.com/wp-content/uploads/2018/02/lighten.jpg)

Today’s meeting across the river comes from the city of three rivers: Pittsburgh, PA.
For a brief time in 1995, Bruce Springsteen joined Joe Grushecky and the Houserockers, taking a supporting role during Joe’s [*American Babylon*](https://estreetshuffle.com/index.php/2020/10/17/american-babylon-a-retrospective/)tour. (Bruce produced the album, played and sang on several tracks, and wrote two of them.)
This audio clip is the final encore from the October 20, 1995 show at Nick’s Fat City, “Lighten Up” from Joe’s album, *End of the Century*. Bruce is on background vocals and guitar, but you can hear him clearly. The song starts about a minute in.
[http://estreetshuffle.com/wp-content/uploads/2018/02/208-Lighten-Up-online-audio-converter.com_.mp3?_=1](http://estreetshuffle.com/wp-content/uploads/2018/02/208-Lighten-Up-online-audio-converter.com_.mp3?_=1)
<http://estreetshuffle.com/wp-content/uploads/2018/02/208-Lighten-Up-online-audio-converter.com_.mp3>
Here’s the original for comparison.
[Youtube: Lighten Up](https://www.youtube.com/watch?v=hZdE37zkdiA)
![](https://www.youtube.com/watch?v=hZdE37zkdiA)