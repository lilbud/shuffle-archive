# Cover Me, John Hiatt: Johnny 99
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/02/19/cover-me-john-hiatt-johnny-99/
#### Published: February 19, 2018
#### Last Updated: November 26, 2020
![j99.jpg](https://estreetshuffle.com/wp-content/uploads/2018/02/j99.jpg)

John Hiatt gives us a sharp-edged, hard-driving take on Bruce’s “[Johnny 99](https://estreetshuffle.com/index.php/2020/07/20/roll-of-the-dice-johnny-99/).”
[Youtube: John Hiatt - Johnny 99](https://www.youtube.com/watch?v=jOE_5cbGNZw)
![](https://www.youtube.com/watch?v=jOE_5cbGNZw)