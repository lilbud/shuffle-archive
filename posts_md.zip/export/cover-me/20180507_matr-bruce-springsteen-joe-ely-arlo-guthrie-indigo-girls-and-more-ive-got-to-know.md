# MatR: Bruce Springsteen, Joe Ely, Arlo Guthrie, Indigo Girls, and more: I've Got to Know
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/05/07/matr-bruce-springsteen-joe-ely-arlo-guthrie-indigo-girls-and-more-ive-got-to-know/
#### Published: May 07, 2018
#### Last Updated: November 26, 2019
![290996-cleveland-photo-83a.jpg](https://estreetshuffle.com/wp-content/uploads/2018/05/290996-cleveland-photo-83a.jpg)

On September 29, 1996, Bruce joined a stellar roster of musicians on stage at Cleveland’s Severance Hall to pay tribute to Woody Guthrie.
Among the tracks performed that night: Woody’s “I’ve Got to Know,” featuring contributions by Bruce, Joe Ely, Arlo Guthrie, The Indigo Girls, Ani DiFranco, Billy Bragg, Country Joe McDonald, David Pirner, and Ramblin’ Jack Elliott.
This is the only time Bruce is known to have performed this song.
[Youtube: I've Got to Know - Bruce Springsteen and others, Cleveland, September 29 1996](https://www.youtube.com/watch?v=0G8dDlLkG7c)
![](https://www.youtube.com/watch?v=0G8dDlLkG7c)
Here’s the original for comparison:
[Youtube: I've Got to Know](https://www.youtube.com/watch?v=A_f1nlorvU0)
![](https://www.youtube.com/watch?v=A_f1nlorvU0)
**I’ve Got to Know**
**First performed:** September 29, 1996 (Cleveland, OH)
**Last performed:** September 29, 1996 (Cleveland, OH)