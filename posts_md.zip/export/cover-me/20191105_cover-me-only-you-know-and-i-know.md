# Cover Me: Only You Know and I Know
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/11/05/cover-me-only-you-know-and-i-know/
#### Published: November 05, 2019
#### Last Updated: November 05, 2019
![only-you-know.jpg](https://estreetshuffle.com/wp-content/uploads/2019/10/only-you-know.jpg)

“Only You Know and I Know” was Dave Mason’s first single to chart, stopping just shy of the Top 40 upon its release in the summer of 1970.
[Youtube: Dave Mason - Only You Know & I Know](https://www.youtube.com/watch?v=z4mcRpWAyRM)
![](https://www.youtube.com/watch?v=z4mcRpWAyRM)
Apparently #42 on the Billboard Hot 100 was high enough to catch the attention of a young Bruce Springsteen, however, because the following year, “Only You Know and I Know” turned up on the setlist of The Bruce Springsteen Band” during their residency at the Student Prince in Asbury Park.
Here’s their only known and captured performance (featuring an extended guitar jam almost as long as the original single) from the evening of December 11, 1971.
[https://videopress.com/embed/sHBamxhn?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata](https://videopress.com/embed/sHBamxhn?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata)
**Only You Know and I Know
First performed:** December 1971 (Asbury Park, NJ)
**Last performed:** December 1971 (Asbury Park, NJ)