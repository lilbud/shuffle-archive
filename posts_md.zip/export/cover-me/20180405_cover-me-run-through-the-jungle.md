# Cover Me: Run Through the Jungle
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/04/05/cover-me-run-through-the-jungle/
#### Published: April 05, 2018
#### Last Updated: December 12, 2021
![jungle.jpg](https://estreetshuffle.com/wp-content/uploads/2018/04/jungle.jpg)

Here’s a timely cover: Three times only, on the original River tour, Bruce and the E Street Band covered the classic CCR anti-gun polemic, “Run Through the Jungle.”
Bruce’s take on the song is quieter, slower and more taut than the original, with a mid-song key change to escalate the tension. If he performed it today, he’d have to update the lyrics, too–we’re at 300 million guns today and counting.
Here’s Bruce’s first of only three performances ever of “Run Through the Jungle.”
[Youtube: Bruce Springsteen - RUN THROUGH THE JUNGLE  1981 (audio)](https://www.youtube.com/watch?v=3XZjhZWbB34)
![](https://www.youtube.com/watch?v=3XZjhZWbB34)
Interestingly, Bruce’s version has extra verses, presumably written by him. Compare with the original Creedence Clearwater Revival version:
[Youtube: Creedence Clearwater Revival - Run Through The Jungle](https://www.youtube.com/watch?v=_7PUPNxsRQ0)
![](https://www.youtube.com/watch?v=_7PUPNxsRQ0)
A couple of those new lyrics would turn up later in the year in a new song Bruce was working on but was never released: “[Bells of San Salvador.](https://estreetshuffle.com/index.php/2021/02/02/roll-of-the-dice-bells-of-san-salvador/)”
But that’s a story for another time.
**Run Through the Jungle**
**First performed:** April 29, 1981 (Rotterdam, The Netherlands)
**Last performed:** May 8, 1981 (Stockholm, Sweden)