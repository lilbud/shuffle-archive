# Cover Me, Hot Chip: Dancing in the Dark
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/03/08/cover-me-hot-chip-dancing-in-the-dark/
#### Published: March 08, 2019
#### Last Updated: January 01, 2023
![Hot_Chip_-_Dancing_In_The_Dark_EP_600_600.jpg](https://estreetshuffle.com/wp-content/uploads/2019/03/Hot_Chip_-_Dancing_In_The_Dark_EP_600_600.jpg)

Just in case Bruce’s original video for “[Dancing in the Dark](https://estreetshuffle.com/index.php/2021/12/25/roll-of-the-dice-dancing-in-the-dark/)” isn’t eighties enough for you… well, sometimes its better to just let a clip speak for itself.
Here’s indie-EDM band Hot Chip’s take on Bruce’s greatest hit (with a little bit of LCD Soundsystem mashed in).
(Warning: Don’t be surprised if this sneaks up on you around two minute mark–and if you’re not dancing by the three minute mark, you’re probably not playing it loud enough.)
[Youtube: Hot Chip - Dancing In The Dark (Official Video)](https://www.youtube.com/watch?v=PyN_d28-sfw)
![](https://www.youtube.com/watch?v=PyN_d28-sfw)