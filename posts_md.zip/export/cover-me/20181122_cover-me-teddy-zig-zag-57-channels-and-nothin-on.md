# Cover Me, Teddy "Zig Zag": 57 Channels (And Nothin' On)
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/11/22/cover-me-teddy-zig-zag-57-channels-and-nothin-on/
#### Published: November 22, 2018
#### Last Updated: December 05, 2020
![teddy-e1542668999421.jpg](https://estreetshuffle.com/wp-content/uploads/2018/11/teddy-e1542668999421.jpg)

It’s not often I can say this: I think this cover is better than Bruce’s original version.
Teddy “Zig Zag” Andreadis has toured with and supported artists ranging from Guns N’ Roses to Carole King, but his roots are on the Jersey shore.
Maybe that’s why he takes so well to covering Bruce. He made a gutsy choice, too–opting for “[57 Channels (And Nothin’ On)](https://estreetshuffle.com/index.php/2020/05/17/roll-of-the-dice-57-channels-and-nothin-on/),” a song that was both lyrically and musically dated almost as soon as it was released.
Zig Zag’s take is bluesy and earthy, breathing new life into the song. Well done.
[Youtube: 57 Channels](https://www.youtube.com/watch?v=PPkADH1GHVQ)
![](https://www.youtube.com/watch?v=PPkADH1GHVQ)