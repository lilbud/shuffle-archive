# Cover Me, Aoife O'Donovan: Nebraska
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/09/28/cover-me-aoife-odonovan-nebraska/
#### Published: September 28, 2018
#### Last Updated: April 14, 2019
![aoife-e1538070651889.jpg](https://estreetshuffle.com/wp-content/uploads/2018/09/aoife-e1538070651889.jpg)

I guess i’m in a bit of a *Nebraska* mood this week, as this the second cover I’ve posted recently from that album.
But Aoife O’Donovan’s cover of the [title track](http://estreetshuffle.com/index.php/2018/04/16/roll-of-the-dice-nebraska/) is too good to sit on, so I won’t.
But more importantly: how is that I’ve never heard of[Salt Stage](http://saltstage.com) before? I’m an instant fan, and it’s gonna take me a long time to browse all their gorgeously filmed performances from some very talented artists. Highly recommended.
[Youtube: Aoife O'Donovan / Nebraska by Bruce Springsteen / Salt Stage / 07.20.16](https://www.youtube.com/watch?v=j-tHyo5im1M)
![](https://www.youtube.com/watch?v=j-tHyo5im1M)