# Christmas Day
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2002/01/10/matr-bruce-springsteen-jimmy-vivino-and-the-max-weinberg-7-christmas-day/
#### Published: January 10, 2002
#### Last Updated: November 06, 2025
![christmas-day-pictures-149752-3074066.png](https://estreetshuffle.com/wp-content/uploads/2019/12/christmas-day-pictures-149752-3074066.png)

Detroit Junior released a seasonal single in 1961 entitled “This Time Last Christmas.” It was the song’s B-side, however, that caught on: “Christmas Day” may not exactly be a holiday classic, but it was successful enough to have been included on several holiday compilation albums.
[Youtube: Detroit Junior - Christmas Day](https://www.youtube.com/watch?v=cDhxLfiPPzk)
![](https://www.youtube.com/watch?v=cDhxLfiPPzk)
It also caught Bruce’s attention, obviously, because he played it seven times over a two year period back in the days of his annual Asbury Park holiday shows–each time as a duet with Jimmy Vivino, backed by The Max Weinberg 7.
Their arrangement of “Christmas Day” was faithful, fun, and rocking, but what’s most remarkable about these performances is watching Bruce tear it up… on the piano. Check it out about the 1:45 mark–who knew Bruce could play like that?
[Youtube: Christmas Day (Feel So Good) - Max Weinberg 7 with Jimmy Vivino & Bruce Springsteen](https://www.youtube.com/watch?v=fo0eaupeP9A)
![](https://www.youtube.com/watch?v=fo0eaupeP9A)
Bruce hasn’t played “Christmas Day” since those too-short-lived holiday show days, but let’s keep hope alive for the rebirth of a holiday tradition soon.
**Christmas Day
First performed:** December 4, 2001 (Asbury Park, NJ)
**Last performed:** December 8, 2003 (Asbury Park, NJ)
(c) December 25, 2019 by Ken Rosen