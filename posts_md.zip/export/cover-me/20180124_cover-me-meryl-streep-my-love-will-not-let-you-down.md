# Cover Me, Meryl Streep(!): My Love Will Not Let You Down
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/01/24/cover-me-meryl-streep-my-love-will-not-let-you-down/
#### Published: January 24, 2018
#### Last Updated: December 12, 2021
![ricki-flash-soundtrack-cover-2015-billboard-510.jpg](https://estreetshuffle.com/wp-content/uploads/2018/01/ricki-flash-soundtrack-cover-2015-billboard-510.jpg)

Bonus *Cover Me* today, because this is just too unlikely to feature on its own:
From the film *Ricki and the Flash*, Meryl Streep performs “[My Love Will Not Let You Down](http://estreetshuffle.com/index.php/2018/01/24/roll-of-the-dice-my-love-will-not-let-you-down/),” and commits to it pretty hard. Ironically, that’s Rick Springfield on lead guitar.
Enjoy. It works better in the movie. Really.
[Youtube: My Love Will Not Let You Down (From “Ricki And The Flash” Soundtrack)](https://www.youtube.com/watch?v=kbZzTP2pdUg)
![](https://www.youtube.com/watch?v=kbZzTP2pdUg)