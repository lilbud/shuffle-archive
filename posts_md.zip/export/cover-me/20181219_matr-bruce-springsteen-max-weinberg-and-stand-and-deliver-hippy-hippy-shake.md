# MatR: Bruce Springsteen, Max Weinberg, and Stand and Deliver: Hippy Hippy Shake
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/12/19/matr-bruce-springsteen-max-weinberg-and-stand-and-deliver-hippy-hippy-shake/
#### Published: December 19, 2018
#### Last Updated: December 18, 2018
![hippy.jpg](https://estreetshuffle.com/wp-content/uploads/2018/12/hippy.jpg)

Chan Romero was only 17 when he wrote his breakthrough hit, “Hippy Hippy Shake.”
[Youtube: Chan Romero - Hippy Hippy Shake](https://www.youtube.com/watch?v=MlkKB1JlbFg)
![](https://www.youtube.com/watch?v=MlkKB1JlbFg)
Released in 1959, it became a huge hit and caught the ear of Paul McCartney, who would perform it often during early Beatles gigs.
[Youtube: The Hippy Hippy Shake (Live At The BBC For "Pop Go The Beatles" / 30th July, 1963)](https://www.youtube.com/watch?v=3rtObYg821M)
![](https://www.youtube.com/watch?v=3rtObYg821M)
Three decades later, Bruce took his one and only swing at it when he made an unannounced guest appearance (along with Max Weinberg) on guitar with cover band Stand and Deliver at the Classics Cafe in Westwood, New Jersey. Take a listen below.
[Youtube: Bruce Springsteen, Max Weinberg, & Stand and Deliver - "Hippy Hippy Shake," 1994-08-26](https://www.youtube.com/watch?v=ts_RdjuZqR8)
![](https://www.youtube.com/watch?v=ts_RdjuZqR8)
**Hippy Hippy Shake**
**First performed:** August 26, 1994 (Westfield, NJ)
**Last performed:** August 26, 1994 (Westfield, NJ)