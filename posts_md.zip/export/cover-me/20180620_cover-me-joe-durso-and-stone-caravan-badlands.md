# Cover Me, Joe D'Urso and Stone Caravan: Badlands
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/06/20/cover-me-joe-durso-and-stone-caravan-badlands/
#### Published: June 20, 2018
#### Last Updated: November 28, 2019
![badlandsurso-e1529155889619.jpg](https://estreetshuffle.com/wp-content/uploads/2018/06/badlandsurso-e1529155889619.jpg)

It takes guts to reinvent an anthem like “[Badlands](http://estreetshuffle.com/index.php/2019/05/20/roll-of-the-dice-badlands/).” Even Bruce has never deviated from its original arrangement–it was pretty much born perfect.
But leave it to fellow Jersey boy Joe D’Urso to take a swing at it, and he certainly puts his own spin on it, giving it almost an island-flavored arrangement with a boost from Miami Horns members Richie LaBamba, Mark Pender, and Jerry Vivino.
[Youtube: Badlands](https://www.youtube.com/watch?v=9LBIzL3rAd8)
![](https://www.youtube.com/watch?v=9LBIzL3rAd8)