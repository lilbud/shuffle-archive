# Cover Me, Kevin Heider: My Lucky Day
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/10/30/cover-me-kevin-heider-my-lucky-day/
#### Published: October 30, 2019
#### Last Updated: October 29, 2019
![ohio.jpg](https://estreetshuffle.com/wp-content/uploads/2019/10/ohio.jpg)

Singer-songwriter Kevin Heider has a brand-new Springsteen tribute album out.
Called *Ohio* (I see what you did there, Kevin), the album features ten acoustic covers. Some are familiar arrangements, others are new, but all are beautiful renditions.
But my favorite track on the album is undoubtedly Kevin’s cover of “[My Lucky Day](http://estreetshuffle.com/index.php/2019/09/02/roll-of-the-dice-my-lucky-day/),” because not only is it a beautiful cover of a great song, there’s also an accompanying video featuring toddlers on a slide.
C’mon, how great is that?
[Youtube: My Lucky Day | Kevin Heider (an official Springsteen cover)](https://www.youtube.com/watch?v=QzbaD4sa7a0)
![](https://www.youtube.com/watch?v=QzbaD4sa7a0)