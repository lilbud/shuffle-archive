# MatR: Dropkick Murphys and Bruce Springsteen, I'm Shipping Up to Boston
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/12/16/matr-dropkick-murphys-and-bruce-springsteen-im-shipping-up-to-boston/
#### Published: December 16, 2018
#### Last Updated: December 06, 2020
![boston.png](https://estreetshuffle.com/wp-content/uploads/2018/12/boston.png)

Dropkick Murphys co-wrote “I’m Shipping Up to Boston” with Woody Guthrie. Seriously.
Chancing upon the hand-written lyrics on a scrap of paper in Guthrie’s archives, Ken Casey and crew set them to music in 2006 and scored their biggest hit in the process.
[Youtube: I'm Shipping Up To Boston - Dropkick Murphys](https://www.youtube.com/watch?v=x-64CaD8GXw)
![](https://www.youtube.com/watch?v=x-64CaD8GXw)
On St. Patrick’s Day in 2011, Bruce shipped up to Boston to perform it with the original artists–his one and only performance of the song to date. It was a fantastic performance, captured in great quality. Check it out below.
[Youtube: I'm Shipping Up To Boston - Dropkick Murphys and The Boss (HiRes)](https://www.youtube.com/watch?v=a7QsVPYWQFE)
![](https://www.youtube.com/watch?v=a7QsVPYWQFE)
**I’m Shipping Up to Boston**
**First performed:** March 18, 2011 (Boston, MA)
**Last performed:** March 18, 2011 (Boston, MA)