# Cover Me, Jimmy LaFave: Land of Hope and Dreams
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/07/20/cover-me-jimmy-lafave-land-of-hope-and-dreams/
#### Published: July 20, 2018
#### Last Updated: July 20, 2018
![lavave.jpg](https://estreetshuffle.com/wp-content/uploads/2018/07/lavave.jpg)

Oklahoma singer-songwriter Jimmy LaFave has a talent for interpreting Bruce’s songs (see his cover of “[Valentine’s Day](http://estreetshuffle.com/index.php/2018/03/03/cover-me-jimmy-lafave-valentines-day/)“).
In 2012, Jimmy released his album *Depending on the Distance*, featuring his cover of Bruce’s “[Land of Hope and Dreams.](http://estreetshuffle.com/index.php/2018/01/05/roll-of-the-dice-land-of-hope-and-dreams/)” Unlike Bruce’s version, which plays more like a declarative anthem, Jimmy’s version is tender–almost a love song. It’s a different take, and a great cover.
[Youtube: Land Of Hope And Dreams](https://www.youtube.com/watch?v=FoVYbBGXHvI)
![](https://www.youtube.com/watch?v=FoVYbBGXHvI)