# MatR: Steve Earle and Bruce Springsteen, I Ain't Ever Satisfied
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/07/06/matr-steve-earle-and-bruce-springsteen-i-aint-ever-satisfied/
#### Published: July 06, 2019
#### Last Updated: July 05, 2019
![satisfied.jpg](https://estreetshuffle.com/wp-content/uploads/2019/07/satisfied.jpg)

“I Ain’t Ever Satisfied” may never have the hit it deserved to be (it only peaked at #26 on the U.S. Mainstream Rock chart), but Earle’s fans still rank it as one of their favorites, and it’s still one of Earle’s most frequently performed songs.
[Youtube: Steve Earle & The Dukes - I Ain't Ever Satisfied](https://www.youtube.com/watch?v=ituFNPXAaE8)
![](https://www.youtube.com/watch?v=ituFNPXAaE8)
With its defiant theme and wordless “Woh-oh-oh-oh-oh-oh-oh-oh ” chorus, “I Ain’t Ever Satisfied” sounds tailor-made for a Springsteen cover or duet.
We got the latter when Bruce joined Steve Earle on stage during the encore set at Earle’s 1998 show at Tradewinds in Sea Bright, New Jersey.
Here’s that one-time only performance, from February 6, 1998. Bruce is on guitar the whole time, and you’ll hear his vocals kick in at around the halfway point.
[https://videopress.com/embed/tRGCYnzg?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata](https://videopress.com/embed/tRGCYnzg?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata)
**I Ain’t Ever Satisfied
First performed:** February 6, 1998 (Sea Bright, NJ)
**Last performed:** February 6, 1998 (Sea Bright, NJ)