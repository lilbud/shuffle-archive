# Cover Me: Riding in My Car
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2020/01/28/cover-me-riding-in-my-car/
#### Published: January 28, 2020
#### Last Updated: January 02, 2024
![30childrens-slide-PQKM-superJumbo.jpg](https://estreetshuffle.com/wp-content/uploads/2020/01/30childrens-slide-PQKM-superJumbo.jpg)

Bruce Springsteen his covered the work of Woody Guthrie time and again.
“[This Land Is Your Land](https://estreetshuffle.com/index.php/2023/07/04/cover-me-this-land-is-your-land/)” was a River Tour staple; “[Hard Times (Come Again No More)](https://estreetshuffle.com/index.php/2022/01/21/cover-me-hard-times-come-again-no-more/)” was a featured encore throughout the Working on a Dream Tour.
Bruce has covered folk classics like “[Lonesome Valley](http://estreetshuffle.com/index.php/2018/02/08/cover-me-woody-guthries-lonesome-valley/)” and “[Deportee (Plane Wreck at Los Gatos)](http://estreetshuffle.com/index.php/2020/01/05/cover-me-deportee-plane-wreck-at-los-gatos/)” in concert, and he’s released a studio recording of “[I Ain’t Got No Home](http://estreetshuffle.com/index.php/2019/02/10/cover-me-rotd-i-aint-got-no-home/).”
But as soon as Bruce became a parent, we knew it was only a matter of time before Guthrie’s children’s songs showed up in Bruce’s set list, too. And really: was there ever any doubt that Woody’s “Riding in My Car” (also known as “Car Song”) would be the one that grabbed Bruce’s attention?
[Youtube: Woody Guthrie - Car Song](https://www.youtube.com/watch?v=DUDtFdnn9oQ)
![](https://www.youtube.com/watch?v=DUDtFdnn9oQ)
Like Bruce would remark when he debuted it at a 1996 Guthrie tribute concert, “Automobiles: that’s my business. Mr. Guthrie, no disrespect but that’s *my* business.”
“Riding in My Car” was a natural choice for Bruce to cover; the only question for those in attendance as he introduced it was: could Bruce nail the car noises?
Of course he could.
[Youtube: Riding In My Car](https://www.youtube.com/watch?v=NQM1LrzfFkM)
![](https://www.youtube.com/watch?v=NQM1LrzfFkM)
Believe it or not, Bruce’s cover of “Riding in My Car” has been officially released–you can find it on *‘Til We Outnumber Them*, which documents that 1996 tribute concert.
For fans of Woody and Bruce, that’s great news, because we’re highly unlikely to hear Bruce cover it in concert again.
**Riding in My Car (Car Song)
Recorded:** September 29, 1996 (live)* *Released:** *‘Til We Outnumber Them* (2000)* *First performed:** September 29, 1996 (Cleveland, OH)
**Last performed:** September 29, 1996 (Cleveland, OH)