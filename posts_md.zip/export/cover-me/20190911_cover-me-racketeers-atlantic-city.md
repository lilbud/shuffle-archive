# Cover Me, Racketeers: Atlantic City
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/09/11/cover-me-racketeers-atlantic-city/
#### Published: September 11, 2019
#### Last Updated: September 10, 2019
![racketeers.jpg](https://estreetshuffle.com/wp-content/uploads/2019/09/racketeers.jpg)

I don’t know much about this New York City-based Irish band than what I’ve already typed, but I hope we hear more from them in the future.
They started a Youtube channel five months ago, and their most recent video is a beautiful cover of Bruce’s “[Atlantic City](http://estreetshuffle.com/index.php/2018/06/04/roll-of-the-dice-atlantic-city/).”
[Youtube: Racketeers   Atlantic City (Bruce Springsteen Cover)](https://www.youtube.com/watch?v=0IMJl9YpabY)
![](https://www.youtube.com/watch?v=0IMJl9YpabY)
Performed by the duo purely on acoustic guitar, mandolin, and harmonica, they perfectly capture the essence of Bruce’s original album arrangement.
This is very, very well done.