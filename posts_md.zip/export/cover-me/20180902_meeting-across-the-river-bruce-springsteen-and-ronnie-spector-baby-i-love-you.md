# Meeting Across the River: Bruce Springsteen and Ronnie Spector, Baby I Love You
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/09/02/meeting-across-the-river-bruce-springsteen-and-ronnie-spector-baby-i-love-you/
#### Published: September 02, 2018
#### Last Updated: December 03, 2020
![babyilove-you-e1535832327205.jpg](https://estreetshuffle.com/wp-content/uploads/2018/09/babyilove-you-e1535832327205.jpg)

“Baby, I Love You” was Ronnie Spector’s second big hit (after “[Be My Baby](http://estreetshuffle.com/index.php/2019/06/01/matr-bruce-springsteen-and-ronnie-spector-be-my-baby/)“). Recorded in the autumn of 1963 (with Darlene Love, Sonny Bono, and a 17-year-old Cher on backing vocals) and released in November, the song went to #24 on the American pop charts and #11 in the UK.
[Youtube: Baby, I Love You](https://www.youtube.com/watch?v=kmFkjURkrEE)
![](https://www.youtube.com/watch?v=kmFkjURkrEE)
Ronnie and Bruce go pretty far back as well, and we’re lucky enough to have several recordings of her iconic voice paired with the mighty E Street Band.
Ronnie and Bruce’s meeting came by way of–believe it or not–John Lennon, who ran into Ronnie on the street in New York one day and insisted on introducing her to Jimmy Iovine, who in turn invited Ronnie to join him for a Southside Johnny studio session. Bruce and Steve happened to be there as well, and both were over the moon to be in the presence of one of their favorite voices.
Bruce was so taken with Ronnie that he insisted that she sing “[You Mean So Much to Me](https://estreetshuffle.com/index.php/2020/02/16/cover-me-southside-johnny-and-ronnie-spector-you-mean-so-much-to-me/)” with Southside on his album–he thought her voice was a perfect fit for it. That was the start of both a long friendship and a professional relationship: the E Street Band (led by Steve) would back Ronnie on her “[Say Goodbye to Hollywood](http://estreetshuffle.com/index.php/2019/08/27/matr-ronnie-spector-and-the-e-street-band-say-goodbye-to-hollywood/)” single, Steve wrote a song (“Baby, Please Don’t Go”) for the b-side, and Ronnie herself would grace Bruce’s stage several times, as recently as December 2016.
This recording of “Baby, I Love You” is from Ronnie’s very first on-stage performance with Bruce and the E Street Band, on November 4, 1976 at the Palladium in New York City.
[Youtube: Bruce Springsteen and Ronnie Spector, "Baby I Love You" - 1976-11-04](https://www.youtube.com/watch?v=jdWqZ3U-e68)
![](https://www.youtube.com/watch?v=jdWqZ3U-e68)
**Baby, I Love You**
**First performed:** November 4, 1976 (New York City, NY)
**Last performed:** May 13, 1977 (Red Bank, NJ)