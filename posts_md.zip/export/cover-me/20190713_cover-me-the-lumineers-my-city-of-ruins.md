# Cover Me, The Lumineers: My City of Ruins
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/07/13/cover-me-the-lumineers-my-city-of-ruins/
#### Published: July 13, 2019
#### Last Updated: July 13, 2019
![lumineers.jpg](https://estreetshuffle.com/wp-content/uploads/2019/07/lumineers.jpg)

The Lumineers may be Denver-based, but they got their start in New Jersey and count Bruce among their influences. Sometimes that influence is under the surface, but sometimes it’s right on top.
And when the band visited Radio Hamburg on a 2012 trip to Germany, Bruce was very much top of mind.
Among the songs they played during their in-station visit: a lovely, stripped-down version of Bruce’s “My City of Ruins.” The recording quality is a bit harsh at times, but the performance is intimate and haunting.
[Youtube: My City of Ruins - The Lumineers (Bruce Springsteen cover)](https://www.youtube.com/watch?v=ffniZ-zC5Mw)
![](https://www.youtube.com/watch?v=ffniZ-zC5Mw)
That wasn’t a one-off, though. The Lumineers brought it out again during their 2016 visit to the town Bruce wrote the song for. From their appearance on the Stone Pony Summer Stage in August 2016, here’s The Lumineers (plus Langhorne Slim) performing “My City of Ruins” for Bruce’s adopted hometown.
[Youtube: The Lumineers & Langhorne Slim Live Cover Springsteen My City of Ruins  at Asbury Park Stone Pony](https://www.youtube.com/watch?v=ImCT_jDOEY0)
![](https://www.youtube.com/watch?v=ImCT_jDOEY0)