# Cover Me, Boombox Hearts: Cover Me
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/10/20/cover-me-boombox-hearts-cover-me/
#### Published: October 20, 2018
#### Last Updated: December 13, 2021
![coverme.jpg](https://estreetshuffle.com/wp-content/uploads/2018/10/coverme.jpg)

By now you my motto when it comes to covers: Do it better, or do it different.
Self-described “melancholy lo-fi indie” band The Boombox Hearts takes the latter route with “[Cover Me](https://estreetshuffle.com/index.php/2021/01/13/roll-of-the-dice-cover-me/),” but it’s pretty darn good, too.
“Cover Me” is at heart a sad song, right from the opening lines, and the Boombox Hearts well capture that sense of longing for connection in a rough and tumble world.
Plus: when’s the last time you heard someone add a trombone solo when covering a Springsteen song?
[Youtube: The Boombox Hearts ~ Cover Me ∞Bruce Springsteen Cover∞](https://www.youtube.com/watch?v=0cECsZXs2EI)
![](https://www.youtube.com/watch?v=0cECsZXs2EI)