# Meeting Across the River: Bruce Springsteen and the Asbury Park All-Star Revue, Got to Get You Off My Mind
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/08/11/meeting-across-the-river-bruce-springsteen-and-the-asbury-park-all-star-revue-got-to-get-you-off-my-mind/
#### Published: August 11, 2018
#### Last Updated: January 01, 2024
![burke.jpg](https://estreetshuffle.com/wp-content/uploads/2018/08/burke.jpg)

When Southside Johnny took ill in May ’77 and couldn’t perform his scheduled gigs at the Monmouth Arts Center in Red Bank, Steve Van Zandt transformed his show into “The Asbury Park All-Star Revue,” featuring the Jukes, Bruce and the E Street Band, and Ronnie Spector. The Revue performed only one show on [May 12th](http://estreetshuffle.com/index.php/2018/05/12/kingdom-of-days-may-12/) and two shows on [the 13th](http://estreetshuffle.com/index.php/2018/05/13/kingdom-of-days-may-13/), but while it lasted it was a glorious concert experience.
For most of the shows–including “Got to Get You Off My Mind,” which the Revue played as the second song for each show, Steve performed lead vocals, with Bruce on guitar and backing vocals. The audio from these nights isn’t great, but you can clearly hear Steve and Bruce’s fun interplay below.
[http://estreetshuffle.com/wp-content/uploads/2018/08/1977_05_13_Early_T02-Got-to-Get-You-Off-of-My-Mind.mp3?_=2](http://estreetshuffle.com/wp-content/uploads/2018/08/1977_05_13_Early_T02-Got-to-Get-You-Off-of-My-Mind.mp3?_=2)
<http://estreetshuffle.com/wp-content/uploads/2018/08/1977_05_13_Early_T02-Got-to-Get-You-Off-of-My-Mind.mp3>
“Got to Get You Off My Mind” was a 1965 hit written and recorded by Solomon Burke, who Bruce has often cited as an influence.
[Youtube: Got to Get You off My Mind (Edit)](https://www.youtube.com/watch?v=JkVsWfj7JKo)
![](https://www.youtube.com/watch?v=JkVsWfj7JKo)
“Got to Get You Off My Mind” went to number one on the R&B charts. Southside covered it on his *I Don’t Want to Go Home* debut album, and he featured it frequently in his setlists. The ’77 All-Star performances are the only times Bruce has performed the song.
[Youtube: Got to Get You Off My Mind (2016 Remaster)](https://www.youtube.com/watch?v=tGgFMB1N0ew)
![](https://www.youtube.com/watch?v=tGgFMB1N0ew)
**Got to Get You Off My Mind****First performed:** [May 12](http://estreetshuffle.com/index.php/2018/05/12/kingdom-of-days-may-12/), 1977 (Red Bank, NJ)
**Last performed:** [May 13](http://estreetshuffle.com/index.php/2018/05/13/kingdom-of-days-may-13/), 1977 (Red Bank, NJ)