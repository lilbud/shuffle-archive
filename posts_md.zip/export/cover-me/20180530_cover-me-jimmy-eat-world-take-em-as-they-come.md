# Cover Me, Jimmy Eat World: Take 'Em as They Come
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/05/30/cover-me-jimmy-eat-world-take-em-as-they-come/
#### Published: May 30, 2018
#### Last Updated: December 28, 2022
![jimmy.jpg](https://estreetshuffle.com/wp-content/uploads/2018/06/jimmy.jpg)

Here’s an undeservedly obscure Bruce cover that deserves much wider exposure:
In 2007, Jimmy Eat World released their sixth studio album, *Chase This Light*, and this frenetic, impossible-not-to-dance-to cover of “[Take ‘Em as They Come](http://estreetshuffle.com/index.php/2019/03/29/roll-of-the-dice-take-em-as-they-come/)” was a bonus track exclusively for iTunes customers.
If you missed it then, give it a listen now–but first, turn the volume up and get your dancing shoes on, because this one *rocks.*
[Youtube: Take 'Em As They Come](https://www.youtube.com/watch?v=PWQmsUWp0JU)
![](https://www.youtube.com/watch?v=PWQmsUWp0JU)