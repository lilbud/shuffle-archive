# MatR: Southside Johnny and Bruce Springsteen, I've Been Working Too Hard
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/07/27/matr-southside-johnny-and-bruce-springsteen-ive-been-working-too-hard/
#### Published: July 27, 2019
#### Last Updated: December 13, 2020
![ive-been-working.jpg](https://estreetshuffle.com/wp-content/uploads/2019/07/ive-been-working.jpg)

Don’t call it a comeback album (because he was never gone), and don’t you dare call it a return to form.
Let’s just call it a reunion album, because eight of the eleven tracks on Southside Johnny’s 1991 *Better Days* album were written by Steve Van Zandt, and Southside Johnny and Little Steven make for a magic combination.
*Better Days* is one of Southside’s best albums, and one of its standout tracks is Steve’s “I’ve Been Working Too Hard,” a rave-up tailor-made for Southside that featured Little Steven on backing vocals, and none other than Jon Bon Jovi on duet vocals.
[Youtube: I've Been Working Too Hard](https://www.youtube.com/watch?v=UmzsOcF5f7k)
![](https://www.youtube.com/watch?v=UmzsOcF5f7k)
The song became a minor, regional hit for Southside, and a crowd-pleaser in concert.
As for Bruce, while he did contribute a song of his own (“[All the Way Home](https://estreetshuffle.com/index.php/2019/09/08/roll-of-the-dice-all-the-way-home/)“) to *Better Days,* along with his vocal talents on “It’s Been a Long Time,” Bruce’s stamp is nowhere to be found on “I’ve Been Working Too Hard.”
But that didn’t stop him from performing it with Southside in concert on two occasions, both at the Stone Pony in Asbury Park.
The latter of those two times was caught on video–and while the quality is rough, it’s still a joy to watch. From May 27, 2001 (three days shy of the 25th anniversary of Southside’s radio broadcast from The Stone Pony), here’s Southside and Bruce (with Graham Parker) singing “I’ve Been Working Too Hard.”
[https://videopress.com/embed/d2Z88t4f?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata](https://videopress.com/embed/d2Z88t4f?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata)
**I’ve Been Working Too Hard
First performed:** July 16, 1994 (Asbury Park, NJ)
**Last performed:** May 27, 2001 (Asbury Park, NJ)