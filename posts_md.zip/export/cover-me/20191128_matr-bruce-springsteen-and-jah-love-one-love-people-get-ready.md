# MatR: Bruce Springsteen and Jah Love, One Love/People Get Ready
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/11/28/matr-bruce-springsteen-and-jah-love-one-love-people-get-ready/
#### Published: November 28, 2019
#### Last Updated: November 28, 2019
![onelove.jpg](https://estreetshuffle.com/wp-content/uploads/2019/11/onelove.jpg)

Bob Marley’s signature song “One Love” might seem like a strange candidate for a Bruce Springsteen cover, but when Bruce and Clarence joined Jah Love, a local New Jersey-based reggae singer, on stage at a Jersey shore club in the summer of 1987, that’s exactly what they performed together.
(At least, until they segued from “One Love” into one of Bruce’s own songs. I’ll let you figure out which one for yourself–suffice it to say it’s just about the last arrangement you’d ever expect to hear for it.)
[https://videopress.com/embed/EYKIYAgU?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata](https://videopress.com/embed/EYKIYAgU?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata)
As for their “One Love” cover… well, let’s just say it’s not one of Bruce’s best attempts.
Then again, it’s hard to top Marley’s original–it remains one of the most universally recognized and loved reggae songs.
[Youtube: Bob Marley - One Love](https://www.youtube.com/watch?v=vdB-8eLEW8g)
![](https://www.youtube.com/watch?v=vdB-8eLEW8g)
**One Love/People Get Ready
First performed:** July 30, 1987 (Neptune, NJ)
**Last performed:** July 30, 1987 (Neptune, NJ)
[https://videopress.com/embed/EYKIYAgU?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata](https://videopress.com/embed/EYKIYAgU?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata)