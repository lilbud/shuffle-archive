# Cover Me, Hem: Valentine's Day
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/02/12/cover-me-hem-valentines-day/
#### Published: February 12, 2019
#### Last Updated: March 09, 2019
![hemval.jpg](https://estreetshuffle.com/wp-content/uploads/2019/02/hemval.jpg)

Shortly after their founding, the eclectic, indie folk band Hem released *I’m Talking With My Mouth*, a 2002 EP of cover tunes, all gorgeously reimagined.
But if there’s a standout track, it has to be Bruce’s “[Valentine’s Day,](http://estreetshuffle.com/index.php/2018/06/12/roll-of-the-dice-valentines-day/)” arranged in a beautiful country-folk setting and featuring some sublime harmonies from singers Sally Ellyson and Steve Curtis.
[Youtube: Valentine's Day](https://www.youtube.com/watch?v=3K9y3QAqSus)
![](https://www.youtube.com/watch?v=3K9y3QAqSus)
The band made an interesting artistic choice, opting to drop the song’s coda (the only part of the song that overtly establishes the connection to the song’s title) in favor of lingering longer in the waking moments of the singer’s dream.
And darn it if it doesn’t work just as well–maybe even better.
This is a very well done cover.