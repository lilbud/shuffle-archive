# Cover Me, EFIX, Henri Pfr, Florence Welch, and Kid Harpoon: I'm Goin' Down
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/10/23/cover-me-efix-henri-pfr-florence-welch-and-kid-harpoon-im-goin-down/
#### Published: October 23, 2018
#### Last Updated: December 13, 2021
![goindown-e1539746631435.jpg](https://estreetshuffle.com/wp-content/uploads/2018/10/goindown-e1539746631435.jpg)

And now for something completely different.
I’d heard Florence Welch and Kid Harpoon’s acoustic take on “[I’m Goin’ Down](https://estreetshuffle.com/index.php/2021/06/05/roll-of-the-dice-im-goin-down/)” from their BBC 6 appearance years ago, but when I searched youtube for it today, I stumbled across this little gem–a remix of an acoustic cover of a minor 80s pop hit. It’s pretty darn good.
[Youtube: EFIX & Henri Pfr - I'm Going Down (feat. Florence Welch & Kid Harpoon)](https://www.youtube.com/watch?v=-waljjH-E04)
![](https://www.youtube.com/watch?v=-waljjH-E04)