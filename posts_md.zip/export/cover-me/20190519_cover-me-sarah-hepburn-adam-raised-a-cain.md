# Cover Me, Sarah Hepburn: Adam Raised a Cain
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/05/19/cover-me-sarah-hepburn-adam-raised-a-cain/
#### Published: May 19, 2019
#### Last Updated: January 01, 2023
![sarahhep.jpg](https://estreetshuffle.com/wp-content/uploads/2019/05/sarahhep.jpg)

Gotta confess: I know next to nothing about Sarah Hepburn, and absolutely zero about Mungo Records and the film called *W at Mungo Park*.
But that film’s soundtrack apparently includes this wonderful, brooding cover of Bruce’s “[Adam Raised a Cain](https://estreetshuffle.com/index.php/2022/07/03/roll-of-the-dice-adam-raised-a-cain/).”
I only came across this one recently, it’s been on heavy rotation ever since. Turn off the lights, turn up the volume, and listen.
[Youtube: Adam Raised a Cain](https://www.youtube.com/watch?v=Fe1nJ-3-E9U)
![](https://www.youtube.com/watch?v=Fe1nJ-3-E9U)