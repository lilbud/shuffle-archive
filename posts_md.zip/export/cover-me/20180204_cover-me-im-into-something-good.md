# Cover Me: I'm Into Something Good
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/02/04/cover-me-im-into-something-good/
#### Published: February 04, 2018
#### Last Updated: December 12, 2021
![herman-hermits.jpg](https://estreetshuffle.com/wp-content/uploads/2018/01/herman-hermits.jpg)

At The Back Door in Richmond, VA, 46 years ago today, Bruce played this one-time-only cover of “I’m Into Something Good,” written by Gerry Goffin and Carole King but made famous by Herman’s Hermits.
[Youtube: I'm Into Something Good - The Bruce Springsteen Band, Live at the Back Door in Richmond, 04.02.1972](https://www.youtube.com/watch?v=bj-nHjjfHmQ)
![](https://www.youtube.com/watch?v=bj-nHjjfHmQ)
“I’m Into Something Good’ was originally recorded by Earl-Jean and released as a single in 1964–but it never charted on the Hot 100.
[Youtube: The Cookies/Earl Jean I'm Into Something Good (ORIGINAL SONG)](https://www.youtube.com/watch?v=q5-Sg_JJgQ4)
![](https://www.youtube.com/watch?v=q5-Sg_JJgQ4)
Shortly after, Herman’s Hermits released their version as their first single, and it went right to the top of the U.K. Singles Chart.
[Youtube: I'm Into Something Good](https://www.youtube.com/watch?v=MDUCOwp1p60)
![](https://www.youtube.com/watch?v=MDUCOwp1p60)
Bruce only performed it that once, with The Bruce Springsteen Band.
**I’m Into Something Good**
**First performed:** February 4, 1972 (Richmond, VA)
**Last performed:** February 4, 1972 (Richmond, VA)