# Cover Me, Michelle Moore and the Alliance Singers: Rocky Ground
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/06/08/cover-me-michelle-moore-and-the-alliance-singers-rocky-ground/
#### Published: June 08, 2018
#### Last Updated: January 01, 2024
![michelle.jpg](https://estreetshuffle.com/wp-content/uploads/2018/06/michelle.jpg)

Michelle Moore is certainly qualified to cover Bruce’s “[Rocky Ground](https://estreetshuffle.com/index.php/2023/03/20/roll-of-the-dice-rocky-ground/)” — she sings and raps on the studio track, after all, and she was a featured vocalist throughout the Wrecking Ball tour whenever this song was in the setlist.
So it’s great to see and hear her take the reins on the full song, supported by The Alliance Singers (who together with Michelle, provide backing vocals on tracks from *The Rising* and *The Promise* as well).
Enjoy this performance from “Thunder Road Thursday,” a Bruce birthday celebration at the Freehold Acoustic Lounge on September 26, 2013.
[Youtube: Alliance Singers featuring Michelle Moore    "Rocky Ground"](https://www.youtube.com/watch?v=PTAT3HJOdhs)
![](https://www.youtube.com/watch?v=PTAT3HJOdhs)