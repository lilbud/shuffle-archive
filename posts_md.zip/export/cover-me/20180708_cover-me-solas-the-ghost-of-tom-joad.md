# Cover Me, Solas: The Ghost of Tom Joad
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/07/08/cover-me-solas-the-ghost-of-tom-joad/
#### Published: July 08, 2018
#### Last Updated: November 28, 2019
![solas.jpg](https://estreetshuffle.com/wp-content/uploads/2018/07/solas.jpg)

If your band’s genre is a mix of Irish traditional and americana music, sooner or later you’re bound to cover our greatest (half-)Irish americana artist. Solas chose a great Springsteen original to cover–their take on “[The Ghost of Tom Joad](http://estreetshuffle.com/index.php/2019/10/17/roll-of-the-dice-the-ghost-of-tom-joad/)” captures its spirit in an (appropriately) haunting arrangement.
[Youtube: Ghost of Tom Joad](https://www.youtube.com/watch?v=fNGjSHiYvoQ)
![](https://www.youtube.com/watch?v=fNGjSHiYvoQ)