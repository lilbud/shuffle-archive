# Cover Me, Jason Heath and The Greedy Souls: 4th of July, Asbury Park (Sandy)
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/11/11/cover-me-jason-heath-and-the-greedy-souls-4th-of-july-asbury-park-sandy/
#### Published: November 11, 2019
#### Last Updated: November 11, 2019
![jasonheathngreedysouls.jpg](https://estreetshuffle.com/wp-content/uploads/2019/11/jasonheathngreedysouls.jpg)

Dare I say it? This cover of “[4th of July, Asbury Park (Sandy)](http://estreetshuffle.com/index.php/2019/04/26/roll-of-the-dice-4th-of-july-asbury-park-sandy/)” by Jason Heath and the Greedy Souls is absolutely perfect.
The band just nails every aspect, capturing not just the sound but the heart and soul of Bruce’s seaside original. I might even love it more than the original, in fact.
[Youtube: Hanging On E' Street - Jason Heath &  the Greedy Souls cover 4th Of July Asbury Park (Sandy)](https://www.youtube.com/watch?v=Yj-H2mqpFQw)
![](https://www.youtube.com/watch?v=Yj-H2mqpFQw)
And if the accordion in particular sounds particularly evocative, there’s a reason: that’s Greedy Souls organist and accordion player Jason Federici you see and hear.
His dad would be proud.