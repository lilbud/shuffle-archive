# MatR: Bryan Adams and Bruce Springsteen, Cuts Like a Knife
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/09/14/meeting-across-the-river-bryan-adams-and-bruce-springsteen-cuts-like-a-knife/
#### Published: September 14, 2018
#### Last Updated: January 01, 2023
![Cuts-Like-a-Knife.jpg](https://estreetshuffle.com/wp-content/uploads/2018/09/Cuts-Like-a-Knife.jpg)

The first time Bruce ever performed Bryan Adam’s “Cuts Like a Knife” was at the eighties-themed Rainforest Fund Concert in 2010. Each artist chose their own material to cover; who knew that Bruce was a Bryan fan before that?
[Youtube: Bruce Springsteen Covers Bryan Adams' Cuts Like a Knife at Rainforest Benefit Concert 05/13/10](https://www.youtube.com/watch?v=VZZgzF0g9lU)
![](https://www.youtube.com/watch?v=VZZgzF0g9lU)
It probably shouldn’t have come as a surprise, though: Bryan’s 1983 anthem sounds tailor-made for Bruce to cover, and I can easily imagine it being played at an E Street Band show someday.
[Youtube: Bryan Adams - Cuts Like A Knife](https://www.youtube.com/watch?v=6VZhSkREYBc)
![](https://www.youtube.com/watch?v=6VZhSkREYBc)
But it would be another seven years after that first performance before the two would have a chance to meet on stage for the first time, when both Bruce and Bryan appeared at the closing ceremony of the 2017 Invictus Games in Toronto.
After Bruce played his own brief acoustic set that late September night, the only real question was whether he’d come out and play with Bryan. When he did, it was obvious which song they’d play (well, obvious if you’d seen that 2010 performance anyway).
Here’s that wonderfully filmed Bruce and Bryan performance of “Cuts Like a Knife” from Invictus Games 2017.
[Youtube: Bryan Adams & Bruce Springsteen performing "Cut's A Knife & “Badlands"](https://www.youtube.com/watch?v=AUTmqptb-XY)
![](https://www.youtube.com/watch?v=AUTmqptb-XY)
**Cuts Like a Knife**
**First performed:** May 13, 2010 (New York City, NY)
**Last performed:** September 30, 2017 (Toronto, ON)