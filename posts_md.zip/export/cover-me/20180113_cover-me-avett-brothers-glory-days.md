# Cover Me, Avett Brothers: Glory Days
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/01/13/cover-me-avett-brothers-glory-days/
#### Published: January 13, 2018
#### Last Updated: January 13, 2018
![avetts.jpg](https://estreetshuffle.com/wp-content/uploads/2018/01/avetts.jpg)

The Avett Brothers used to play Springsteen’s “Glory Days” fairly frequently in concert. Here’s a fun professionally shot (if not staged) performance of it. Happy Saturday!
[Youtube: The Avett Brothers "Glory Days" - Hangin' Out On E Street](https://www.youtube.com/watch?v=kmWIxnVBU7w)
![](https://www.youtube.com/watch?v=kmWIxnVBU7w)