# Cover Me, Diarrhea Planet and Harry Kagan: Born to Run
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2020/02/12/cover-me-diarrhea-planet-and-harry-kagan-born-to-run/
#### Published: February 12, 2020
#### Last Updated: February 08, 2020
![maxresdefault.jpg](https://estreetshuffle.com/wp-content/uploads/2020/02/maxresdefault.jpg)

Prepare yourself for the absolute best freaking cover of “Born to Run” ever.
Nashville rockers Diarrhea Planet are no strangers to Bruce’s signature song–they’d covered it in concert years before their mic drop performance as the closers for Nashville’s Freakin’ Weekend in 2017.
But add Music Band’s Harry Kagan on lead vocals, and the incredible Ross Holmes from Mumford & Sons on fiddle (he darn near steals the show with his incredible solo), and the band’s already incredible cover takes off into the stratosphere.
Seriously: turn up the volume, switch to full screen mode, and just take it all in:
[Youtube: Diarrhea Planet "Born To Run" Live @ Exit/In Freakin' Weekend VIII (1080p)](https://www.youtube.com/watch?v=jYHiTyBsdHI)
![](https://www.youtube.com/watch?v=jYHiTyBsdHI)
See what I mean? Sadly, Diarrhea Planet is no more–the band broke up in 2018. But at least we have this incredible performance to remember them by.
Just be careful not to mentally juxtapose the name of the band and the song, though, or else you may never hear “Born to Run” the same way again.