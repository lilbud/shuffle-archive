# Cover Me, Roger Daltrey: Born to Run
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/09/13/cover-me-roger-daltrey-born-to-run/
#### Published: September 13, 2018
#### Last Updated: September 13, 2018
![daltrey.jpg](https://estreetshuffle.com/wp-content/uploads/2018/09/daltrey.jpg)

It may have taken him two attempts to get started, but dang–Roger Daltrey absolutely *nails* his “Born to Run” cover.
[Youtube: Roger Daltrey covers Born to Run by Bruce Springsteen](https://www.youtube.com/watch?v=JNyut-S5fWs)
![](https://www.youtube.com/watch?v=JNyut-S5fWs)
I’m not sure exactly when and where this performance happened (if you do, please drop me a line), but you can find it on Daltrey’s *Moonlighting* and *Gold* CDs.
Want to see Bruce return the compliment? Check out his performances of “[My Generation](http://estreetshuffle.com/index.php/2018/03/27/matr-pete-townshend-roger-daltry-and-bruce-springsteen-my-generation/)” and “[Won’t Get Fooled Again.](http://estreetshuffle.com/index.php/2018/08/30/meeting-across-the-river-bruce-springsteen-and-the-who-wont-get-fooled-again/)“