# Back in the U.S.A.
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/1976/01/03/cover-me-back-in-the-u-s-a/
#### Published: January 03, 1976
#### Last Updated: November 15, 2025
![backinus.jpg](https://estreetshuffle.com/wp-content/uploads/1976/01/backinus.jpg)

Bruce Springsteen has covered almost two dozen Chuck Berry tunes in concert, but none with more gusto than “Back in the U.S.A.” (Perhaps “[Little Queenie](http://estreetshuffle.com/index.php/2018/12/11/cover-me-little-queenie/)” is tied for first, though.)
Bruce played it occasionally on the Born to Run Tour, closing his legendary Main Point show with it on February 5th.
[Youtube: Bruce Springsteen - "Back in the USA" - 1975-02-05](https://www.youtube.com/watch?v=UPocmHcX2tw)
![](https://www.youtube.com/watch?v=UPocmHcX2tw)
Originally released in 1959, Berry’s ode to hamburgers at the corner cafe (or at least that’s what you would think it was about based on Bruce’s performance of it) just barely cracked the Top 40, but that was high enough to capture Bruce’s attention.
[Youtube: Back In The U.S.A.](https://www.youtube.com/watch?v=JbZ4T_noAtA)
![](https://www.youtube.com/watch?v=JbZ4T_noAtA)
The song would go on to chart once more–higher even–when Linda Ronstadt covered it three years later, but no one could quite match the energy and passion for burgers that Bruce brought to it back in 1975.
**Back in the U.S.A.**
**First performed:** February 5, 1975 (Bryn Mawr, PA)
**Last performed:** December 27, 1975 (Philadelphia, PA)
(c) March 11, 2019