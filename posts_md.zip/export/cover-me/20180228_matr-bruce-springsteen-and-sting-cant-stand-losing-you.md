# MatR: Bruce Springsteen and Sting, "Can't Stand Losing You"
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/02/28/matr-bruce-springsteen-and-sting-cant-stand-losing-you/
#### Published: February 28, 2018
#### Last Updated: April 13, 2019
![cantstand.jpg](https://estreetshuffle.com/wp-content/uploads/2018/02/cantstand.jpg)

A one-time-only performance: Bruce and Sting perform the Police classic “Can’t Stand Losing You” on the eve of Sting’s 60th birthday, October 1, 2011.
[Youtube: Bruce Springsteen 2011-10-01 Sting's Birthday](https://www.youtube.com/watch?v=drRydmHvI0I)
![](https://www.youtube.com/watch?v=drRydmHvI0I)
The original, of course, was by Sting’s former band, The Police. Released in 1978 as the follow-up single to the monumentally popular “Roxanne,” “Can’t Stop Losing You” stopped one spot shy of the top of the U.K. chart the following year.
[Youtube: The Police - Can't Stand Losing You (Official Music Video)](https://www.youtube.com/watch?v=nH0vjLwMyc4)
![](https://www.youtube.com/watch?v=nH0vjLwMyc4)
**Can’t Stand Losing You**
**First Performed:** October 1, 2011 (New York City, NY)
**Last Performed:** October 1, 2011 (New York City, NY)