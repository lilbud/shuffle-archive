# Cover Me, Ani DiFranco: Used Cars
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/06/02/cover-me-ani-difranco-used-cars/
#### Published: June 02, 2018
#### Last Updated: November 30, 2020
![ani-e1525645475895.jpg](https://estreetshuffle.com/wp-content/uploads/2018/05/ani-e1525645475895.jpg)

In 2000, Subpop released a tribute album to Bruce’s *Nebraska.* It’s a gorgeous album, and one of the stronger tracks on it is this haunting cover of “[Used Cars](https://estreetshuffle.com/index.php/2019/06/13/roll-of-the-dice-used-cars/)” by Ani DiFranco.
[Youtube: tribute Used Cars Bruce Springsteen par Ani di Franco](https://www.youtube.com/watch?v=2cg0-brnMuM)
![](https://www.youtube.com/watch?v=2cg0-brnMuM)