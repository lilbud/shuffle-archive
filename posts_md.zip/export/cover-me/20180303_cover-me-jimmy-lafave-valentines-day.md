# Cover Me, Jimmy LaFave: Valentine's Day
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/03/cover-me-jimmy-lafave-valentines-day/
#### Published: March 03, 2018
#### Last Updated: March 09, 2019
![lafave.jpg](https://estreetshuffle.com/wp-content/uploads/2018/02/lafave.jpg)

From Jimmy LaFave’s 1999 release, *Trail*, comes this faithful cover of Bruce’s “[Valentine’s Day](http://estreetshuffle.com/index.php/2018/06/12/roll-of-the-dice-valentines-day/).”
[Youtube: Valentine's Day](https://www.youtube.com/watch?v=qFd6VzkQHTo)
![](https://www.youtube.com/watch?v=qFd6VzkQHTo)