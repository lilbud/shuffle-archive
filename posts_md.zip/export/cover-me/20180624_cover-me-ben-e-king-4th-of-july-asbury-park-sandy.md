# Cover Me, Ben E. King: 4th of July, Asbury Park (Sandy)
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/06/24/cover-me-ben-e-king-4th-of-july-asbury-park-sandy/
#### Published: June 24, 2018
#### Last Updated: November 28, 2019
![ben-e-king-4th-of-july-asbury-park-sandy-the-right-stuff-e1529355386275.jpg](https://estreetshuffle.com/wp-content/uploads/2018/06/ben-e-king-4th-of-july-asbury-park-sandy-the-right-stuff-e1529355386275.jpg)

Turns out that “[4th of July, Asbury Park (Sandy)](http://estreetshuffle.com/index.php/2019/04/26/roll-of-the-dice-4th-of-july-asbury-park-sandy/)” works *perfectly* in a Drifters-style arrangement. Ben E. King tackled it on a 1997 tribute album, and his soaring vocals carry us skyward.
[Youtube: Ben E. King - 4th July,Asbury Park (Sandy)](https://www.youtube.com/watch?v=Dt9lvu4yTPs)
![](https://www.youtube.com/watch?v=Dt9lvu4yTPs)