# Cover Me, Carolyne Mas: New York City Serenade
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/04/06/cover-me-carolyne-mas-new-york-city-serenade/
#### Published: April 06, 2018
#### Last Updated: April 06, 2018
![nycmas.jpg](https://estreetshuffle.com/wp-content/uploads/2018/04/nycmas.jpg)

Carolyne Mas used to get called “the female Springsteen” (if you’ve never seen her live performances, google her videos and you’ll understand why).
When she finally covered one of Bruce’s songs, however, she went old school and acoustic. Listen–just listen–to her gorgeous, magnetic take on “New York City Serenade.”
[Youtube: NYC SERENADE](https://www.youtube.com/watch?v=J7a_XNjyMWw)
![](https://www.youtube.com/watch?v=J7a_XNjyMWw)