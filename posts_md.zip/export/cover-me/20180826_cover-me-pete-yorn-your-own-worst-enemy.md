# Cover Me, Pete Yorn: Your Own Worst Enemy
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/08/26/cover-me-pete-yorn-your-own-worst-enemy/
#### Published: August 26, 2018
#### Last Updated: December 03, 2020
![peteyorn.jpg](https://estreetshuffle.com/wp-content/uploads/2018/08/peteyorn.jpg)

Ten points to Pete Yorn for choosing one of the best tracks (but least played) from Bruce’s *Magic* album: “[Your Own Worst Enemy.](https://estreetshuffle.com/index.php/2020/05/31/roll-of-the-dice-your-own-worst-enemy/)”
Another 10 points for his beautiful guitar work and deeply felt vocals.
Minus 5 for not understanding the song.
Still a great cover, though.
[Youtube: Pete Yorn "Your Own Worst Enemy" - Hangin' Out On E Street](https://www.youtube.com/watch?v=fSc4KAOUY2w)
![](https://www.youtube.com/watch?v=fSc4KAOUY2w)