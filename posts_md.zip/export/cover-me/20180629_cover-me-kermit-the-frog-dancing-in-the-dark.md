# Cover Me, Kermit the Frog: Dancing in the Dark
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/06/29/cover-me-kermit-the-frog-dancing-in-the-dark/
#### Published: June 29, 2018
#### Last Updated: December 28, 2022
![kermit.jpg](https://estreetshuffle.com/wp-content/uploads/2018/06/kermit.jpg)

In honor of the anniversary of the release of [Bruce’s most well-known video](https://estreetshuffle.com/index.php/2021/12/25/roll-of-the-dice-dancing-in-the-dark/), here’s one of my favorite homages, from *Muppets Tonight* in 1996. Courtney Cox, eat your heart out.
[Youtube: Muppets Tonight - Dancin' in the Dark](https://www.youtube.com/watch?v=8mNyZVbSv5g)
![](https://www.youtube.com/watch?v=8mNyZVbSv5g)