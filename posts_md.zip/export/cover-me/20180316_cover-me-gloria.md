# Cover Me: Gloria
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/16/cover-me-gloria/
#### Published: March 16, 2018
#### Last Updated: December 12, 2021
![gloria.jpg](https://estreetshuffle.com/wp-content/uploads/2018/03/gloria.jpg)

“Gloria” is a riff-rock classic that’s perfectly suited for the E Street Band’s guitar-heavy arsenal. It’s turned up in Bruce’s setlist more than a dozen times over the years, and that’s *not* including its frequent mini-appearance as a lead-in to “[She’s the One](https://estreetshuffle.com/index.php/2021/04/04/roll-of-the-dice-shes-the-one/).” It’s clearly a significant song for Bruce, as you can hear in this conversation between Bruce and Steve from the Underground Garage in 2011.
[Youtube: Bruce and Steve discuss "Them"](https://www.youtube.com/watch?v=fUKe6X-W0F4)
![](https://www.youtube.com/watch?v=fUKe6X-W0F4)
Bruce may have bought the single on instinct, but as he says as above, “When that hit, once that hit, if you couldn’t play it, you didn’t get a gig.”
So play it they did. There are plenty of video clips to choose from, but I’m partial to this one from a few years ago–it’s nice and close up, with great audio.
[Youtube: Gloria - Springsteen - Tampa, FL - May 1, 2014](https://www.youtube.com/watch?v=C5aQz_6tC6U)
![](https://www.youtube.com/watch?v=C5aQz_6tC6U)
Here’s the original 1964 B-side(!) by Them.
[Youtube: Them - Gloria (Original version)](https://www.youtube.com/watch?v=WkaMVLHxzWE)
![](https://www.youtube.com/watch?v=WkaMVLHxzWE)
**Gloria****First performed:** December 26, 1975 (New York City, NY)
**Last performed:** May 1, 2014 (Tampa, FL)