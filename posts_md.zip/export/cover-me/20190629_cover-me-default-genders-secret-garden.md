# Cover Me, Default Genders: Secret Garden
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/06/29/cover-me-default-genders-secret-garden/
#### Published: June 29, 2019
#### Last Updated: June 29, 2019
![defaultgen.jpg](https://estreetshuffle.com/wp-content/uploads/2019/06/defaultgen.jpg)

I’ve covered covers of Springsteen songs going back to the beginning of Bruce’s career on this site, but here’s one of the newest ones.
Earlier this year, EDM artist James Brooks (no, not *that* James Brooks) released a new album, *Main Pop Girl 2019*, under the name Default Genders (he’d previously gone under the names Dead Girlfriends and as part of a duo called Elite Gymnastics). Buried in the middle of it is a, shall we say, liberal cover of Bruce’s “[Secret Garden](http://estreetshuffle.com/index.php/2019/05/30/roll-of-the-dice-secret-garden/)” (playfully called “Secret Garden .NUXX” here).
Brooks’ version is *very* nineties. Yes, I know that’s the era that Bruce’s original hails from too, but give a listen below and you’ll see what I mean.
[Youtube: default genders - secret garden .NUXX](https://www.youtube.com/watch?v=p6mCaNyCdqk)
![](https://www.youtube.com/watch?v=p6mCaNyCdqk)
If you’re not an EDM fan, you probably don’t care for this one. But in his own way, Brooks retains the yearning, disorienting feel of Bruce’s original version while taking the song in a bold new direction.