# Cover Me, Dean Ford: The Fever
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/05/18/cover-me-dean-ford-the-fever/
#### Published: May 18, 2018
#### Last Updated: November 28, 2020
![deanfordfever.jpg](https://estreetshuffle.com/wp-content/uploads/2018/05/deanfordfever.jpg)

Way back in 1977, Dean Ford took a swing at “[The Fever](https://estreetshuffle.com/index.php/2020/10/04/roll-of-the-dice-the-fever/).” It’s a very faithful cover–Ford never strays from the original arrangement–but it’s very nicely done.
[Youtube: Dean Ford (Marmalade) The Fever.wmv](https://www.youtube.com/watch?v=cU9IeMGACRk)
![](https://www.youtube.com/watch?v=cU9IeMGACRk)