# Cover Me, Ryan Bingham: Atlantic City
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/09/25/cover-me-ryan-bingham-atlantic-city/
#### Published: September 25, 2018
#### Last Updated: September 26, 2018
![bingham.jpg](https://estreetshuffle.com/wp-content/uploads/2018/09/bingham.jpg)

Singer/songwriter Ryan Bingham already had the talent, voice and sensibilities to nail his cover of “[Atlantic City](http://estreetshuffle.com/index.php/2018/06/04/roll-of-the-dice-atlantic-city/).”
But capturing Bruce’s original *Nebraska* vibe through his arrangement, home studio and iPhone video filter? That’s just golden.
[Youtube: Ryan Bingham Covers Bruce Springsteen's Atlantic City Bootleg #15](https://www.youtube.com/watch?v=pnsmb4SjZVs)
![](https://www.youtube.com/watch?v=pnsmb4SjZVs)