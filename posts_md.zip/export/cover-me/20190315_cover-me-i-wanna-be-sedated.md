# Cover Me: I Wanna Be Sedated
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/03/15/cover-me-i-wanna-be-sedated/
#### Published: March 15, 2019
#### Last Updated: January 01, 2024
![sedated.jpg](https://estreetshuffle.com/wp-content/uploads/2019/03/sedated.jpg)

We’ll get to the Springsteen connection in a minute; for the moment, you’ll need to excuse me while I rock out to the greatest punk band ever. Turn up the volume and join me, won’t you?
[Youtube: Ramones - I Wanna Be Sedated (Official Music Video)](https://www.youtube.com/watch?v=bm51ihfi1p4)
![](https://www.youtube.com/watch?v=bm51ihfi1p4)
Whew. Okay, now we can proceed.
“I Wanna Be Sedated” is one of those songs that will absolutely stop me in the tracks of whatever I was doing at the time so I can dance with abandon around the house singing “ba ba baba, baba ba baba…” Who doesn’t love to do that?
Apparently Bruce does, because he didn’t hesitate to grab the sign request for The Ramones’ classic crowd-pleaser when a fan raised it at Bruce’s second show in Boston on the Working on a Dream Tour.
After taking a moment or ten to work out the song with the band, they barrel-rolled through it, as loose and woolly as the song deserves. Take a listen:
[http://estreetshuffle.com/wp-content/uploads/2019/03/2009-04-22-D1Track10-I-Wanna-Be-Sedated-online-audio-converter.com_.mp3?_=1](http://estreetshuffle.com/wp-content/uploads/2019/03/2009-04-22-D1Track10-I-Wanna-Be-Sedated-online-audio-converter.com_.mp3?_=1)
<http://estreetshuffle.com/wp-content/uploads/2019/03/2009-04-22-D1Track10-I-Wanna-Be-Sedated-online-audio-converter.com_.mp3>
(Oh, and a fun fact about that brilliant video at the top of the post: that’s a very young Courtney Love playing the role of the bride.)
A true one-off performance, that was–Bruce has never played “I Wanna Be Sedated” before or since.
**I Wanna Be Sedated**
**First performed:** April 22, 2009 (Boston, MA)
**Last performed:** April 22, 2009 (Boston, MA)