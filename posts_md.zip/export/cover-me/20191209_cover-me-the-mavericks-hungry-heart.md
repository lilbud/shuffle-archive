# Cover Me, The Mavericks: Hungry Heart
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/12/09/cover-me-the-mavericks-hungry-heart/
#### Published: December 09, 2019
#### Last Updated: January 01, 2023
![Mavericks_PlayTheHits_3000px.jpg](https://estreetshuffle.com/wp-content/uploads/2019/12/Mavericks_PlayTheHits_3000px.jpg)

The Mavericks are certainly no stranger to Bruce’s catalog–[their cover of “All That Heaven Will Allow”](http://estreetshuffle.com/index.php/2019/02/28/cover-me-the-mavericks-all-that-heaven-will-allow/) is one of the finer Springsteen covers out there.
Now they’re at it again: just a couple of months ago they released their latest album, an all-covers compilation entitled *Play the Hits*.
This time, the band turns their attention to “[Hungry Heart](https://estreetshuffle.com/index.php/2022/12/21/roll-of-the-dice-hungry-heart/),” giving it an infectious country-ska treatment. (I don’t know if that’s a thing, but it sure sounds like it to me.)
[Youtube: Hungry Heart](https://www.youtube.com/watch?v=MXzUfPVF08o)
![](https://www.youtube.com/watch?v=MXzUfPVF08o)
It’s not surprising to see the band lavishing love an attention on Bruce’s songs–they’re clearly big fans. And don’t just take that from me:
[Youtube: Ask The Mavs #1 // Springsteen](https://www.youtube.com/watch?v=2ct4WG3v43I)
![](https://www.youtube.com/watch?v=2ct4WG3v43I)
Let’s hope their wish comes true and Bruce joins them on stage sometime soon. I’d love to see how Bruce would take to an arrangement like this one.
[Youtube: The Mavericks - "Hungry Heart" (SEC Armadillo, Glasgow, 2019)](https://www.youtube.com/watch?v=x73lHHHlolY)
![](https://www.youtube.com/watch?v=x73lHHHlolY)