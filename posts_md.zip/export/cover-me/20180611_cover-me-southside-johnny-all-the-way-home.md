# Cover Me, Southside Johnny: All the Way Home
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/06/11/cover-me-southside-johnny-all-the-way-home/
#### Published: June 11, 2018
#### Last Updated: November 28, 2019
![ssj-e1528500941697.jpg](https://estreetshuffle.com/wp-content/uploads/2018/06/ssj-e1528500941697.jpg)

If you only know “[All the Way Home](http://estreetshuffle.com/index.php/2019/09/08/roll-of-the-dice-all-the-way-home/)” from the *Devils & Dust* album, then you don’t know its original arrangement and best performance.
From Southside Johnny’s 1991 *Better Days* LP, this is the definitive version of “All the Way Home.” The lyrics are a bit different, but it’s the melody and the band that transform this into powerful romantic ballad.
(Listen carefully–you’ll hear Bruce on backing vocals and keyboard.)
[Youtube: All The Way Home](https://www.youtube.com/watch?v=MaXBYo7hHdg)
![](https://www.youtube.com/watch?v=MaXBYo7hHdg)