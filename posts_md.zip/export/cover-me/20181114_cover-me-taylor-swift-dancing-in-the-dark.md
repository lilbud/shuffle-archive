# Cover Me, Taylor Swift: Dancing in the Dark
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/11/14/cover-me-taylor-swift-dancing-in-the-dark/
#### Published: November 14, 2018
#### Last Updated: January 01, 2023
![Taylor-and-Bruce.jpg](https://estreetshuffle.com/wp-content/uploads/2018/11/Taylor-and-Bruce.jpg)

Now here’s an unlikely cover: when her Speak Now World Tour made a stop in Newark on July 20, 2011, superstar Taylor Swift paid homage to her New Jersey songwriting influencers:
[Youtube: Dancing in the Dark (Cover) / Livin' on a Prayer (Cover) - Taylor Swift 7/20/11](https://www.youtube.com/watch?v=-qinVezgFAI)
![](https://www.youtube.com/watch?v=-qinVezgFAI)
Yeah, I know it’s just a snippet, but it’s still pretty cool.
And lest you think that she’s pandering to the locals, T-Swizzle is indeed a B-Sprizzle fan. And it seems like Bruce reciprocates–watch Bruce delight Taylor by playing “[Dancing in the Dark](https://estreetshuffle.com/index.php/2021/12/25/roll-of-the-dice-dancing-in-the-dark/)” on her guitar backstage at her show in Raleigh a few months later.
[Youtube: Exclusive! Taylor Swift's Springsteen Story on Ellen show](https://www.youtube.com/watch?v=fOpbhV-aLew)
![](https://www.youtube.com/watch?v=fOpbhV-aLew)