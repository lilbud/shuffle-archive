# Cover Me: Oh Boy
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/05/17/cover-me-oh-boy/
#### Published: May 17, 2018
#### Last Updated: November 28, 2020
![ohboy.jpg](https://estreetshuffle.com/wp-content/uploads/2018/05/ohboy.jpg)

“Oh Boy!” was originally written and recorded by Sonny West, but it was Buddy Holly and the Crickets’ version that broke through to become a hit (peaking at number 10 in the US) and an enduring classic.
Bruce counts Buddy Holly among his big influences, so it’s not surprising that Bruce performed “Oh Boy” a few times during the Darkness on the Edge of Town tour.
Here’s the last performance from that tour, from the August 4, 1978 show in Charleston, West Virginia.
[Youtube: 1. Oh Boy (Bruce Springsteen- Live In Charleston 8-4-1978)](https://www.youtube.com/watch?v=KVtZ8m3fyZY)
![](https://www.youtube.com/watch?v=KVtZ8m3fyZY)
You’re probably familiar with Buddy Holly’s version already–so here’s the Sonny West original.
[Youtube: All My Love aka Oh Boy -  Sonny West  (on intro) 1957 Atlantic (ORIGINAL VERSIONS)](https://www.youtube.com/watch?v=TlcjdSJwI5k)
![](https://www.youtube.com/watch?v=TlcjdSJwI5k)
**Oh Boy
First performed:** July 29, 1978 (St. Petersburg, FL)
**Last performed:** March 17, 1996 (Dublin, Ireland)