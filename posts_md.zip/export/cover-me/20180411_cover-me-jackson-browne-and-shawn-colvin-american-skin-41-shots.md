# Cover Me, Jackson Browne and Shawn Colvin: American Skin (41 Shots)
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/04/11/cover-me-jackson-browne-and-shawn-colvin-american-skin-41-shots/
#### Published: April 11, 2018
#### Last Updated: November 26, 2019
![colvin-9.jpg](https://estreetshuffle.com/wp-content/uploads/2018/04/colvin-9.jpg)

Jackson Browne and Shawn Colvin toured together a couple of years back. Both fans of Springsteen (Jackson and Bruce are longtime friends, and [Shawn recorded “Tougher Than the Rest”](http://estreetshuffle.com/index.php/2018/05/09/cover-me-shawn-colvin-tougher-than-the-rest/) for her 2015 covers album), it was pretty much a given for them to team up on a Bruce cover.
They chose “American Skin (41 Shots),” as timely then as it is now. Here’s a great performance of it from Golden Gate Park in October 2016.
[Youtube: Jackson Browne w/ Shawn Colvin, American Skin, Hardly Strictly, Golden Gate Park 2016](https://www.youtube.com/watch?v=2FEfa_N-mno)
![](https://www.youtube.com/watch?v=2FEfa_N-mno)