# Cover Me: Sentimental Journey
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/03/18/cover-me-sentimental-journey/
#### Published: March 18, 2019
#### Last Updated: March 18, 2019
![sentimental.jpg](https://estreetshuffle.com/wp-content/uploads/2019/03/sentimental.jpg)

Today’s covered-by-Bruce entry is certainly an unlikely one:
Sure, “Sentimental Journey” was a number one hit for Doris Day in 1945 and spent a remarkable 23 weeks on the charts. But it was a mellow big band standard, more likely to be covered by fellow New Jerseyan Frank Sinatra (who did in fact cover it, of course) than Bruce Springsteen.
[Youtube: Doris Day A Sentimental Journey](https://www.youtube.com/watch?v=PUw125JMVFI)
![](https://www.youtube.com/watch?v=PUw125JMVFI)
And yet cover it he did, with the E Street Band during a radio station appearance forty-five years ago–so early that the band didn’t even have their name yet.
From March 9, 1974 at Station KLOL-FM in Houston, in crystal clarity, here’s Bruce Springsteen and the E Street Band’s one and only performance of “Sentimental Journey.”*
[Youtube: Bruce Springsteen- Sentimental Journey (The Lost Radio Show)](https://www.youtube.com/watch?v=w09LawN2qZw)
![](https://www.youtube.com/watch?v=w09LawN2qZw)
*There is a surviving but undated setlist from Bruce’s high school days with The Castiles that indicates he may have played “Sentimental Journey” at a wedding in 1965 (Bruce would have *just* turned sixteen), but it cannot be definitively dated and no recording exists.
**Sentimental Journey**
First performed: March 9, 1974 (Houston, TX)
Last performed: March 9, 1974 (Houston, TX)