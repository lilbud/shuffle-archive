# Cover Me, Catie Curtis: If I Should Fall Behind
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/28/cover-me-catie-curtis-if-i-should-fall-behind/
#### Published: March 28, 2018
#### Last Updated: March 09, 2019
![inmyroom.jpg](https://estreetshuffle.com/wp-content/uploads/2018/03/inmyroom.jpg)

I’m a big Catie Curtis fan, so I’ve known and loved her cover of “[If I Should Fall Behind](http://estreetshuffle.com/index.php/2018/06/01/roll-of-the-dice-if-i-should-fall-behind/)” for years, since its appearance on a 2010 benefit album. But until I went searching for a youtube link to include, I’d never seen this video of her recording the song (and from the looks of the view count, not may other people have either).
This is the exact take that’s on the album, and it’s fascinating to see her record it live.
[Youtube: If I Should Fall Behind](https://www.youtube.com/watch?v=aFNaQ23r-IM)
![](https://www.youtube.com/watch?v=aFNaQ23r-IM)