# Cover Me, Marc Broussard: Back in Your Arms
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/07/05/cover-me-marc-broussard-back-in-your-arms/
#### Published: July 05, 2018
#### Last Updated: November 28, 2019
![broussard-e1530503932120.jpg](https://estreetshuffle.com/wp-content/uploads/2018/07/broussard-e1530503932120.jpg)

From the 2003 “Light of Day” tribute album, here’s Marc Broussard’s soulful, horn-fueled take on “[Back in Your Arms](http://estreetshuffle.com/index.php/2019/11/10/roll-of-the-dice-back-in-your-arms/).” It’s a very different arrangement than Bruce’s, but it works extremely well.
[Youtube: Back in Your Arms](https://www.youtube.com/watch?v=JYJimIqSkOw)
![](https://www.youtube.com/watch?v=JYJimIqSkOw)