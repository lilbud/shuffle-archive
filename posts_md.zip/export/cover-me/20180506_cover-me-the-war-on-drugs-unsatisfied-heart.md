# Cover Me, The War on Drugs: Unsatisfied Heart
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/05/06/cover-me-the-war-on-drugs-unsatisfied-heart/
#### Published: May 06, 2018
#### Last Updated: November 28, 2020
![TheWaronDrugs_1300x620_NEW-2c9d59a076-e1525581634994.jpg](https://estreetshuffle.com/wp-content/uploads/2018/05/TheWaronDrugs_1300x620_NEW-2c9d59a076-e1525581634994.jpg)

I try to steer clear of current events on this blog, even Bruce-related ones–the vault of past treasures is deep enough to keep me busy for years.
But I’m a sucker for a good cover of an obscure Bruce song, and this one from three weeks ago is as obscure as it gets:
Never released, never performed: Bruce Springsteen’s “[Unsatisfied Heart](https://estreetshuffle.com/index.php/2018/09/12/roll-of-the-dice-unsatisfied-heart/),” performed in San Diego by The War on Drugs on April 15, 2018. Looks like they know where to find the great bootlegs!
https://youtu.be/3NP7AJjt3gk