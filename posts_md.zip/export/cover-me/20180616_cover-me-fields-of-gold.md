# Cover Me: Fields of Gold
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/06/16/cover-me-fields-of-gold/
#### Published: June 16, 2018
#### Last Updated: April 14, 2019
![fields-1.jpg](https://estreetshuffle.com/wp-content/uploads/2018/06/fields-1.jpg)

Sting celebrated his 60th birthday in 2011 by throwing himself a party at the Beacon Theater in New York City (a benefit for the Rainforest Fund). Bruce was in attendance to celebrate his old friend, and he paid tribute by covering Sting’s classic, “Fields of Gold.”
[Youtube: Bruce Springsteen - Fields of Gold @ Stings 60th Birthday Party at Beacon NYC 10/1/2011](https://www.youtube.com/watch?v=xSfPSkgtf_g)
![](https://www.youtube.com/watch?v=xSfPSkgtf_g)
Bruce gave a lovely performance, but it’s hard to top the original.
[Youtube: Sting - Fields Of Gold](https://www.youtube.com/watch?v=KLVq0IAzh1A)
![](https://www.youtube.com/watch?v=KLVq0IAzh1A)
**Fields of Gold
First performed:** October 1, 2011 (New York City, NY)
**Last performed:** October 1, 2011 (New York City, NY)