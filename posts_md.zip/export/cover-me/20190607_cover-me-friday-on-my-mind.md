# Cover Me: Friday on My Mind
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/06/07/cover-me-friday-on-my-mind/
#### Published: June 07, 2019
#### Last Updated: December 17, 2021
![easybeats.jpg](https://estreetshuffle.com/wp-content/uploads/2019/06/easybeats.jpg)

> “When I wrote [“Out in the Street”] I was trying to copy one of my all time favorite songs, “Friday On My Mind” by the Easybeats. I have always loved that song. The structure on that is just incredible, and it had that unbelievable exhilaration when they broke into the chorus. You know, its Friday and you are out of school or out of work and you’re just *out there*!” — Bruce Springsteen to Molly Meldrum, April 7, 1995
The Easybeats’ “Friday On My Mind” may have only reached #16 in the U.S., but it was a bona fide smash hit around the world, peaking at #6 in the U.K. and #1 in Australia.
The 1966 single was voted the best Australian song of all time and is easily the band’s greatest hit. (While “Friday on My Mind” is the only Easybeats song to crack the U.S. Top 40, the band has a whopping fourteen other Top 40 singles in their native Australia.)
[Youtube: The Easybeats - Friday On My Mind (French TV, 1967) 1080p HD](https://www.youtube.com/watch?v=dnqxbdnzlhw)
![](https://www.youtube.com/watch?v=dnqxbdnzlhw)
When Bruce brought the High Hopes Tour to Sydney in the summer of 2014, he decided to pay homage to The Easybeats by opening the show with his cover of “Friday on My Mind.” It was the first of only two performances ever, and we’re lucky that Bruce had it professionally filmed. Check it out below.
[Youtube: Bruce Springsteen- The Easybeats' "Friday On My Mind" - (Sydney, 02/19/14)](https://www.youtube.com/watch?v=iMMpSiG57Zo)
![](https://www.youtube.com/watch?v=iMMpSiG57Zo)
Wondering how you follow up a show opener like that? If you’re Bruce, you give a little wink and segue directly into your own attempt at the same song: “[Out in the Street](https://estreetshuffle.com/index.php/2021/10/28/roll-of-the-dice-out-in-the-street/).”
**Friday on My Mind**
**First performed:** February 19, 2014 (Sydney, Australia)
**Last performed:** February 22, 2014 (Hunter Valley, Australia)