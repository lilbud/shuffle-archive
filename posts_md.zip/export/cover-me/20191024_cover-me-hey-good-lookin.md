# Cover Me: Hey, Good Lookin'
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/10/24/cover-me-hey-good-lookin/
#### Published: October 24, 2019
#### Last Updated: January 02, 2024
![hey-good.jpg](https://estreetshuffle.com/wp-content/uploads/2019/10/hey-good.jpg)

By now, we shouldn’t be surprised at the range of covers Bruce Springsteen is prone to playing in concert.
Still, “Hey, Good Lookin’,” Hank Williams’ #1 country hit from 1951, seems like one of the least likely contenders. (It’s certainly tough to imagine a fan bringing a sign for it.)
[Youtube: Hank Williams - Hey Good Lookin' (Official Video)](https://www.youtube.com/watch?v=bjCoKslQOEs)
![](https://www.youtube.com/watch?v=bjCoKslQOEs)
Bruce did play it live, though–one time only–and it wasn’t even on the Seeger Sessions Tour where one might expect it.
Nope, this one was in Asbury Park, at Bruce’s last show of the 20th century.
I wrote about that show last month when I shared Bruce’s soundchecked cover of another Hank Williams song, “[Jambalaya (On the Bayou)](http://estreetshuffle.com/index.php/2019/09/14/cover-me-jambalaya-on-the-bayou/).” Bruce’s cover of “Hey Good Lookin'” comes from the same rehearsal–in fact, it immediately followed “Jambalaya,” making for a Hank Williams double-header.
It’s more than a bit loose and messy, but that’s part of the charm. Take a listen to Bruce, Patti, Garry, Nils, Soozie, Lisa Lowell, and Southside Johnny on the harp having a ball and falling all over themselves:
[Youtube: Bruce Springsteen - HEY GOOD LOOKIN 2000 (audio)](https://www.youtube.com/watch?v=4Nbuk-j3VLw)
![](https://www.youtube.com/watch?v=4Nbuk-j3VLw)
**Hey, Good Lookin’
First performed:** December 18, 2000 (Asbury Park, NJ)
**Last performed:** December 18, 2000 (Asbury Park, NJ)