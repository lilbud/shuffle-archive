# Cover Me, The Pointer Sisters: The Fever
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/06/16/cover-me-the-pointer-sisters-the-fever/
#### Published: June 16, 2019
#### Last Updated: December 12, 2020
![priority.jpg](https://estreetshuffle.com/wp-content/uploads/2019/06/priority.jpg)

The Pointer Sisters’ version of “[The Fever](https://estreetshuffle.com/index.php/2020/10/04/roll-of-the-dice-the-fever/)” has long been one of my favorite Springsteen covers. It’s not that they bring anything new to the table–their arrangement is very close to the original, in fact.
It’s just that they bring so much *heat.*
Check it out in this video (which I only just discovered as I wrote this post–I never knew there was a high-quality video of it until now), and you’ll see what I mean.
[Youtube: Pointer Sisters - (She's Got) The Fever • TopPop](https://www.youtube.com/watch?v=DL126FttZFs)
![](https://www.youtube.com/watch?v=DL126FttZFs)
She’s got the fever, indeed.
You can find the studio version on The Pointer Sisters’ 1979 studio album, *Priority*.