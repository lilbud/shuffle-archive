# Cover Me, Minnie Driver: Hungry Heart
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/07/25/cover-me-minnie-driver-hungry-heart/
#### Published: July 25, 2019
#### Last Updated: January 01, 2023
![hungry-heart.jpg](https://estreetshuffle.com/wp-content/uploads/2019/07/hungry-heart.jpg)

She’s much better known as an actress, but Minnie Driver’s also a singer-songwriter with three albums under her belt.
Minnie released her first album, *Everything I’ve Got in My Pocket,* in 2004. Accompanying the ten original compositions on that album is a lovely cover of Bruce’s “[Hungry Heart.](https://estreetshuffle.com/index.php/2022/12/21/roll-of-the-dice-hungry-heart/)”
The arrangement is lovely: all slow, soft piano and drum brush. I can’t honestly say it suits the lyrics, but then again, neither does Bruce’s original arrangement, so no stones thrown from where I sit.
Take a listen below.
[Youtube: Hungry Heart](https://www.youtube.com/watch?v=5X67svLMJn8)
![](https://www.youtube.com/watch?v=5X67svLMJn8)