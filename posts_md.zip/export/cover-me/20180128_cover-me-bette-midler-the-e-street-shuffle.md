# Cover Me, Bette Midler: The E Street Shuffle
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/01/28/cover-me-bette-midler-the-e-street-shuffle/
#### Published: January 28, 2018
#### Last Updated: November 25, 2020
![bette.jpg](https://estreetshuffle.com/wp-content/uploads/2018/01/bette.jpg)

Oh my.
Never have I seen a Springsteen cover start with so much promise only to go so horribly wrong.
From *Divine Madness*, Bette Midler covers Bruce’s slow arrangement of “[The E Street Shuffle](https://estreetshuffle.com/index.php/2020/06/06/roll-of-the-dice-the-e-street-shuffle/)” that he would occasionally perform in the early-to-mid-seventies, and she actually does a fine job of it… for about two minutes.
[Youtube: Bette Midler-E Street Shuffle/Leader of the Pack](https://www.youtube.com/watch?v=xJEH9K04U5g)
![](https://www.youtube.com/watch?v=xJEH9K04U5g)