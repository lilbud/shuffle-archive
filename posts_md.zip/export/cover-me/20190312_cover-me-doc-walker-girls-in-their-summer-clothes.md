# Cover Me, Doc Walker: Girls in Their Summer Clothes
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/03/12/cover-me-doc-walker-girls-in-their-summer-clothes/
#### Published: March 12, 2019
#### Last Updated: March 12, 2019
![docwalker.jpg](https://estreetshuffle.com/wp-content/uploads/2019/03/docwalker.jpg)

Sure, we know that Bruce’s songs translate well into country music arrangements. A good deal of his catalog is country-inspired, so it only makes sense that his music should appeal to country artists.
Check out [The Mavericks’ wonderful rendition of “All That Heaven Will Allow”](http://estreetshuffle.com/index.php/2019/02/28/cover-me-the-mavericks-all-that-heaven-will-allow/) for example, or Thompson Square on “[Brilliant Disguise](http://estreetshuffle.com/index.php/2018/10/17/cover-me-thompson-square-brilliant-disguise/).”
But if you ranked all of Bruce’s songs on a “Most Likely to be Covered by a Country Artist” list, my guess is “[Girls in Their Summer Clothes](http://estreetshuffle.com/index.php/2019/02/17/roll-of-the-dice-girls-in-their-summer-clothes/)” wouldn’t be anywhere near the top of it.
And yet… Canadian country band Doc Walker took a swing at it on their 2009 album *Go*, and dang if it doesn’t work perfectly. Hear for yourself:
[Youtube: Doc Walker  - "Girls in Their Summer Clothes"](https://www.youtube.com/watch?v=NfLkTFPsoCw)
![](https://www.youtube.com/watch?v=NfLkTFPsoCw)
Can’t say I prefer it to Bruce’s original, but it’s a very nice cover nonetheless.