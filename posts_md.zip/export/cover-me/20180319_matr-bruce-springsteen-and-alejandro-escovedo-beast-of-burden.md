# MatR: Bruce Springsteen and Alejandro Escovedo – Beast of Burden
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/19/matr-bruce-springsteen-and-alejandro-escovedo-beast-of-burden/
#### Published: March 19, 2018
#### Last Updated: August 30, 2020
![Beastofburden.gif](https://estreetshuffle.com/wp-content/uploads/2018/03/Beastofburden.gif)

Bruce dropped by Alejandro Escovedo’s gig at the Stone Pony on July 23, 2010 and joined him for The Rolling Stones’ “Beast of Burden.” Bruce has only performed this classic twice in his career–both times with Escovedo.
[Youtube: Escovedo & Springsteen - Beast of Burden (23-07-2010)](https://www.youtube.com/watch?v=sWu1xn3OKHM)
![](https://www.youtube.com/watch?v=sWu1xn3OKHM)
“Beast of Burden” was the second single off of The Stones’ 1978 *Some Girls* album, reaching #8 on the Billboard Hot 100.
[Youtube: Beast Of Burden by The Rolling Stones](https://www.youtube.com/watch?v=-tRdBsnX4N4)
![](https://www.youtube.com/watch?v=-tRdBsnX4N4)
**Beast of Burden
First performed:** July 23, 2010 (Asbury Park, NJ)
**Last performed:** March 14, 2012 (Austin, TX)