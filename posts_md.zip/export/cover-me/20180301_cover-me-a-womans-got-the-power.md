# Cover Me: A Woman's Got the Power
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/03/01/cover-me-a-womans-got-the-power/
#### Published: March 01, 2018
#### Last Updated: December 12, 2021
![womanpower.jpg](https://estreetshuffle.com/wp-content/uploads/2018/03/womanpower.jpg)

When Bruce’s mom complained that he always sang about his father but never about her, Bruce replied by covering “A Woman’s Got the Power” by the great Philly band The A’s during a Meadowlands appearance early on the *Born in the U.S.A.* Tour. (This was before Bruce wrote “[The Wish](http://estreetshuffle.com/index.php/2018/06/23/roll-of-the-dice-the-wish/).”)
[https://videopress.com/embed/t5cDigsh?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata](https://videopress.com/embed/t5cDigsh?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata)
On-stage, Bruce credited the song to Clarence Clemons and the Red Bank Rockers, and brought RBR vocalist J.T. Bowen on stage to sing it with him. And yes, Clarence and the Red Bank Rockers did release their own version a year prior in 1983.
[Youtube: A Woman's Got the Power](https://www.youtube.com/watch?v=fZgnx0oqv1c)
![](https://www.youtube.com/watch?v=fZgnx0oqv1c)
…but as a Philly child of the 80s, hometown pride compels to me to credit local band The A’s for the original, released in 1981. Their version will always be my favorite.
[Youtube: A Woman's Got the Power](https://www.youtube.com/watch?v=5Iw1wpLauVY)
![](https://www.youtube.com/watch?v=5Iw1wpLauVY)
**A Woman’s Got the Power****First performed:** August 9, 1984 (East Rutherford, NJ)
**Last performed:** October 22, 2011 (Asbury Park, NJ)