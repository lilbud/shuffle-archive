# MatR: Bruce Springsteen and Ringo Starr and His All Starr Band, Photograph
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/04/29/matr-bruce-springsteen-and-ringo-starr-and-his-all-starr-band-photograph/
#### Published: April 29, 2018
#### Last Updated: April 14, 2019
![starr-e1523737647640.jpg](https://estreetshuffle.com/wp-content/uploads/2018/04/starr-e1523737647640.jpg)

In 1989, with no E Street Band tour on the horizon, Clarence and Nils joined the original incarnation of Ringo Starr’s All-Star Band (which also included Levon Helm, Joe Walsh, Dr. John, Billy Preston, and other great artists).
When the tour came around to the Garden State Arts Center, Bruce joined his bandmates on-stage during the encores for four songs, including Ringo’s hit, “Photograph.”
[Youtube: PHOTOGRAPH ( Ringo Star cover )](https://www.youtube.com/watch?v=EzxoTbt0FRU)
![](https://www.youtube.com/watch?v=EzxoTbt0FRU)
This was the only time Bruce is known to have performed “Photograph.” Two months later, Bruce re-connected with Clarence and Nils during Starr’s Japanese tour leg–this time by phone, to break the news that he was ending the E Street Band.
[Youtube: Photograph](https://www.youtube.com/watch?v=nevdSt_2PIM)
![](https://www.youtube.com/watch?v=nevdSt_2PIM)
**Photograph**
**First performed:** August 11, 1989 (Holmdel, NJ)
**Last performed:** August 11, 1989 (Holmdel, NJ)