# MatR: Joe Grushecky and Bruce Springsteen: I Still Look Good (for Sixty)
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/04/24/matr-joe-grushecky-and-bruce-springsteen-i-still-look-good-for-sixty/
#### Published: April 24, 2018
#### Last Updated: April 14, 2019
![lookgood.jpg](https://estreetshuffle.com/wp-content/uploads/2018/04/lookgood.jpg)

Performed together only thrice: Bruce and Joe Grushecky have a good time sending themselves up with Joe’s “I Still Look Good (for Sixty).”
Here’s the first time they played it together, from night one of Bruce’s post-High Hopes Tour shows with Joe in Pittsburgh, May 22, 2014.
[Youtube: Bruce Springsteen - 2014-05-22 - I Still Look Good (For Sixty)](https://www.youtube.com/watch?v=__Cep8MQwtU)
![](https://www.youtube.com/watch?v=__Cep8MQwtU)
And the original, for comparison:
[Youtube: I Still Look Good (For Sixty)](https://www.youtube.com/watch?v=hMLxxgUCpeo)
![](https://www.youtube.com/watch?v=hMLxxgUCpeo)
**I Still Look Good (For Sixty)
First performed:** May 22, 2014 (Pittsburgh, PA)
**Last performed:** January 17, 2015 (Asbury Park, NJ)