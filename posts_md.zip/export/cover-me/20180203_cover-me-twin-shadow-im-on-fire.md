# Cover Me, Twin Shadow: I'm on Fire
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/02/03/cover-me-twin-shadow-im-on-fire/
#### Published: February 03, 2018
#### Last Updated: December 12, 2021
![twin-shadow.jpg](https://estreetshuffle.com/wp-content/uploads/2018/01/twin-shadow.jpg)

It occurred to me to day that I’m about a month into this blog and have yet to spotlight a cover of “[I’m on Fire](https://estreetshuffle.com/index.php/2021/09/11/roll-of-the-dice-im-on-fire/).”
That needs to change–if only because there are SO MANY covers of this song out there, and if I don’t start soon, we’re going to end up needing an “I’m on Fire” month at some point, and as great as the song is, no one wants that.
So let’s kick things off, with this *very* different take on “I’m on Fire” by Twin Shadow. He actually captures the steamy, late-night vibe of this song really well, placing him pretty high up on my list of “I’m on Fire” coverers. Enjoy.
[Youtube: Twin Shadow - I'm On Fire [UNDER THE CVRS]](https://www.youtube.com/watch?v=SktIeDlgYg4)
![](https://www.youtube.com/watch?v=SktIeDlgYg4)
Got a favorite “I’m on Fire” cover? Send a link my way, please!