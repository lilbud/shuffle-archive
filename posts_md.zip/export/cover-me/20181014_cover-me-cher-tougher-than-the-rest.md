# Cover Me, Cher: Tougher Than the Rest
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/10/14/cover-me-cher-tougher-than-the-rest/
#### Published: October 14, 2018
#### Last Updated: December 04, 2020
![cher.jpg](https://estreetshuffle.com/wp-content/uploads/2018/10/cher.jpg)

I’m not the biggest Cher fan, and the whole “bar in the sky” thing is a bit over-the-top and more than a bit corny, but… I do like her vocal turn on “[Tougher Than the Rest](https://estreetshuffle.com/index.php/2020/08/08/roll-of-the-dice-tougher-than-the-rest/)” from her 1990 performance in Vegas.
Also: Darlene Love! She classes up any act.
[Youtube: Cher - Tougher Than The Rest](https://www.youtube.com/watch?v=Kdg4FejMAZA)
![](https://www.youtube.com/watch?v=Kdg4FejMAZA)