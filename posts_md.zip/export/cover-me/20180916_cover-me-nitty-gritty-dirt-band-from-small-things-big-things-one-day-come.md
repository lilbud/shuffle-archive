# Cover Me, Nitty Gritty Dirt Band: From Small Things (Big Things One Day Come)
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/09/16/cover-me-nitty-gritty-dirt-band-from-small-things-big-things-one-day-come/
#### Published: September 16, 2018
#### Last Updated: December 03, 2020
![the-nitty-gritty-dirt-band-from-small-things-big-things-one-day-come-mca-e1535585046749.jpg](https://estreetshuffle.com/wp-content/uploads/2018/09/the-nitty-gritty-dirt-band-from-small-things-big-things-one-day-come-mca-e1535585046749.jpg)

The Nitty Gritty Dirt Band has a knack for spotting Springsteen songs that are ripe for a rockabilly cover treatment.
They scored with [their 1984 cover of “Cadillac Ranch,”](http://estreetshuffle.com/index.php/2018/02/26/cover-me-nitty-gritty-dirt-band-cadillac-ranch/) and six years later they rescued “From Small Things” from obscurity and landed it on the Billboard Country Top 100 chart, where it peaked at #65.
Their version breathes a bit more than Bruce’s original but retains its rebellious outlaw spirit. Here’s the studio recording and a live TV performance.
[Youtube: From Small Things (Big Things One Day Come)](https://www.youtube.com/watch?v=N-TbGLN8-lw)
![](https://www.youtube.com/watch?v=N-TbGLN8-lw)
[Youtube: From small things (Big things one day come) - The Nitty Gritty Dirt Band - live](https://www.youtube.com/watch?v=7OPqJObhkjQ)
![](https://www.youtube.com/watch?v=7OPqJObhkjQ)