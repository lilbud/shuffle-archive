# Cover Me, Nils Lofgren: Wreck on the Highway
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/01/25/cover-me-nils-lofgren-wreck-on-the-highway/
#### Published: January 25, 2018
#### Last Updated: December 28, 2022
![nils.jpg](https://estreetshuffle.com/wp-content/uploads/2018/01/nils.jpg)

Today’s Bruce cover is close to home: From the tail end of the E Street Diaspora comes this gorgeous Nils Lofgren cover of “[Wreck on the Highway](https://estreetshuffle.com/index.php/2022/08/28/roll-of-the-dice-wreck-on-the-highway/).”
Originally recorded for a Bruce tribute album in 1997, it was re-released on Nils’ *Face the Music* box set a few years back.
Nils’ vocals suit the song, but for my money the highlight is Nils’ take one the long guitar outro. This is easily a repeat-listen cover.
[Youtube: Nils Lofgren - Wreck on the Highway](https://www.youtube.com/watch?v=HsBRnnzn6Vc)
![](https://www.youtube.com/watch?v=HsBRnnzn6Vc)