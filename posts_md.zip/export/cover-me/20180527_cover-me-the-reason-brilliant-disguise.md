# Cover Me, The Reason: Brilliant Disguise
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/05/27/cover-me-the-reason-brilliant-disguise/
#### Published: May 27, 2018
#### Last Updated: March 09, 2019
![reason.jpg](https://estreetshuffle.com/wp-content/uploads/2018/05/reason.jpg)

From their 2008 EP by the same name, here’s a lovely acoustic cover of “[Brilliant Disguise](http://estreetshuffle.com/index.php/2018/02/06/roll-of-the-dice-brilliant-disguise/)” by Canadian band, The Reason. Most of the song is brash and bright, but the band grows quieter as the song becomes more contemplative, to great effect. A very nice cover of one of my all-time favorites.
[Youtube: Brilliant Disguise](https://www.youtube.com/watch?v=jq0LkOd-TFU)
![](https://www.youtube.com/watch?v=jq0LkOd-TFU)