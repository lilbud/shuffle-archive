# Cover Me, Little Mazarn: Dancing in the Dark
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2019/07/09/cover-me-little-mazarn-dancing-in-the-dark/
#### Published: July 09, 2019
#### Last Updated: January 01, 2023
![mazarn.jpg](https://estreetshuffle.com/wp-content/uploads/2019/07/mazarn.jpg)

I’m not sure how to describe Little Mazarn’s sound; “new age/Appalachian” may be as close as I can get.
It’s not worth getting hung up on categories, though, because no matter where you assign it, Little Mazarn’s cover of Bruce’s “[Dancing in the Dark](https://estreetshuffle.com/index.php/2021/12/25/roll-of-the-dice-dancing-in-the-dark/)” is gorgeous, haunting, and unique. It’ll stick with you long after the first listen.
[Youtube: Dancing in the Dark](https://www.youtube.com/watch?v=Wap9nrhyEJw)
![](https://www.youtube.com/watch?v=Wap9nrhyEJw)
You can find her version on her new 2019 album, *Io*, released mere weeks ago (as I write this, anyway).
Bonus: here’s a live performance from a few months before the album’s release. It’s not quite as stunning as the album version, but the context perfectly captures the isolation and loneliness in Bruce’s lyrics.
[Youtube: Little Mazarn// live cover of Dancing in the Dark](https://www.youtube.com/watch?v=I81h30D5mJ0)
![](https://www.youtube.com/watch?v=I81h30D5mJ0)