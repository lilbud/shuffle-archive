# Cover Me, Drive-By Truckers: Adam Raised a Cain
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/06/26/cover-me-drive-by-truckers-adam-raised-a-cain/
#### Published: June 26, 2018
#### Last Updated: December 28, 2022
![dbtruckers-e1529240957556.jpg](https://estreetshuffle.com/wp-content/uploads/2018/06/dbtruckers-e1529240957556.jpg)

Alt-country band Drive-by Truckers prove their rock bona fides whenever they cover [this classic](https://estreetshuffle.com/index.php/2022/07/03/roll-of-the-dice-adam-raised-a-cain/) from [*Darkness on the Edge of Town*](https://estreetshuffle.com/index.php/2022/07/05/album-companion-darkness-on-the-edge-of-town/). Here’s a recent performance from November 2016.
[Youtube: DRIVE-BY-TRUCKERS-ADAM RAISED A CAIN-WHERE THR DEVIL DON'T STAY](https://www.youtube.com/watch?v=RsGon7OLwjI)
![](https://www.youtube.com/watch?v=RsGon7OLwjI)