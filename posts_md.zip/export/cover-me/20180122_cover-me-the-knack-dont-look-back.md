# Cover Me, The Knack: Don't Look Back
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/01/22/cover-me-the-knack-dont-look-back/
#### Published: January 22, 2018
#### Last Updated: November 25, 2020
![kanck.jpg](https://estreetshuffle.com/wp-content/uploads/2018/01/kanck.jpg)

One of my all-time favorite Bruce covers: “[Don’t Look Back](https://estreetshuffle.com/index.php/2020/05/03/roll-of-the-dice-dont-look-back/)” by The Knack. (I’m a child of the 1980s. No apologies.)
If you’re gonna cover a Bruce Springsteen song, you either need to reinvent it or completely commit to it. These guys did the latter–and they wisely chose a song so well suited to their style that you could be forgiven for assuming it was their own material.
[Youtube: The Knack - Don't Look Back (blues springsteen cover)](https://www.youtube.com/watch?v=yBAMzLfatOA)
![](https://www.youtube.com/watch?v=yBAMzLfatOA)