# Cover Me, Bat for Lashes: I'm on Fire
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/11/02/cover-me-bat-for-lashes-im-on-fire/
#### Published: November 02, 2018
#### Last Updated: December 14, 2021
![bat.jpg](https://estreetshuffle.com/wp-content/uploads/2018/11/bat.jpg)

Here’s a cover that should stop you in your tracks.
Bat For Lashes (Natasha Khan) completely co-opts “[I’m on Fire,](https://estreetshuffle.com/index.php/2021/09/11/roll-of-the-dice-im-on-fire/)” preserving its sexual tension but completely transforming it into something more spiritual and more human than Bruce’s baser original.
Carried by an instrumental track that’s all piano, strings, and marxophone–and absolutely no percussion–Khan’s rendition of “I’m on Fire” is searingly yearning from start to finish.
[Youtube: BAT FOR LASHES I'm On Fire](https://www.youtube.com/watch?v=Rhat3oUbNkw)
![](https://www.youtube.com/watch?v=Rhat3oUbNkw)