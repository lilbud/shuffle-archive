# Cover Me: Gypsy Woman
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2020/01/21/cover-me-gypsy-woman/
#### Published: January 21, 2020
#### Last Updated: January 21, 2020
![gypsywoman.jpg](https://estreetshuffle.com/wp-content/uploads/2020/01/gypsywoman.jpg)

Curtis Mayfield may have had much bigger hits than “Gypsy Woman,” but “Gypsy Woman” is the track that paved the way for them.
Mayfield wrote “Gypsy Woman” after becoming the lead singer for The Impressions. Peaking at #20 on the Top 100 and stopping just short of the top spot on the R&B chart, the 1961 song became the first of a string of hits for Mayfield and the group.
[Youtube: The Impressions - Gypsy Woman (1961)](https://www.youtube.com/watch?v=3Wd4tlX5t-Q)
![](https://www.youtube.com/watch?v=3Wd4tlX5t-Q)
In 1970, Brian Hyland covered “Gypsy Woman” in a dreamlike arrangement and took the song even higher up the Top 100, peaking at #3.
[Youtube: Gypsy Woman - Brian Hyland - 1970.](https://www.youtube.com/watch?v=StC5lwA2snM)
![](https://www.youtube.com/watch?v=StC5lwA2snM)
In 1993, when asked to contribute a track to an upcoming Curtis Mayfield tribute album, Bruce chose “Gypsy Woman” as his contribution. Recorded in his home studio, the track features a prominent Tommy Sims (a recent alum of Bruce’s 1992-93 touring band) on bass, keyboards, percussion, backing vocals, and the Hammond B-3.
[Youtube: Gypsy Woman](https://www.youtube.com/watch?v=KnA4hbRDM4g)
![](https://www.youtube.com/watch?v=KnA4hbRDM4g)
Bruce’s version retains the mysterious atmosphere of Mayfield’s original and adds just a hint of danger. It’s a fine addition to Springsteen’s officially released catalog.
Although Bruce has never performed “Gypsy Woman” live in full, he did give us a taste of it at the Grammy Awards in 1994, when he sang it as part of a Mayfield medley with Bonnie Raitt, B.B. King, Steve Winwood and others. Take a look–you’ll find the song at around the 3:19 mark below.
[Youtube: Curtis Mayfield All-Star Jam](https://www.youtube.com/watch?v=AjM2KHrNUxk)
![](https://www.youtube.com/watch?v=AjM2KHrNUxk)
**Gypsy Woman
Recorded:** September-October 1993
**Released:** *A Tribute to Curtis Mayfield* (1994)
**Never performed** (but excerpted at the Grammy Awards on March 1, 1994 in New York City)