# Cover Me, Southside Johnny: Fade Away
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/05/03/cover-me-southside-johnny-fade-away/
#### Published: May 03, 2018
#### Last Updated: April 13, 2019
![spittinfire-e1524973878534.jpg](https://estreetshuffle.com/wp-content/uploads/2018/05/spittinfire-e1524973878534.jpg)

Last week, I wrote about Bruce’s sublime “[Fade Away.](http://estreetshuffle.com/index.php/2018/04/28/roll-of-the-dice-fade-away/)” It takes a lot of guts to cover it–there’s not much room (if any) for improvement.
But if anyone can do it justice, it’s Southside Johnny. His voice and style are perfectly suited for it, and he hits it out of the park. Just a beautiful, beautiful cover, from his 1997 *Spittin Fire* live album.
[Youtube: fade away/Southside Johnny](https://www.youtube.com/watch?v=Hp-UT_lcnSI)
![](https://www.youtube.com/watch?v=Hp-UT_lcnSI)