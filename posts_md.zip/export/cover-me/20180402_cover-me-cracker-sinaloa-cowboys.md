# Cover Me, Cracker: Sinaloa Cowboys
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/04/02/cover-me-cracker-sinaloa-cowboys/
#### Published: April 02, 2018
#### Last Updated: November 27, 2020
![cracker-e1522171095638.jpg](https://estreetshuffle.com/wp-content/uploads/2018/04/cracker-e1522171095638.jpg)

“Sinaloa Cowboys” isn’t a song I’d expect anyone to cover, but Cracker took a, um, crack at it back in 2003 on their *Countrysides* album. It’s a little countrified, but it still gets Bruce’s quiet, tragic story across quite nicely.
[Youtube: Sinaloa Cowboys](https://www.youtube.com/watch?v=K5Lja8y1Y3g)
![](https://www.youtube.com/watch?v=K5Lja8y1Y3g)