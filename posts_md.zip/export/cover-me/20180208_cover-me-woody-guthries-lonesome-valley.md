# Cover Me: Woody Guthrie's "Lonesome Valley"
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/02/08/cover-me-woody-guthries-lonesome-valley/
#### Published: February 08, 2018
#### Last Updated: November 25, 2019
![lonesome.jpg](https://estreetshuffle.com/wp-content/uploads/2018/02/lonesome.jpg)

At the June 26, 1993 Kristen Ann Carr benefit concert, Bruce and the 1992-1993 band (plus Joe Ely), opened the show with this emotional cover of Woody Guthrie’s “Lonesome Valley.”
It’s the only time Bruce has performed this song to date.
[Youtube: Bruce Springsteen - LONESOME VALLEY  1993 (audio)](https://www.youtube.com/watch?v=30DrA9_lIwc)
![](https://www.youtube.com/watch?v=30DrA9_lIwc)
**Lonesome Valley
First performed:** June 26, 1993
**Last performed:** June 26, 1993