# MatR: Darlene Love and Bruce Springsteen, Today I Met the Boy I'm Gonna Marry
#### Originally Published on Ken Rosen's E Street Shuffle blog at https://estreetshuffle.com/index.php/2018/11/12/matr-darlene-love-bruce-springsteen-and-the-cbs-orchestra-today-i-met-the-boy-im-gonna-marry/
#### Published: November 12, 2018
#### Last Updated: November 14, 2018
![t_darlene_love__today_i_met_the_boy_im_gonna_marry_ic001_122.jpg](https://estreetshuffle.com/wp-content/uploads/2018/11/t_darlene_love__today_i_met_the_boy_im_gonna_marry_ic001_122.jpg)

In 2011, Darlene Love was inducted into the Rock and Roll Hall of Fame. Bruce joined Darlene and the house band on stage at the induction ceremony for three of her songs, including her 1963 hit, “Today I Met the Boy I’m Gonna Marry.”
[Youtube: [Today I Met] The Boy I'm Gonna Marry](https://www.youtube.com/watch?v=MLAbXua2WxU)
![](https://www.youtube.com/watch?v=MLAbXua2WxU)
Only parts of the song were broadcast, but it documented the only time Bruce is known to have played this song. Watch it here, intercut with excerpts of Darlene’s acceptance speech, acknowledging Bruce and Steve:
[https://videopress.com/embed/6fI9NRMy?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata](https://videopress.com/embed/6fI9NRMy?hd=1&amp;cover=1&amp;loop=0&amp;autoPlay=0&amp;permalink=1&amp;muted=0&amp;controls=1&amp;playsinline=0&amp;useAverageColor=0&amp;preloadContent=metadata)
See my post on “[Zip a Dee Doo Dah](http://estreetshuffle.com/index.php/2018/08/28/meeting-across-the-river-darlene-love-and-bruce-springsteen-zip-a-dee-doo-dah/)” for another great performance from this show.
**Today I Met the Boy I’m Gonna Marry
First performed:** March 14, 2011 (New York City, NY)
**Last performed:** March 14, 2011 (New York City, NY)